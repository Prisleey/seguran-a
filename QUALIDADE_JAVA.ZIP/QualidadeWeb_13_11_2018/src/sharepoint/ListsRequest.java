package sharepoint;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import sharepoint.ListsSoap;
import sharepoint.UpdateListItems;
import sharepoint.UpdateListItems.Updates;

public class ListsRequest {
    	 
        private Document rootDocument;
        private Element rootDocContent;
        
        public ListsRequest() {
        	
        }

        public ListsRequest(String requestType) throws Exception {
            if (requestType != null) {
                if (requestType.equals("New") || requestType.equals("Update") || requestType.equals("Delete")) {
                    try {
                        Element rootElement = null;
                        DocumentBuilder docBuilder = null;
                        DocumentBuilderFactory dbfac = DocumentBuilderFactory.newInstance();
                        docBuilder = dbfac.newDocumentBuilder();
                        rootDocument = docBuilder.newDocument();
         
                        //Creates the root element
                        rootElement = rootDocument.createElement("Batch");
                        rootDocument.appendChild(rootElement);
         
                        //Creates the batch attributes
                        rootElement.setAttribute("ListVersion", "1");
                        rootElement.setAttribute("OnError", "Continue");
                        rootDocContent = rootDocument.createElement("Method");
                        rootDocContent.setAttribute("Cmd", requestType);
                        rootDocContent.setAttribute("ID", "1");
                        rootDocument.getElementsByTagName("Batch").item(0).appendChild(rootDocContent);
                    } catch (ParserConfigurationException ex) {
                        ex.printStackTrace();
                        throw (new Exception(ex.toString()));
                    }
                } else {
                    String err = "Unsupported request type";
                    throw (new Exception(err));
                }
            } else {
                String err = "Null parameters";
                throw (new Exception(err));
            }
        }

		/**
         * @return the rootDocument
         */
        public Document getRootDocument() {
            return rootDocument;
        }
     
        /**
         * @return the rootDocContent
         */
        public Element getRootDocContent() {
            return rootDocContent;
        }
        
        public boolean createListItem(List<HashMap<String, String>> fields) {
            //params check
            if (fields != null && this.getRootDocContent() != null && this.getRootDocument() != null && !fields.isEmpty()) {
                Element createdElement = null;
                //Adds attribute by attribute to fields
                for (int i = 0; i < fields.size(); i++) {
	                for (Map.Entry<String, String> aField : fields.get(i).entrySet()) {
	                    createdElement = this.getRootDocument().createElement("Field");
	                    createdElement.setAttribute("Name", aField.getKey());
	                    Text attributeValue = getRootDocument().createTextNode("" + aField.getValue());
	                    createdElement.appendChild(attributeValue);
	                    this.getRootDocContent().appendChild(createdElement);
	                }
                }
                System.out.println(xmlToString(this.getRootDocContent().getOwnerDocument()));
                return true;
            }
            return false;
        }
        
        public boolean updateItem(String itemName, String itemValue, String id) {
            //params check
            if (itemName != "" && this.getRootDocContent() != null && this.getRootDocument() != null && itemValue != "") {
                Element createdElement = null;
                Element createdElementID = null;
                
                createdElementID = this.getRootDocument().createElement("Field");
            	createdElementID.setAttribute("Name", "ID");
                Text attributeValueID = getRootDocument().createTextNode("" + id);
                createdElementID.appendChild(attributeValueID);
            
                createdElement = this.getRootDocument().createElement("Field");
                createdElement.setAttribute("Name", itemName);
                Text attributeValue = getRootDocument().createTextNode("" + itemValue);
                createdElement.appendChild(attributeValue);
                
                this.getRootDocContent().appendChild(createdElementID);
                this.getRootDocContent().appendChild(createdElement);
                
                return true;
            }
            return false;
        }
        
        public boolean deleteItem(List<HashMap<String, String>> itemUpdates, String id) {
            //params check
            if (itemUpdates != null && this.getRootDocContent() != null && this.getRootDocument() != null && !itemUpdates.isEmpty()) {
                Element createdElementID = null;

                createdElementID = this.getRootDocument().createElement("Field");
            	createdElementID.setAttribute("Name", "ID");
                Text attributeValueID = getRootDocument().createTextNode("" + id);
                createdElementID.appendChild(attributeValueID);
                
                this.getRootDocContent().appendChild(createdElementID);
                
                return true;
            }
            return false;
        }

        public String insertListItem(ListsSoap port, String listName, List<HashMap<String, String>> itemAttributes) {
        	 String log = "N�o houve update";
            //Parameters validity check
            if (port != null && listName != null && itemAttributes != null && !itemAttributes.isEmpty()) {
                try {
         
                    //Building the CAML query with one item to add, and printing request
                    ListsRequest newCompanyRequest = new ListsRequest("New");
                    newCompanyRequest.createListItem(itemAttributes);
         
                    //initializing the Web Service operation here
                    Updates updates = new UpdateListItems.Updates();
         
                    //Preparing the request for the update
                    Object docObj = (Object) newCompanyRequest.getRootDocument().getDocumentElement();
                    updates.getContent().add(0, docObj);

                    //Sending the insert request to the Lists.UpdateListItems Web Service
                    port.updateListItems(listName, updates);
                    
                    System.out.println("Update realizado com sucesso!!");
                    
                    log = "Update com sucesso!!";
                    return log;
                    /*
                     *Printing the response in the console.
                     *If successful, the inserted item will be returned
                     */
                } catch (Exception e) {
                    e.printStackTrace();
                    log = "Update n�o realizado!!";
                    return log;
                }
            }
			return log;
        }
        
        public void deleteListItem(ListsSoap port, String listName, List<HashMap<String, String>> itemAttributes) {
       	 
            //Parameters validity check
            if (port != null && listName != null && itemAttributes != null && !itemAttributes.isEmpty()) {
                try {
         
                    //Building the CAML query with one item to add, and printing request
                    ListsRequest newCompanyRequest = new ListsRequest("Delete");
                    newCompanyRequest.createListItem(itemAttributes);
         
                    //initializing the Web Service operation here
                    Updates updates = new UpdateListItems.Updates();
         
                    //Preparing the request for the update
                    Object docObj = (Object) newCompanyRequest.getRootDocument().getDocumentElement();
                    updates.getContent().add(0, docObj);
         
                    //Sending the insert request to the Lists.UpdateListItems Web Service
                    port.updateListItems(listName, updates);
                    
                    System.out.println("Delete realizado com sucesso!!");
                    /*
                     *Printing the response in the console.
                     *If successful, the inserted item will be returned
                     */
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        
        public void updateListItem(ListsSoap port, String listName, List<HashMap<String, String>> itemAttributes, List<HashMap<String, String>> itemUpdates) {
          	 
            //Parameters validity check
            if (port != null && listName != null && itemAttributes != null && !itemAttributes.isEmpty()) {
                try {
                    //Building the CAML query with one item to update, and printing request
                    ListsRequest newCompanyRequest = new ListsRequest("Update");
                    
                    for (int i = 0; i < itemAttributes.size(); i++) {
                    	String id = itemAttributes.get(i).values().toString().replace("[","").replaceAll("]", "").split(", ")[1];
    	                for (Map.Entry<String, String> aField : itemAttributes.get(i).entrySet()) {
    	                	for (int j = 0; j < itemUpdates.size(); j++) {
    	                		for (Map.Entry<String, String> aField2 : itemUpdates.get(j).entrySet()) {
    	                		
		    	                	newCompanyRequest = new ListsRequest("Update");
		    	                	
		    	                	if (aField.getKey() == "NomeBase") {
		    	                		newCompanyRequest.updateItem(aField.getKey(), aField2.getValue(), id);
		        	                    
		        	                    System.out.println(xmlToString(newCompanyRequest.getRootDocument()));
		        	                    
		        	                    //initializing the Web Service operation here
		        	                    Updates updates = new UpdateListItems.Updates();
		        	         
		        	                    //Preparing the request for the update
		        	                    Object docObj = (Object) newCompanyRequest.getRootDocument().getDocumentElement();
		        	                    updates.getContent().add(0, docObj);
		        	         
		        	                    //Sending the insert request to the Lists.UpdateListItems Web Service
		        	                    System.out.println(updates.getContent());
		        	                    port.updateListItems(listName, updates);
		        	                    
		        	                    System.out.println("Update realizado com sucesso!!");
		        	                    break;
	    	                		}
    	                		}
    	                	}
    	                	
    	                }
                    }
                    
                    /*
                     *Printing the response in the console.
                     *If successful, the inserted item will be returned
                     */
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        
        public static String xmlToString(Document docToString) {
            String returnString = "\n-------------- XML START --------------\n";
            try {
                //create string from xml tree
                //Output the XML
                //set up a transformer
                TransformerFactory transfac = TransformerFactory.newInstance();
                Transformer trans;
                trans = transfac.newTransformer();
                trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
                trans.setOutputProperty(OutputKeys.INDENT, "yes");
                StringWriter sw = new StringWriter();
                StreamResult streamResult = new StreamResult(sw);
                DOMSource source = new DOMSource(docToString);
                trans.transform(source, streamResult);
                String xmlString = sw.toString();
                //print the XML
                returnString = returnString + xmlString;
            } catch (TransformerException ex) {
                System.out.println("N�o converteu para string");
            }
            returnString = returnString + "-------------- XML END --------------";
            return returnString;
        }
    }