package conectores;

import java.io.*;
import java.net.*;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.w3c.dom.Document;
import org.xml.sax.*;

public class ConectorSP {
	private final String sts = "https://login.microsoftonline.com/extSTS.srf";
	
	private final String loginContextPath = "/_forms/default.aspx?wa=wsignin1.0";
	
	private final String sharepointContext = "http://shp.net.bradesco.com.br/risk/dtm/imi/dq/Lists/Monitoramento%20Qualidade";
	
	private final String username="i354217";
	private final String password="cebola08";
	
	private final String reqXML = "<?xml version=\"1.0\" encoding=\"utf-8\" ?><s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:a=\"http://www.w3.org/2005/08/addressing\" xmlns:u=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"><s:Header><a:Action s:mustUnderstand=\"1\">http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue</a:Action><a:ReplyTo><a:Address>http://www.w3.org/2005/08/addressing/anonymous</a:Address></a:ReplyTo><a:To s:mustUnderstand=\"1\">https://login.microsoftonline.com/extSTS.srf</a:To><o:Security s:mustUnderstand=\"1\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><o:UsernameToken><o:Username>[username]</o:Username><o:Password>[password]</o:Password></o:UsernameToken></o:Security></s:Header><s:Body><t:RequestSecurityToken xmlns:t=\"http://schemas.xmlsoap.org/ws/2005/02/trust\"><wsp:AppliesTo xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/policy\"><a:EndpointReference><a:Address>[endpoint]</a:Address></a:EndpointReference></wsp:AppliesTo><t:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</t:KeyType><t:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</t:RequestType><t:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</t:TokenType></t:RequestSecurityToken></s:Body></s:Envelope>";
	
	private String generateSAML() {
		String saml = reqXML
				.replace("[username]", username);
		saml = saml.replace("[password]", password );
		saml = saml.replace("[endpoint]", sharepointContext+loginContextPath);
		return saml;
	}
	public String login() {
		String token;
		try {
			token = requestToken();
			String cookie = submitToken(token);
			return cookie;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return "";
	}
	
	private String requestToken() throws XPathExpressionException, SAXException,
		ParserConfigurationException, IOException {

		String saml = generateSAML();

		URL u = new URL(sts);
		URLConnection uc = u.openConnection();
		HttpURLConnection connection = (HttpURLConnection) uc;

		connection.setDoOutput(true);
		connection.setDoInput(true);
		connection.setRequestMethod("POST");
		
		connection.addRequestProperty("Content-Type",
				"text/xml; charset=utf-8");
		// connection.addRequestProperty("Expect", "100-continue");
		// connection.addRequestProperty("Connection", "Keep-Alive");
		// connection.addRequestProperty("Content-Length", saml.length() +
		// "");
		// connection.setRequestProperty("SOAPAction", SOAP_ACTION);

		OutputStream out = connection.getOutputStream();
		Writer wout = new OutputStreamWriter(out);
		wout.write(saml);

		wout.flush();
		wout.close();

		InputStream in = connection.getInputStream();
		int c;
		StringBuilder sb = new StringBuilder("");
		while ((c = in.read()) != -1)
			sb.append((char) (c));
		in.close();
		String result = sb.toString();
		String token = extractToken(result);
		System.out.println(token);
		return token;
	}
	private String extractToken(String result) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException {
		
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();

        Document document = db.parse(new InputSource(new StringReader(result)));

        XPathFactory xpf = XPathFactory.newInstance();
        XPath xp = xpf.newXPath();
        String token = xp.evaluate("//BinarySecurityToken/text()", document.getDocumentElement());
        System.out.println(token);
        return token;
	}
	private String submitToken(String token) throws IOException {
		String url = sharepointContext+loginContextPath;
		URL u = new URL(url);
		URLConnection uc = u.openConnection();
		HttpURLConnection connection = (HttpURLConnection) uc;

		connection.setDoOutput(true);
		connection.setDoInput(true);
		connection.setRequestMethod("POST");
		connection.addRequestProperty("Accept", "application/x-www-form-urlencoded");
		connection.addRequestProperty("User-Agent", "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0)");
		// http://stackoverflow.com/questions/12294274/mobile-app-for-sharepoint/12295224#12295224
		// connection.addRequestProperty("SOAPAction", sts);
		connection.addRequestProperty("Content-Type",
				"text/xml; charset=utf-8");
		// connection.addRequestProperty("Expect", "100-continue");
		// connection.addRequestProperty("Connection", "Keep-Alive");
		// connection.addRequestProperty("Content-Length", saml.length() +
		// "");
		connection.setInstanceFollowRedirects(false);

		OutputStream out = connection.getOutputStream();
		Writer wout = new OutputStreamWriter(out);

		wout.write(token);

		wout.flush();
		wout.close();

		InputStream in = connection.getInputStream();
		
		//http://www.exampledepot.com/egs/java.net/GetHeaders.html
		
	    for (int i=0; ; i++) {
	        String headerName = connection.getHeaderFieldKey(i);
	        String headerValue = connection.getHeaderField(i);
	        System.out.println("header: " + headerName + " : " + headerValue);
	        if (headerName == null && headerValue == null) {
	            // No more headers
	            break;
	        }
	        if (headerName == null) {
	            // The header value contains the server's HTTP version
	        }
	    }
		String headerName = connection.getHeaderField("set-cookie");
		System.out.println("headerName");
		System.out.println(headerName);
		int c;
		StringBuilder sb = new StringBuilder("");
		while ((c = in.read()) != -1)
			sb.append((char) (c));
		in.close();
		String result = sb.toString();
		System.out.println(result);

		return headerName;
	}

	public static void main(String [] args) {
		System.out.println(new ConectorSP().login());
		
	}
}