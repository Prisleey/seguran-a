package conectores;

import com.sas.iom.SAS.ILanguageService;
import com.sas.iom.SAS.IWorkspace;
import com.sas.iom.SAS.IWorkspaceHelper;
import com.sas.iom.SASIOMDefs.GenericError;
import com.sas.rio.MVAConnection;
import com.sas.services.connection.*;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import model.Base;
import model.ColunaTabela;
import model.Setor;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.BasicConfigurator;

public class ConectorSAS implements Iconectores {
	
	private IWorkspace sasWorkspace = null;
	private ILanguageService sasLanguage;
	private org.omg.CORBA.Object obj = null;
	private String log;
	public String getLog() {
		return this.log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	private ConnectionInterface cx = null;
	private MVAConnection connection = null;
	private Properties props = new Properties();
	private Statement statement = null;
	private ResultSet result = null;
	
	
	//construtor
	public ConectorSAS() {
		
	}
	
	//estabelece a conex�o
	public void iniciar() {
		
		
	}
	
	public void iniciar(String user, String password, String host, int port) throws IOException {
		try {
			
			//FIXANDO A SENHA AQUI PARA SO MUDAR EM UM LUGAR QUANDO PRECISAR
			String[] login = getLoginSAS();
			String usr = login[0];
			String pwd = login[1];
			
			BasicConfigurator.configure();
			String classID = Server.CLSID_SAS;
			// Connect to the server and retrieve an IWorkSpace
			Server server = new BridgeServer(classID, host, port);
			ConnectionFactoryConfiguration cxfConfig = new ManualConnectionFactoryConfiguration(server);
			ConnectionFactoryManager cxfManager = new ConnectionFactoryManager();
			ConnectionFactoryInterface cxf = cxfManager.getFactory(cxfConfig);
			cx = cxf.getConnection(usr, pwd);

			obj = cx.getObject();
			sasWorkspace = IWorkspaceHelper.narrow(obj);
			sasLanguage = sasWorkspace.LanguageService();
			log = sasLanguage.FlushLog(10000);
			sasLanguage.Submit("options obs=max nosyntaxcheck;");

			if (!log.contains("Access denied")) {
				System.out.println("Conectado com sucesso no SAS!!");
			}

			try {
				Class.forName("com.sas.rio.MVADriver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			props.setProperty("user", usr);
			props.setProperty("password", pwd);
			try {
				connection = new MVAConnection(sasWorkspace, props);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		} catch (ConnectionFactoryException e) {
			System.out.println("Falha na conex�o com o servidor!!");
			setLog("Falha na conex�o com o servidor");
			System.out.println(e.getMessage());
		} catch (GenericError e) {
			System.out.println("Falha no carregamento da log!!");
			setLog("Falha no carregamento da log");
			System.out.println(e.getMessage());
		}
	}
	
	private String[] getLoginSAS() {
		GerenciadorDeConexao sqlServer = null;
		String[] login = new String[2];
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			login = bDAO.getLoginSAS();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return login;
	}

	//encerra a conex�o
	public void encerrar() {
		closeResources();
		if(connection != null) {
			try {
				connection.close();
				System.out.println("Connection encerrada!!");
			} catch(Exception except) {
				System.out.println("Falha ao fechar Connection: " + except.getMessage());
			} finally {
				connection = null;
			}
		}
		if(sasWorkspace != null) {
			try {
				sasWorkspace.Close();
			} catch(Exception except) {
				System.out.println("Falha ao fechar SasWorkspace: " + except.getMessage());
			} finally {
				sasWorkspace = null;
			}
		}
		if(cx != null) {
			try {
				cx.close();
				System.out.println("ConnectionInterface encerrada!!");
			} catch(Exception except) {
				System.out.println("Falha ao fechar ConnectionInterface: " + except.getMessage());
			} finally {
				cx = null;
			}
		}		
	}
	
	
	
	//M�todo que executa um comando no SAS
	public String ComandoSAS(String comando) throws GenericError {
		if (sasLanguage == null) {
			System.out.println("� null");
			return "-1";
		}
		sasLanguage.Submit(comando);
		String log = sasLanguage.FlushLog(10000000);
		return log;
	}
	
	
	//M�todo que traz o resultado de uma coluna do SAS para saber se a tabela est� vazia ou n�o
		public int getColunaVazia(String queryString) {
				int resultado = 0;
			try {
				statement = connection.createStatement();
				result = statement.executeQuery(queryString);
	
			    int columnCount = result.getMetaData().getColumnCount();
			    
			    while(result.next()) {
			    	resultado = result.getInt("VAZIA");
			    }
			     		     
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeResources();
			}
			return resultado;
		}
	
	//M�todo que traz a base do SAS
	public ArrayList<ArrayList<String>> baseSAS(String queryString) {
		try {
			statement = connection.createStatement();
			result = statement.executeQuery(queryString);
			ArrayList<ArrayList<String>> table;
		    int columnCount = result.getMetaData().getColumnCount();
		     
		    if(result.getType() == ResultSet.TYPE_FORWARD_ONLY) 
		        table = new ArrayList<ArrayList<String>>();
		    else {  
		        result.last();
		        table = new ArrayList<ArrayList<String>>(result.getRow());
		        result.beforeFirst();
		    }
		 
		    for(ArrayList<String> row; result.next(); table.add(row)) {
		        row = new ArrayList<String>(columnCount);
		 
		        for(int c = 1; c <= columnCount; ++ c)
		            row.add(result.getString(c).intern());
		    }
		     
		    return table;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		return null;
	}
	
	public double[] nobs_bases(String lib, String base, String ultimaData, int contador, int tamanho_amostra) {
		
		ArrayList<ArrayList<String>> table_observacao = new ArrayList<ArrayList<String>>();
		double[] nobs = null;
		String date = "";
		String time = "";
		int time_int = 0;
		
		String dataDeHoje = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
				.format(new Date());
		
		if (!ultimaData.equals("0")) {
			date = ultimaData.substring(0, 10);
			date = date.split("/")[2] + "-" + date.split("/")[1] + "-" + date.split("/")[0];
			
			time = ultimaData.substring(11, ultimaData.length());
			time_int = Integer.parseInt(time.replace(":", ""));
		}
		//Server SASApp
		String log = null;
		
		try {
		
			// Faz o proc contents e busca as informa��es dos campos e n� de observa��es da base.
			//O sas deve ter sido previamente conectado pelo metodo "Iniciar()"
			
			if (lib.length() > 9) { 
				log = ComandoSAS("libname OBSER " + lib + ";");
				log = ComandoSAS("%macro lib_assign(lib1);%if (%sysfunc(libref(&lib1))) %then %put %sysfunc(sysmsg());%else %put \"assigned\";%mend;%lib_assign(lib1=OBSER);");
				if (log.contains("ERROR: Libref OBSER is not assigned.") || log.contains("Library OBSER does not exist.")) {
					nobs = new double[1];
					nobs[0] = -1;
				} else {
					System.out.println("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library=OBSER memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 8)+") = \""+(base.substring(0, base.length() - 8))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA=OBSER.&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS; date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output; RUN;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library=OBSER memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 8)+") = \""+(base.substring(0, base.length() - 8))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA=OBSER.&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS; date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output; RUN;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+"));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
				}
			} else {	
				log = ComandoSAS("%macro lib_assign(lib1);%if (%sysfunc(libref(&lib1))) %then %put %sysfunc(sysmsg());%else %put \"assigned\";%mend;%lib_assign(lib1="+lib+");");
				
				if (log.contains("is not assigned.") || log.contains("does not exist.")) {
					nobs = new double[1];
					nobs[0] = -1;
				} else {
				
					System.out.println("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library="+lib+" memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 8)+") = \""+(base.substring(0, base.length() - 8))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA="+lib+".&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS;date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output;run;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library="+lib+" memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 8)+") = \""+(base.substring(0, base.length() - 8))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA="+lib+".&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS;date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output;run;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+"));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
				}
			}
			if (!log.contains("\"DEU BOA\"")) {
				System.out.println(log);
				nobs = new double[1];
				nobs[0] = -1;
			} else if (log.contains("is damaged.")) {
				nobs = new double[1];
				nobs[0] = -5;
			} else {		
				System.out.println(log);
				table_observacao = new ArrayList<ArrayList<String>>();
				
				
				if (ultimaData.equals("0")) {
					log += ComandoSAS("PROC SQL outobs= "+tamanho_amostra+";create table lista_Nobs"+contador+" as select * from lista_Nobs"+contador+" ORDER BY MODATE DESC;QUIT;");
					table_observacao = baseSAS("SELECT nobs FROM WORK.lista_Nobs" + contador + " Order BY MODATE DESC;");
				} else {
					table_observacao = baseSAS("SELECT nobs FROM WORK.lista_Nobs" + contador);
				}
				
				nobs = new double[table_observacao.size()];
				
				for (int base_i = 0; base_i < (table_observacao.size()); base_i++)
				{
					nobs[base_i] = Double.parseDouble(table_observacao.get(base_i).get(0));
				}
			}
			
//			try (PrintStream out = new PrintStream(new FileOutputStream("Z:\\Publico\\D4852\\GestaoDados\\03 - Controle de Qualidade & BI\\Outros\\LOGS\\" + base + "_" + dataDeHoje.replace("\\", "_").replace(":", "_") +".txt"))) {
//			    out.print(log);
//			} catch (FileNotFoundException e) {
//				e.printStackTrace();
//			}
			
		} catch (GenericError e) {
			System.out.println("Falha ao executar o comando selecionado!!");
			System.out.println(e.getMessage());
		}
		
		if (nobs.length == 0) {
			nobs = new double[1];
			nobs[0] = -1;
		}
	
		return nobs;
	}
	
	public double[] nobs_basesMensal(String lib, String base, String ultimaData, int contador) {
		
		ArrayList<ArrayList<String>> table_observacao = null;
		double[] nobs = null;
		String date = "";
		String time = "";
		int time_int = 0;
		if (!ultimaData.equals("0")) {
			date = ultimaData.substring(0, 10);
			date = date.split("/")[2] + "-" + date.split("/")[1] + "-" + date.split("/")[0];
			
			time = ultimaData.substring(11, ultimaData.length());
			time_int = Integer.parseInt(time.replace(":", ""));
		}
		
		//Server SASApp
		String log = null;
		
		try {
		
			// Faz o proc contents e busca as informa��es dos campos e n� de observa��es da base.
			//O sas deve ter sido previamente conectado pelo metodo "Iniciar()"
			
			if (lib.length() > 9) { 
				log = ComandoSAS("libname OBSER " + lib + ";");	
				log = ComandoSAS("%macro lib_assign(lib1);%if (%sysfunc(libref(&lib1))) %then %put %sysfunc(sysmsg());%else %put \"assigned\";%mend;%lib_assign(lib1=OBSER);");
				if (log.contains("ERROR: Libref OBSER is not assigned.")) {
					nobs = new double[1];
					nobs[0] = -1;
				} else {
					
					System.out.println("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library=OBSER memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 6)+") = \""+(base.substring(0, base.length() - 6))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA=OBSER.&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS; date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output; RUN;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library=OBSER memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 6)+") = \""+(base.substring(0, base.length() - 6))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA=OBSER.&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS; date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output; RUN;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+"));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
				}
			} else {	
				log = ComandoSAS("%macro lib_assign(lib1);%if (%sysfunc(libref(&lib1))) %then %put %sysfunc(sysmsg());%else %put \"assigned\";%mend;%lib_assign(lib1="+lib+");");
				if (log.contains("ERROR: Libref OBSER is not assigned.")) {
					nobs = new double[1];
					nobs[0] = -1;
				} else {
					System.out.println("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library="+lib+" memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 6)+") = \""+(base.substring(0, base.length() - 6))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA="+lib+".&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS; date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output; RUN;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output;RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("options obs=max nosyntaxcheck;proc datasets library=WORK kill; run; quit;ods output Members=Lista_Bases; proc datasets library="+lib+" memtype=data; run;proc delete data=BASE_OBSERVACAO"+contador+"; run;proc delete data=BASE_OBS; run;proc delete data=Lista_Bases_Observacao;run; data Lista_Bases_Observacao(keep= Name);SET work.Lista_Bases( WHERE = (Substr(NAME,1,"+(base.length() - 6)+") = \""+(base.substring(0, base.length() - 6))+"\" AND (length(NAME) = "+base.length()+")));length date_time3 $5;date_time3 = input(\""+date+"\", yymmdd10.);date_time2 = input(date_time3, 8.);date_time = Datepart(LastModified);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(LastModified),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time2) then output;else if (date_time = date_time2) then do;if (time1 > time2) then output;end;RUN; %macro GerarLista();%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN%DO;DATA lista_Nobs"+contador+";set lista_Nobs"+contador+";if NOBS < 0 then output;RUN;%END; DATA _NULL_; IF 0 THEN SET WORK.Lista_Bases_Observacao NOBS=N; CALL SYMPUTX('NOBS_BASE_Lista_OBS',N); STOP; RUN; %IF &NOBS_BASE_Lista_OBS. > 0 %THEN %DO; DATA _NULL_; SET WORK.Lista_Bases_Observacao; CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME); CALL SYMPUT('NOBS_BASE',_N_); RUN; PROC DELETE DATA=BASE_OBSERVACAO"+contador+";PROC DELETE DATA=BASE_OBS;RUN; RUN; %DO i = 1 %TO &NOBS_BASE.; PROC CONTENTS DATA="+lib+".&&nome_base&i. OUT=BASE_OBS (keep= NOBS MEMNAME MODATE) NOPRINT; RUN; DATA BASE_OBS; SET BASE_OBS; date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output; RUN;DATA BASE_OBS;SET BASE_OBS;IF _N_ = 1 then output;run; PROC APPEND BASE=BASE_OBSERVACAO"+contador+" DATA=BASE_OBS FORCE; %END; %END; %ELSE %DO; DATA BASE_OBSERVACAO"+contador+"; NOBS = -1;MEMNAME = 0;MODATE=\"\"; RUN; %END; %mend GerarLista; %GerarLista; DATA lista_Nobs"+contador+" (keep= NOBS MODATE);SET WORK.BASE_OBSERVACAO"+contador+";date_time3 = input(\""+date+"\", yymmdd10.);date_time = Datepart(modate);time2 = "+time_int+";time_1 = COMPRESS(put(timepart(modate),time.));time1 = input(COMPRESS(tranwrd(time_1, ':', '')), 8.);if (date_time > date_time3) then output; else if (date_time = date_time3) then do;if (time1 > time2) then output;end;else output;RUN;DATA lista_Modate"+contador+" (keep= MODATE1);SET WORK.BASE_OBSERVACAO"+contador+";modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3); RUN;");
					log += ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.lista_Nobs"+contador+"));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
				}
			}
			if (log.contains("ERROR")) {
				System.out.println(log);	
			}
			
			if (ultimaData.equals("0")) {
				log += ComandoSAS("PROC SQL outobs= 6;create table lista_Nobs"+contador+" as select * from lista_Nobs"+contador+" ORDER BY MODATE DESC;QUIT;");
				table_observacao = baseSAS("SELECT nobs FROM WORK.lista_Nobs" + contador + " Order BY MODATE DESC");
			} else {
				table_observacao = baseSAS("SELECT nobs FROM WORK.lista_Nobs" + contador + " Order BY MODATE DESC");
			}
			
			nobs = new double[table_observacao.size()];
			
			for (int base_i = 0; base_i < (table_observacao.size()); base_i++)
			{
				nobs[base_i] = Double.parseDouble(table_observacao.get(base_i).get(0));
			}
			
			
		} catch (GenericError e) {
			System.out.println("Falha ao executar o comando selecionado!!");
			System.out.println(e.getMessage());
		}
		
		if (nobs.length == 0) {
			nobs = new double[1];
			nobs[0] = -1;
		}
	
		return nobs;
	}
	
	@SuppressWarnings("unused")
	public List<ColunaTabela> getCaracteristicasColunas(int id) {

		ArrayList<ArrayList<String>> table_observacao = null;
		List<ColunaTabela> colunas = new ArrayList();
		ColunaTabela coluna;

		table_observacao = baseSAS("SELECT NAME, TYPE, LENGTH FROM WORK.BASE_INTEGRIDADE WHERE ID = " + id + "");

		for (int i = 0; i < table_observacao.size(); i++) {
			coluna = new ColunaTabela();
			coluna.setNomeColuna(table_observacao.get(i).get(0).trim());
			
			String tipoCol;
			tipoCol = table_observacao.get(i).get(1).toString().trim();

			//int tipoCol2;
			//tipoCol2 = Integer.parseInt(table_observacao.get(i).get(1).trim());
			coluna.setTipoColuna(Integer.parseInt(table_observacao.get(i).get(1).trim().split("\\.")[0]));
			coluna.setTamanhoColuna(Integer.parseInt(table_observacao.get(i).get(2).trim().split("\\.")[0]));
			
			colunas.add(coluna);
			
		}

		return colunas;
	}
	
	
	public String[] nomeBase() {

		ArrayList<ArrayList<String>> table_observacao = null;
		ArrayList<ArrayList<String>> table_nomes = null;
		ArrayList<String> vetor = new ArrayList<String>();
		String[] nomes = null;

		table_nomes = baseSAS("SELECT NAME FROM WORK.BASE_INTEGRIDADE");
		table_observacao =baseSAS("SELECT NAME FROM WORK.Lista_Bases_Integridade");
		nomes = new String[table_nomes.size()];

		for (int i = 1; i < table_observacao.size(); i++) {
			table_nomes = baseSAS("SELECT NAME FROM WORK.BASE_INTEGRIDADE WHERE ID= " + i + "");
			
			for (int j = 0; j < table_nomes.size(); j++) {
				vetor.add(table_observacao.get(i).get(0).trim());
			}
		}
		nomes = new String[vetor.size()];
		for (int j = 0; j < vetor.size(); j++) {
			nomes[j] = vetor.get(j);
		}

		return nomes;
	}
	
	public void gerarBases(String lib, String base) {

		String log = null;
		
		try {
			if (lib.length() > 9) { 
				log = ComandoSAS("libname INTEG " + lib + ";");
				log += ComandoSAS(
						"ods output Members=Lista_Bases;proc datasets library=INTEG memtype=data;run;data Lista_Bases_Integridade (keep= Name WHERE = (NAME CONTAINS " + base + "));SET work.Lista_Bases;RUN;DATA _NULL_;SET WORK.Lista_Bases_Integridade;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);	CALL SYMPUT('NOBS_BASE',_N_);RUN;%PUT NOBS_BASE: &NOBS_BASE.;%macro GerarLista();PROC DELETE DATA=BASE_INTEGRIDADE;RUN;PROC DELETE DATA=BASE_OBSERVACAO;RUN;%do i=1 %to &NOBS_BASE;	%put &&nome_base&i.;PROC CONTENTS DATA=INTEG.&&nome_base&i. OUT=BASE_OBS (keep= MEMNAME NAME TYPE LENGTH NOBS) NOPRINT;	RUN;DATA BASE_INTEGRIDADE_AUX (KEEP= NAME LENGTH TYPE ID);		SET work.BASE_OBS;		ID = &i.;	RUN;PROC APPEND BASE=BASE_INTEGRIDADE DATA=BASE_INTEGRIDADE_AUX FORCE;DATA BASE_OBSERVACAO_AUX (KEEP= MEMNAME NOBS);		SET work.BASE_OBS;	RUN;PROC APPEND BASE=BASE_OBSERVACAO DATA=BASE_OBSERVACAO_AUX FORCE;%end;%mend GerarLista;%GerarLista;PROC SORT DATA=BASE_OBSERVACAO NODUPKEY;BY MEMNAME;RUN;PROC DELETE DATA=BASE_INTEGRIDADE_AUX;RUN;PROC DELETE DATA=BASE_OBSERVACAO_AUX;RUN;PROC DELETE DATA=Lista_Bases;RUN;PROC DELETE DATA=BASE_OBS;RUN;");
			} else {
				log += ComandoSAS(
						"ods output Members=Lista_Bases;proc datasets library="+lib+" memtype=data;run;data Lista_Bases_Integridade (keep= Name WHERE = (NAME CONTAINS " + base + "));SET work.Lista_Bases;RUN;DATA _NULL_;SET WORK.Lista_Bases_Integridade;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);	CALL SYMPUT('NOBS_BASE',_N_);RUN;%PUT NOBS_BASE: &NOBS_BASE.;%macro GerarLista();PROC DELETE DATA=BASE_INTEGRIDADE;RUN;PROC DELETE DATA=BASE_OBSERVACAO;RUN;%do i=1 %to &NOBS_BASE;	%put &&nome_base&i.;PROC CONTENTS DATA="+lib+".&&nome_base&i. OUT=BASE_OBS (keep= MEMNAME NAME TYPE LENGTH NOBS) NOPRINT;	RUN;DATA BASE_INTEGRIDADE_AUX (KEEP= NAME LENGTH TYPE ID);		SET work.BASE_OBS;		ID = &i.;	RUN;PROC APPEND BASE=BASE_INTEGRIDADE DATA=BASE_INTEGRIDADE_AUX FORCE;DATA BASE_OBSERVACAO_AUX (KEEP= MEMNAME NOBS);		SET work.BASE_OBS;	RUN;PROC APPEND BASE=BASE_OBSERVACAO DATA=BASE_OBSERVACAO_AUX FORCE;%end;%mend GerarLista;%GerarLista;PROC SORT DATA=BASE_OBSERVACAO NODUPKEY;BY MEMNAME;RUN;PROC DELETE DATA=BASE_INTEGRIDADE_AUX;RUN;PROC DELETE DATA=BASE_OBSERVACAO_AUX;RUN;PROC DELETE DATA=Lista_Bases;RUN;PROC DELETE DATA=BASE_OBS;RUN;");
			}
			 
			if (log.contains("ERROR")) {
				System.out.println(log);
			}
		} catch (GenericError e) {
			e.printStackTrace();
		}
	}
	
	public void gerarBases2(String lib, String bases) {
		//System.out.println("ods output Members=Lista_Bases;proc datasets library=INTEG memtype=data;run;data Lista_Bases_Integridade (keep= Name WHERE = (NAME in " + bases + "));SET work.Lista_Bases;RUN;DATA _NULL_;SET WORK.Lista_Bases_Integridade;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);	CALL SYMPUT('NOBS_BASE',_N_);RUN;%PUT NOBS_BASE: &NOBS_BASE.;%macro GerarLista();PROC DELETE DATA=BASE_INTEGRIDADE;RUN;PROC DELETE DATA=BASE_OBSERVACAO;RUN;%do i=1 %to &NOBS_BASE;	%put &&nome_base&i.;PROC CONTENTS DATA=INTEG.&&nome_base&i. OUT=BASE_OBS (keep= MEMNAME NAME TYPE LENGTH NOBS) NOPRINT;	RUN;DATA BASE_INTEGRIDADE_AUX (KEEP= NAME LENGTH TYPE ID);		SET work.BASE_OBS;		ID = &i.;	RUN;PROC APPEND BASE=BASE_INTEGRIDADE DATA=BASE_INTEGRIDADE_AUX FORCE;DATA BASE_OBSERVACAO_AUX (KEEP= MEMNAME NOBS);		SET work.BASE_OBS;	RUN;PROC APPEND BASE=BASE_OBSERVACAO DATA=BASE_OBSERVACAO_AUX FORCE;%end;%mend GerarLista;%GerarLista;PROC SORT DATA=BASE_OBSERVACAO NODUPKEY;BY MEMNAME;RUN;PROC DELETE DATA=BASE_INTEGRIDADE_AUX;RUN;PROC DELETE DATA=BASE_OBSERVACAO_AUX;RUN;PROC DELETE DATA=Lista_Bases;RUN;PROC DELETE DATA=BASE_OBS;RUN;");
		String log = null;
		
		if (!bases.contains("\"")) {
			bases = "\"" + bases + "\"";
		}
		
		try {
			if (lib.length() > 9) { 
				log = ComandoSAS("libname INTEG " + lib + ";");

				System.out.println("ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY=INTEG MEMTYPE=DATA;RUN;DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + bases + ")));SET WORK.LISTA_BASES;RUN;DATA _NULL_;SET WORK.LISTA_BASES_INTEGRIDADE;CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;%PUT NOBS_OBS: &NOBS_OBS.;");
				log += ComandoSAS("ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY=INTEG MEMTYPE=DATA;RUN;DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + bases + ")));SET WORK.LISTA_BASES;RUN;DATA _NULL_;SET WORK.LISTA_BASES_INTEGRIDADE;CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;%PUT NOBS_OBS: &NOBS_OBS.;");
				System.out.println("%MACRO GERARLISTA();PROC DELETE DATA=WORK.BASE_INTEGRIDADE;RUN;PROC DELETE DATA=WORK.BASE_VAZIA_FINAL;RUN;%DO I=1 %TO &NOBS_OBS;%PUT &&NOME_BASE&I.;DATA _NULL_;IF 0 THEN SET INTEG.&&NOME_BASE&I. NOBS=N;CALL SYMPUTX('NOBS_BASE',N);STOP;RUN;%PUT NOBS_BASE : &NOBS_BASE.;%IF &NOBS_BASE. > 0 %THEN%DO;PROC CONTENTS DATA=INTEG.&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT;RUN;PROC SORT DATA=BASE_OBS OUT=BASE_OBS;BY NAME;RUN;DATA BASE_INTEGRIDADE_TEMP;SET WORK.BASE_OBS;ID = &I.;RUN;PROC APPEND BASE=BASE_INTEGRIDADE DATA=BASE_INTEGRIDADE_TEMP FORCE;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 1;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%ELSE%DO;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 0;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%END;%MEND GERARLISTA;%GERARLISTA;PROC DELETE DATA=WORK.BASE_INTEGRIDADE_TEMP;RUN;PROC DELETE DATA=WORK.BASE_OBS;RUN;PROC DELETE DATA=WORK.LISTA_BASES;RUN;PROC DELETE DATA=BASE_VAZIA;RUN;");
				log += ComandoSAS("%MACRO GERARLISTA();PROC DELETE DATA=WORK.BASE_INTEGRIDADE;RUN;PROC DELETE DATA=WORK.BASE_VAZIA_FINAL;RUN;%DO I=1 %TO &NOBS_OBS;%PUT &&NOME_BASE&I.;DATA _NULL_;IF 0 THEN SET INTEG.&&NOME_BASE&I. NOBS=N;CALL SYMPUTX('NOBS_BASE',N);STOP;RUN;%PUT NOBS_BASE : &NOBS_BASE.;%IF &NOBS_BASE. > 0 %THEN%DO;PROC CONTENTS DATA=INTEG.&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT;RUN;PROC SORT DATA=BASE_OBS OUT=BASE_OBS;BY NAME;RUN;DATA BASE_INTEGRIDADE_TEMP;SET WORK.BASE_OBS;ID = &I.;RUN;PROC APPEND BASE=BASE_INTEGRIDADE DATA=BASE_INTEGRIDADE_TEMP FORCE;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 1;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%ELSE%DO;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 0;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%END;%MEND GERARLISTA;%GERARLISTA;PROC DELETE DATA=WORK.BASE_INTEGRIDADE_TEMP;RUN;PROC DELETE DATA=WORK.BASE_OBS;RUN;PROC DELETE DATA=WORK.LISTA_BASES;RUN;PROC DELETE DATA=BASE_VAZIA;RUN;");
			} else {		
				System.out.println("ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY="+lib+" MEMTYPE=DATA;RUN;DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + bases + ")));SET WORK.LISTA_BASES;RUN;DATA _NULL_;SET WORK.LISTA_BASES_INTEGRIDADE;CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;%PUT NOBS_OBS: &NOBS_OBS.;");
				log += ComandoSAS("ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY="+lib+" MEMTYPE=DATA;RUN;DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + bases + ")));SET WORK.LISTA_BASES;RUN;DATA _NULL_;SET WORK.LISTA_BASES_INTEGRIDADE;CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;%PUT NOBS_OBS: &NOBS_OBS.;");
				System.out.println("%MACRO GERARLISTA();PROC DELETE DATA=WORK.BASE_INTEGRIDADE;RUN;PROC DELETE DATA=WORK.BASE_VAZIA_FINAL;RUN;%DO I=1 %TO &NOBS_OBS;%PUT &&NOME_BASE&I.;DATA _NULL_;IF 0 THEN SET "+lib+".&&NOME_BASE&I. NOBS=N;CALL SYMPUTX('NOBS_BASE',N);STOP;RUN;%PUT NOBS_BASE : &NOBS_BASE.;%IF &NOBS_BASE. > 0 %THEN%DO;PROC CONTENTS DATA="+lib+".&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT;RUN;PROC SORT DATA=BASE_OBS OUT=BASE_OBS;BY NAME;RUN;DATA BASE_INTEGRIDADE_TEMP;SET WORK.BASE_OBS;ID = &I.;RUN;PROC APPEND BASE=BASE_INTEGRIDADE DATA=BASE_INTEGRIDADE_TEMP FORCE;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 1;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%ELSE%DO;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 0;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%END;%MEND GERARLISTA;%GERARLISTA;PROC DELETE DATA=WORK.BASE_INTEGRIDADE_TEMP;RUN;PROC DELETE DATA=WORK.BASE_OBS;RUN;PROC DELETE DATA=WORK.LISTA_BASES;RUN;PROC DELETE DATA=BASE_VAZIA;RUN;");
				log += ComandoSAS("%MACRO GERARLISTA();PROC DELETE DATA=WORK.BASE_INTEGRIDADE;RUN;PROC DELETE DATA=WORK.BASE_VAZIA_FINAL;RUN;%DO I=1 %TO &NOBS_OBS;%PUT &&NOME_BASE&I.;DATA _NULL_;IF 0 THEN SET "+lib+".&&NOME_BASE&I. NOBS=N;CALL SYMPUTX('NOBS_BASE',N);STOP;RUN;%PUT NOBS_BASE : &NOBS_BASE.;%IF &NOBS_BASE. > 0 %THEN%DO;PROC CONTENTS DATA="+lib+".&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT;RUN;PROC SORT DATA=BASE_OBS OUT=BASE_OBS;BY NAME;RUN;DATA BASE_INTEGRIDADE_TEMP;SET WORK.BASE_OBS;ID = &I.;RUN;PROC APPEND BASE=BASE_INTEGRIDADE DATA=BASE_INTEGRIDADE_TEMP FORCE;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 1;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%ELSE%DO;DATA BASE_VAZIA;NOME = \"&&NOME_BASE&I.\";VAZIA = 0;RUN;PROC APPEND BASE=WORK.BASE_VAZIA_FINAL DATA=WORK.BASE_VAZIA FORCE;%END;%END;%MEND GERARLISTA;%GERARLISTA;PROC DELETE DATA=WORK.BASE_INTEGRIDADE_TEMP;RUN;PROC DELETE DATA=WORK.BASE_OBS;RUN;PROC DELETE DATA=WORK.LISTA_BASES;RUN;PROC DELETE DATA=BASE_VAZIA;RUN;");
			}
			if (log.contains("ERROR")) {
				System.out.println(log);
			}
			
		} catch (GenericError e) {
			e.printStackTrace();
		}
	}
	
	public List<ColunaTabela> getLayoutBaseSAS(String lib, String base){
		String log = "";
		List<ColunaTabela> colunasLayout = new ArrayList();
		if (!base.contains("\"")) {
			base = "\"" + base + "\"";
		}
		try {
			String comando1 = "";
			String comando2 = "";
			if (lib.length() > 9) { 
				log = ComandoSAS("LIBNAME INTEG '" + lib + "';");
				comando1 = "ODS OUTPUT MEMBERS=LISTA_BASES; PROC DATASETS LIBRARY=INTEG MEMTYPE=DATA; RUN; DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + base + "))); SET WORK.LISTA_BASES; count + 1; RUN; DATA _NULL_; SET WORK.LISTA_BASES_INTEGRIDADE; CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME); CALL SYMPUT('NOBS_OBS',_N_); RUN; %PUT NOBS_OBS: &NOBS_OBS.;";
				comando2 = "%MACRO GERARLISTA(); PROC DELETE DATA=WORK.BASE_INTEGRIDADE; RUN; PROC DELETE DATA=WORK.BASE_VAZIA_FINAL; RUN; %DO I=1 %TO &NOBS_OBS; %PUT &&NOME_BASE&I.; DATA _NULL_; IF 0 THEN SET INTEG.&&NOME_BASE&I. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE : &NOBS_BASE.; %IF &NOBS_BASE. > 0 %THEN %DO; PROC CONTENTS DATA=INTEG.&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT; RUN; PROC SORT DATA=BASE_OBS OUT=BASE_OBS; BY NAME; RUN; %END; %ELSE%DO; %END; %END; %MEND GERARLISTA; %GERARLISTA;";
			} else {
				comando1 = "ODS OUTPUT MEMBERS=LISTA_BASES; PROC DATASETS LIBRARY="+lib+" MEMTYPE=DATA; RUN; DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + base + "))); SET WORK.LISTA_BASES; count + 1; RUN; DATA _NULL_; SET WORK.LISTA_BASES_INTEGRIDADE; CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME); CALL SYMPUT('NOBS_OBS',_N_); RUN; %PUT NOBS_OBS: &NOBS_OBS.;";
				comando2 = "%MACRO GERARLISTA(); PROC DELETE DATA=WORK.BASE_INTEGRIDADE; RUN; PROC DELETE DATA=WORK.BASE_VAZIA_FINAL; RUN; %DO I=1 %TO &NOBS_OBS; %PUT &&NOME_BASE&I.; DATA _NULL_; IF 0 THEN SET "+lib+".&&NOME_BASE&I. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE : &NOBS_BASE.; %IF &NOBS_BASE. > 0 %THEN %DO; PROC CONTENTS DATA="+lib+".&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT; RUN; PROC SORT DATA=BASE_OBS OUT=BASE_OBS; BY NAME; RUN; %END; %ELSE%DO; %END; %END; %MEND GERARLISTA; %GERARLISTA;";
			}
			/*
			System.out.println("LIBNAME INTEG " + lib + ";");
			System.out.println(comando1);
			System.out.println(comando2);
			*/
			
			log += ComandoSAS(comando1);
			log += ComandoSAS(comando2);
			if(log.contains("ERROR")) {
				System.out.println(log);
			}else {
				ResultSet rs;
				statement = connection.createStatement();
				rs = statement.executeQuery("SELECT NAME, TYPE, LENGTH FROM WORK.BASE_OBS ORDER BY 1");
			    
			    while(rs.next()) {
			    	ColunaTabela col = new ColunaTabela();
			    	col.setNomeColuna(rs.getString("NAME").trim());
			    	col.setTipoColuna(rs.getInt("TYPE"));
			    	col.setTamanhoColuna(rs.getInt("LENGTH"));
			    	colunasLayout.add(col);
			    }
			    
			}
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		return colunasLayout;
	}
	
	public List<ColunaTabela> getLayoutBaseSAScontador(String lib, String base, int contador){
		String log = "";
		List<ColunaTabela> colunasLayout = new ArrayList();
		if (!base.contains("\"")) {
			base = "\"" + base + "\"";
		}
		try {
			String comando1 = "";
			String comando2 = "";
			if (lib.length() > 9) { 
				log = ComandoSAS("LIBNAME INTEG '" + lib + "';");
				comando1 = "ODS OUTPUT MEMBERS=LISTA_BASES; PROC DATASETS LIBRARY=INTEG MEMTYPE=DATA; RUN; DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + base + "))); SET WORK.LISTA_BASES; count + 1; RUN; DATA _NULL_; SET WORK.LISTA_BASES_INTEGRIDADE; CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME); CALL SYMPUT('NOBS_OBS',_N_); RUN; %PUT NOBS_OBS: &NOBS_OBS.;";
				comando2 = "%MACRO GERARLISTA(); PROC DELETE DATA=WORK.BASE_INTEGRIDADE; RUN; PROC DELETE DATA=WORK.BASE_VAZIA_FINAL; RUN; %DO I=1 %TO &NOBS_OBS; %PUT &&NOME_BASE&I.; DATA _NULL_; IF 0 THEN SET INTEG.&&NOME_BASE&I. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE : &NOBS_BASE.; %IF &NOBS_BASE. >= 0 %THEN %DO; PROC CONTENTS DATA=INTEG.&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT; RUN; PROC SORT DATA=BASE_OBS OUT=BASE_OBS"+contador+"; BY NAME; RUN; %END; %ELSE%DO; %END; %END; %MEND GERARLISTA; %GERARLISTA;";
			} else {
				comando1 = "ODS OUTPUT MEMBERS=LISTA_BASES; PROC DATASETS LIBRARY="+lib+" MEMTYPE=DATA; RUN; DATA LISTA_BASES_INTEGRIDADE (KEEP= NAME WHERE = (NAME in (" + base + "))); SET WORK.LISTA_BASES; count + 1; RUN; DATA _NULL_; SET WORK.LISTA_BASES_INTEGRIDADE; CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME); CALL SYMPUT('NOBS_OBS',_N_); RUN; %PUT NOBS_OBS: &NOBS_OBS.;";
				comando2 = "%MACRO GERARLISTA(); PROC DELETE DATA=WORK.BASE_INTEGRIDADE; RUN; PROC DELETE DATA=WORK.BASE_VAZIA_FINAL; RUN; %DO I=1 %TO &NOBS_OBS; %PUT &&NOME_BASE&I.; DATA _NULL_; IF 0 THEN SET "+lib+".&&NOME_BASE&I. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE : &NOBS_BASE.; %IF &NOBS_BASE. >= 0 %THEN %DO; PROC CONTENTS DATA="+lib+".&&NOME_BASE&I. OUT=BASE_OBS (KEEP= NAME TYPE LENGTH) NOPRINT; RUN; PROC SORT DATA=BASE_OBS OUT=BASE_OBS"+contador+"; BY NAME; RUN; %END; %ELSE%DO; %END; %END; %MEND GERARLISTA; %GERARLISTA;";
			}
			/*
			System.out.println("LIBNAME INTEG " + lib + ";");
			System.out.println(comando1);
			System.out.println(comando2);
			*/
			
			log += ComandoSAS(comando1);
			log += ComandoSAS(comando2);
			if(log.contains("ERROR")) {
				System.out.println(log);
			}else {
				ResultSet rs;
				statement = connection.createStatement();
				rs = statement.executeQuery("SELECT * FROM WORK.BASE_OBS"+contador+" ORDER BY 1");
			    
			    while(rs.next()) {
			    	ColunaTabela col = new ColunaTabela();
			    	col.setNomeColuna(rs.getString("NAME").trim());
			    	col.setTipoColuna(rs.getInt("TYPE"));
			    	col.setTamanhoColuna(rs.getInt("LENGTH"));
			    	colunasLayout.add(col);
			    }
			    
			}
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		return colunasLayout;
	}
	
	//pega todas as bases novas do sas que chegaram depois da data limite.
	public ArrayList<ArrayList<String>> getNovasBasesSAS(String dataLimite) {
		try {
			statement = connection.createStatement();
			// tb1.MODATE < '13JUL18:16:00:00'dt and
			String queryString = "PROC SQL; CREATE TABLE WORK.TESTE AS select DISTINCT tb1.memname as NOME_BASE, tb1.libname AS LIB_NAME, tb2.path as CAMINHO, tb1.MEMTYPE, tb1.BUFSIZE, tb1.MEMLABEL, tb1.crdate AS DT_CRIACAO, tb1.modate as DT_MODIFICACAO, tb2.SYSDESC, tb2.SYSNAME, tb2.SYSVALUE, tb2.temp from dictionary.tables tb1 LEFT JOIN dictionary.LIBNAMES tb2 ON(tb1.libname = tb2.libname) WHERE tb1.MODATE > '"+dataLimite+"'dt and tb2.sysname = 'Filename' AND temp = 'no' AND tb2.libname not in(\"MAPS\",\"MAPSGFK\",\"MAPSSAS\",\"SASHELP\",\"SASUSER\",\"WORK\") order by tb1.MODATE desc ; QUIT;" +
			"DATA BASE_DOMINIOS; SET WORK.TESTE (KEEP=NOME_BASE LIB_NAME); DO I=1 BY 1 WHILE(SCAN(NOME_BASE,I,'_') ^= ' '); NOME = SCAN(NOME_BASE,I,'_'); LEN = LENGTHN(NOME); NEWVAL = COMPRESS(NOME,\".\",'D'); LEN2 = LENGTHN(NEWVAL); IF LEN2 NE 0 THEN FLAG = 0; ELSE FLAG = 1; END; RUN; DATA BASES_SAFRAS; SET BASE_DOMINIOS; LEN_NOME_BASE = LENGTHN(NOME_BASE); LEN_NOME = LENGTHN(NOME); LEN_TOTAL = LEN_NOME_BASE - LEN_NOME; SUB_NOME_BASE = SUBSTR(NOME_BASE,1,LEN_TOTAL); FULL_INCREMENTAL = \"FULL\"; SAFRADA = 0; IF LEN > 6 THEN DO; SUB_NOME_BASE_COMP = COMPRESS(SUB_NOME_BASE || \"AAAAMMDD\"); PERIODICIDADE = \"Di�ria\"; END; ELSE IF LEN = 6 THEN DO; SUB_NOME_BASE_COMP = COMPRESS(SUB_NOME_BASE || \"AAAAMM\"); PERIODICIDADE = \"Mensal\"; END; IF FLAG = 1 THEN OUTPUT; RUN; PROC SORT DATA=BASES_SAFRAS(KEEP=SUB_NOME_BASE_COMP NOME_BASE LIB_NAME FULL_INCREMENTAL PERIODICIDADE SAFRADA) OUT=BASES_COM_SAFRAS NODUPKEY; BY SUB_NOME_BASE_COMP; RUN; DATA BASES_SEM_SAFRAS; SET BASE_DOMINIOS; FULL_INCREMENTAL = \"FULL\"; PERIODICIDADE = \"Di�ria\"; SAFRADA = 1; IF FLAG = 0 THEN OUTPUT; RUN; PROC SORT DATA=BASES_SEM_SAFRAS(KEEP=NOME_BASE LIB_NAME FULL_INCREMENTAL PERIODICIDADE SAFRADA) OUT=BASES_SEM_SAFRAS NODUPKEY; BY NOME_BASE; RUN; DATA BASES(KEEP=SUB_NOME_BASE_COMP NOME_BASE LIB_NAME FULL_INCREMENTAL PERIODICIDADE SAFRADA); SET BASES_SEM_SAFRAS BASES_COM_SAFRAS; RUN; DATA BASES; SET BASES; IF SUB_NOME_BASE_COMP = \"\" THEN SUB_NOME_BASE_COMP = NOME_BASE; RUN;";
			
			System.out.println(queryString);
			
			try {
				ComandoSAS(queryString);
			} catch (GenericError e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			result = statement.executeQuery("SELECT SUB_NOME_BASE_COMP, NOME_BASE, LIB_NAME, FULL_INCREMENTAL, PERIODICIDADE, SAFRADA FROM WORK.BASES_CADASTRO");
			ArrayList<ArrayList<String>> table;
		    int columnCount = result.getMetaData().getColumnCount();
		     
		    if(result.getType() == ResultSet.TYPE_FORWARD_ONLY) 
		        table = new ArrayList<ArrayList<String>>();
		    else {  
		        result.last();
		        table = new ArrayList<ArrayList<String>>(result.getRow());
		        result.beforeFirst();
		    }
		 
		    for(ArrayList<String> row; result.next(); table.add(row)) {
		        row = new ArrayList<String>(columnCount);
		 
		        for(int c = 1; c <= columnCount; ++ c)
		            row.add(result.getString(c).intern());
		    }
		     
		    return table;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeResources();
		}
		return null;
	}
	
	
	/**
	 * Fechar resultset e statement.
	 */
	protected void closeResources() {
		if(result != null) {
			try {
				result.close();
			} catch(Exception except) {
				System.out.println("Falha ao fechar ResultSet: " + except.getMessage());
			} finally {
				result = null;
			}
		}
		if(statement != null) {
			try {
				statement.close();
			} catch(Exception except) {
				System.out.println("Falha ao fechar Statement: " + except.getMessage());
			} finally {
				statement = null;
			}
		}					
	}
}
