package conectores;


//interface que todos os conectores devem implementar, para permitir a cria��o de m�todos gen�ricos baseados na interface
public interface Iconectores {
	
	public void iniciar();
	public void encerrar();
}

