package controllers;

import java.io.IOException;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class addContatoServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		response.addHeader("Access-Control-Allow-Origin", "*");
		RequestDispatcher rd;
		rd = request.getRequestDispatcher("/WEB-INF/View/adiciona-contato.jsp");
		System.out.println("testando GET 444");
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		response.addHeader("Access-Control-Allow-Origin", "*");
		System.out.println("Testando Post 1234");
		
		String name = request.getParameter("name");
		PrintWriter out = response.getWriter();
		
		response.setContentType("text/plain");
	    response.setCharacterEncoding("UTF-8"); 
	    out.write("the contact's name is: " + name);
	}
}
