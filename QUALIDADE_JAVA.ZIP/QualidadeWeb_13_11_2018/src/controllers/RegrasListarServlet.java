package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.RegraDAO;
import model.Base;
import model.Regra;
import model.Resposta;

public class RegrasListarServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		RequestDispatcher rd;
		
		List<Regra> listaRegras;
		listaRegras = listarRegrasDetalhes();
		
		request.setAttribute("listaDeRegras", listaRegras);
		
		
		rd = request.getRequestDispatcher("/WEB-INF/View/regrasListar.jsp");
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		
		String idString =request.getParameter("idString");
		int idTb = Integer.parseInt(idString.split(";")[0]);
		int idCol = Integer.parseInt(idString.split(";")[1]);
		int idRegra = Integer.parseInt(idString.split(";")[2]);
		Resposta resposta = new Resposta();
		
		if(idRegra == 6) { //duplicidade
			
			String[] multIds = request.getParameter("multIds").split(",");
			for(String id : multIds) {
				int idColInt = Integer.parseInt(id.trim());
				resposta = deletarRegraPorId(idRegra, idColInt, idTb);
			}
			System.out.println("MULTIDS: " + multIds);
			
		}else{ //demais
			
			System.out.println("demais");
			resposta = deletarRegraPorId(idRegra, idCol, idTb);
		}
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
	    response.setCharacterEncoding("UTF-8");
	    out.write(resposta.getMensagem()+";"+resposta.getTipo());
		
	}
	
	public List<Regra> listarRegrasDetalhes() {
		GerenciadorDeConexao sqlServer = null;
		List<Regra> regras = new ArrayList();
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			regras = regraDAO.listarRegrasDetalhes();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return regras;
	}
	
	//deleta uma regra, apartir de seu ID
	private Resposta deletarRegraPorId(int idRegra, int idCol, int idTb) {
		Resposta resp = new Resposta();
		GerenciadorDeConexao sqlServer = null;		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			resp = regraDAO.deletarRegraPorId(idRegra, idCol, idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resp;
	}
}
