package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import model.Base;
import model.Resposta;

public class BasesListarServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		
		RequestDispatcher rd;
		
		//listarTodos() - listar todas as bases cadastradas
		List<Base> listaBases;
		listaBases = listarTodos();
		
		request.setAttribute("listaDeBases", listaBases);
		
		rd = request.getRequestDispatcher("/WEB-INF/View/basesListar.jsp");
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		
		int idBase = Integer.parseInt(request.getParameter("idBase"));
		Resposta resposta = deletarBasePeloId(idBase);
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
	    response.setCharacterEncoding("UTF-8");
	    out.write(resposta.getMensagem()+";"+resposta.getTipo());
	}

	//lista todas as bases cadastradas, futuramente o metodo deve ser filtrado por usu�rio
	private List<Base> listarTodos(){
		GerenciadorDeConexao sqlServer = null;
		List<Base> listaBases;
		listaBases = new ArrayList();
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			listaBases = baseDAO.listarTodos();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return listaBases;
		
	}
	
	private Resposta deletarBasePeloId(int idTb) {
		Resposta resposta = new Resposta();
		GerenciadorDeConexao sqlServer = null;		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resposta = baseDAO.deletarBasePeloId(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		return resposta;
	}
}
