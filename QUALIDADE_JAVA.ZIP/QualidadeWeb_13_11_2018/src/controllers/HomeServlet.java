package controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.plaf.synth.SynthSeparatorUI;

import DAO.DAOException;
import DAO.GerenciadorDeConexao;
import DAO.tabelaXDAO;
import model.ModeloX;


public class HomeServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		RequestDispatcher rd;
		
//		ModeloX mx, mx2, mx3, mx4, mx5;
//		
//		//Select por ID
//		mx = new ModeloX();
//		mx = getObjetoPorId(2);
//		if(mx != null) { //se o objeto � nulo, n�o foi encontrado objeto com este ID
//			System.out.println(mx.getDesc());
//			System.out.println(mx.getId());
//		}else {
//			System.out.println("N�o foi encontrado objeto com esse Id!");
//		}
		
		rd = request.getRequestDispatcher("/WEB-INF/View/home.jsp");
		
		//INSERINDO
		/*
		mx2 = new ModeloX();
		mx2.setDesc("Uma descricao qualquer");
		mx2.setVal(20.20f);
		System.out.println(inserir(mx2)); //retorno do metodo � a resposta
		*/
		
		
		//UPDATE
		/*
		mx3 = new ModeloX();
		mx3.setId(3);
		mx3.setDesc("NOVA DESC ATUALIZADA");
		mx3.setVal(66.66f);
		System.out.println(atualizar(mx3));
		*/
		
		//DELETE
		/*
		System.out.println(deletar(4));
		*/
		
		
		//Listar Todos
		/*
		List<ModeloX> listaObjetos;
		listaObjetos = listarTodos();
		
		for(ModeloX obj : listaObjetos){
			System.out.println("ObjetoID: " + obj.getId() + " Descri��o do objeto: " + obj.getDesc() + 
					" Valor do obejto: " + obj.getVal());
		}
		
		request.setAttribute("listaRegistros", listaObjetos);
		*/
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	private ModeloX getObjetoPorId(int id) { //retorna um objeto a partir de um ID
		
		ModeloX mx = new ModeloX();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); //abrindo a conex�o
			tabelaXDAO tbx = sqlServer.getObjetoX();
			mx = tbx.objetoPorId(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		return mx;
	}
	
	private String inserir(ModeloX mx) {
		
		String resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); //abrindo a conex�o
			tabelaXDAO tbx = sqlServer.getObjetoX();
			resposta = tbx.inserir(mx); //resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resposta;
	}
	
	private String atualizar(ModeloX mx) {
		
		String resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); //abrindo a conex�o
			tabelaXDAO tbx = sqlServer.getObjetoX();
			resposta = tbx.atualizar(mx); //resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resposta;
	}
	
	private String deletar(int id) {
		
		String resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); //abrindo a conex�o
			tabelaXDAO tbx = sqlServer.getObjetoX();
			resposta = tbx.deletar(id); //resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resposta;
	}
	
	private List<ModeloX> listarTodos(){
		GerenciadorDeConexao sqlServer = null;
		List<ModeloX> listaObjetos;
		listaObjetos = new ArrayList();
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			tabelaXDAO tbx = sqlServer.getObjetoX();
			listaObjetos = tbx.listarTodos();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		return listaObjetos;
		
	}
}


