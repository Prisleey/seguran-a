package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import model.Resposta;
import model.ServidorSAS;
import model.Setor;

public class SetoresListar extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		
		RequestDispatcher rd;
		
		rd = request.getRequestDispatcher("/WEB-INF/View/setoresListar.jsp");
		
		//listar setores SAS
		List<Setor> listaSetores;
		listaSetores = listarSetores();
		
		request.setAttribute("listaSetores", listaSetores);
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
		response.setCharacterEncoding("UTF-8"); 
		
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println("o id que vai ser apagado �: " + id);
		Resposta resp = new Resposta();
		resp = deletarSetorPorId(id);
		
		out.write(resp.getMensagem() + ";" + resp.getTipo());
		
	}
	
	public List<Setor> listarSetores(){
		GerenciadorDeConexao sqlServer;
		List<Setor> listaSetores;
		listaSetores = new ArrayList();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		listaSetores = baseDAO.listarSetores();
		sqlServer.encerrar();
		
		return listaSetores;
	}
	
	// deleta um Setor, desde que n�o haja nenhuma base conectada com ele por Foreign Key
	public Resposta deletarSetorPorId(int idSetor) {
		GerenciadorDeConexao sqlServer = null;
		Resposta resp = new Resposta();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		resp = baseDAO.deletarSetorPorId(idSetor);
		sqlServer.encerrar();
		
		return resp;
	}

}
