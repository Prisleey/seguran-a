package controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.GerenciadorDeConexao;
import DAO.ObservacaoDAO;
import model.Base;

public class ListaObservacaoServlet extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		
		RequestDispatcher rd;
		
		rd = request.getRequestDispatcher("/WEB-INF/View/ListaObservacao.jsp");
		
		List<Base> listaDeBases = listarBasesObs();
		System.out.println("chegou aqui:" + listaDeBases.get(0).getNomeBase());
		request.setAttribute("listaBases", listaDeBases);
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private List<Base> listarBasesObs() {
		
		GerenciadorDeConexao sqlServer = null;
		List<Base> listaBases = new ArrayList();
		try {
			sqlServer = new GerenciadorDeConexao();			
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			listaBases = obsDAO.listarBasesObs();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return listaBases;
		
		
	}
}
