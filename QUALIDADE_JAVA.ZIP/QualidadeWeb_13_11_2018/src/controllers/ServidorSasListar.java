package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import model.Base;
import model.Resposta;
import model.ServidorSAS;

//Controller que far� o CRUD dos servidores SAS no SQL Server
public class ServidorSasListar extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		
		RequestDispatcher rd;
		
		//listarTodos() - listar todas as bases cadastradas
		List<ServidorSAS> listaServidoresSAS;
		listaServidoresSAS = listarServidoresSAS();
		
		request.setAttribute("listaServidoresSAS", listaServidoresSAS);
		
		rd = request.getRequestDispatcher("/WEB-INF/View/servidorSasListar.jsp");
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
		response.setCharacterEncoding("UTF-8"); 
		
		int id = Integer.parseInt(request.getParameter("id"));
		System.out.println("o id que vai ser apagado �: " + id);
		Resposta resp = new Resposta();
		resp = deletarServidorSasPorId(id);
		
		out.write(resp.getMensagem() + ";" + resp.getTipo());
		
	}
	
	//lista todas as bases cadastradas, futuramente o metodo deve ser filtrado por usu�rio
	private List<ServidorSAS> listarServidoresSAS(){
		GerenciadorDeConexao sqlServer;
		List<ServidorSAS> listarServidoresSAS;
		listarServidoresSAS = new ArrayList();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		listarServidoresSAS = baseDAO.listarServidoresSAS();
		sqlServer.encerrar();
		
		return listarServidoresSAS;
		
	}
	
	// deleta um servidor SAS e por sua vez uma rela��o "servidor x base"
	private Resposta deletarServidorSasPorId(int idServidor) {
		GerenciadorDeConexao sqlServer = null;
		Resposta resp = new Resposta();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		resp = baseDAO.deletarServidorSasPorId(idServidor);
		sqlServer.encerrar();
		
		return resp;
	}
	
}
