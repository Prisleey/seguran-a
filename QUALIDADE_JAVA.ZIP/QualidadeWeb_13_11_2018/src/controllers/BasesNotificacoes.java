package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import DAO.GerenciadorDeConexao;
import DAO.NotificacaoDAO;
import model.Notificacao;

public class BasesNotificacoes extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		RequestDispatcher rd;
		
		String dtHoje = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
		Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.DATE, -2);
		String dtOntem = new SimpleDateFormat("dd/MM/yyyy").format(cal.getTime());
		
		request.setAttribute("DT_hoje", dtHoje);
		request.setAttribute("DT_ontem", dtOntem);
		
		String dtdeHoje = dtHoje.split("/")[2] + "-" + dtHoje.split("/")[1] + "-" + dtHoje.split("/")[0];
		String dtdeOntem = dtOntem.split("/")[2] + "-" + dtOntem.split("/")[1] + "-" + dtOntem.split("/")[0];
		
		ArrayList<Notificacao> bases = new ArrayList<Notificacao>();
		bases = getBasesNotificacaoporData("0","",-1,dtdeOntem,dtdeHoje);
		
		ArrayList<String[]> metricas = new ArrayList<String[]>();
		metricas = getMetricasNotificacao();
		
		Gson gson = new Gson();
		String json = gson.toJson(bases);
		System.out.println(bases);
		request.setAttribute("Bases", json);
		request.setAttribute("Metricas", metricas);
		
		ArrayList<String> datas = new ArrayList<String>();
		datas = getDataMinMaxNotificacoes();
		
		String[] dtMinMax = new String[2];
		
		dtMinMax[0] = datas.get(0) + " 00:00";
		dtMinMax[1] = datas.get(1) + " 23:59";
		
		request.setAttribute("Datas", dtMinMax);
		
		ArrayList<List> bases_lista = new ArrayList<List>();
		bases_lista = getBasesNotificacao();
		
		request.setAttribute("Bases_lista", bases_lista);
		
		System.out.println("Chegou em Bases Notifica��es");
		
		rd = request.getRequestDispatcher("/WEB-INF/View/basesNotificacoes.jsp");
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		 
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
	    response.setCharacterEncoding("UTF-8"); 
	    
    
	    String nmBase= "";    
	    int idRegra = -1;
		String coluna = "";
		String dtIni = "";
		String dtFim = "";
		
		if (request.getParameter("regra") != null ) {
			idRegra = Integer.parseInt((String) request.getParameter("regra"));
		}
		if (request.getParameter("nmBase") != null ) {
			nmBase= (String)request.getParameter("nmBase");
		}
		if (request.getParameter("dtIni") != null ) {
			dtIni = (String) request.getParameter("dtIni");
		}
		if (request.getParameter("dtFim") != null ) {
			dtFim = (String) request.getParameter("dtFim");
		}
		if (request.getParameter("coluna") != null ) {
			coluna = (String)request.getParameter("coluna");
		}
	    
	    
	    String dtIniForm = dtIni.split("/")[2] + "-" + dtIni.split("/")[1] + "-" + dtIni.split("/")[0];
	    String dtFimForm = dtFim.split("/")[2] + "-" + dtFim.split("/")[1] + "-" + dtFim.split("/")[0];
	    
	    System.out.println("DT INIC: " + dtIni + " DT FIM: " + dtFim);
	    ArrayList<Notificacao> not = new ArrayList<Notificacao>();
		    
		not = getBasesNotificacaoporData(nmBase,coluna, idRegra, dtIniForm,dtFimForm);
	    
	    Gson gson = new Gson();
	    String json = gson.toJson(not);
	    System.out.println(json.length());
	    out.write(json);      // Write response body.
	}
	
	public ArrayList<List> getBasesNotificacao() {
		ArrayList<List> bases = new ArrayList<List>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getBasesNotificacao();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}
	
	public ArrayList<String> getDataMinMaxNotificacoes() {
		ArrayList<String> datas = new ArrayList<String>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			datas = notifDAO.getDataMinMaxNotificacoes();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return datas;
	}

	public ArrayList<Notificacao> getBasesNotificacaoporData(String nmBase, String coluna, int idRegra, String dtIni, String dtFim) {
		ArrayList<Notificacao> notificacoes = new ArrayList<Notificacao>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			notificacoes = notifDAO.getBasesNotificacaoporData(nmBase,coluna,idRegra,dtIni, dtFim);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return notificacoes;
	}
	
	public ArrayList<List> getNomesColunas() {
		ArrayList<List> colunas = new ArrayList<List>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			colunas = notifDAO.getNomesColunas();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return colunas;
	}
	
	
	public ArrayList<List> getNomesMetricas() {
		ArrayList<List> listaNotif = new ArrayList<List>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			listaNotif = notifDAO.getNomesMetricas();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaNotif;
	}
	
	public ArrayList<String[]> getMetricasNotificacao() {
		ArrayList<String[]> metricas = new ArrayList<String[]>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			metricas = notifDAO.getMetricasNotificacao();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return metricas;
	}
	
}
