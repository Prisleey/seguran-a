package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import model.Resposta;
import model.ServidorSAS;
import model.Setor;

public class SetoresCadastrar extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		
		RequestDispatcher rd;
		
		
		if (request.getParameter("id") != null) {
			
			int idSetor = Integer.parseInt(request.getParameter("id"));
			
			System.out.println("id �: " + idSetor);
			
			Setor setor = new Setor();
			
			setor = getSetorPorId(idSetor);
			
			System.out.println("nome do setor: " + setor.getNomeSetor());
			
			request.setAttribute("id", idSetor);
			request.setAttribute("nomeSetor", setor.getNomeSetor());
		}
		
		rd = request.getRequestDispatcher("/WEB-INF/View/setoresCadastrar.jsp");
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
		response.setCharacterEncoding("UTF-8"); 
		
		int id = Integer.parseInt(request.getParameter("id"));
		String nomeSetor = request.getParameter("nomeSetor").trim();
		
		
		Resposta resp = new Resposta();
		if(id > 0) { //update
			resp = updateSetorPorId(id, nomeSetor);
		}else { //insert
			resp = inserirSetor(nomeSetor);
		}
		
		out.write(resp.getMensagem() + ";" + resp.getTipo());
		
	}
	
	
	//Get setor por id_setor, para retrieve antes do update
	public Setor getSetorPorId(int idSetor) {
		GerenciadorDeConexao sqlServer;
		Setor setor = new Setor();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		setor = baseDAO.getSetorPorId(idSetor);
		sqlServer.encerrar();
		
		return setor;
	}
	
	public Resposta updateSetorPorId(int idSetor, String nomeSetor) {
		
		GerenciadorDeConexao sqlServer = null;
		Resposta resp = new Resposta();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		resp = baseDAO.updateSetorPorId(idSetor, nomeSetor);
		sqlServer.encerrar();
		
		return resp;
	}
	
	//insere 1 setor na base SETORES
	public Resposta inserirSetor(String nomeSetor) {
		
		GerenciadorDeConexao sqlServer = null;
		Resposta resp = new Resposta();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		resp = baseDAO.inserirSetor(nomeSetor);
		sqlServer.encerrar();
		
		return resp;
	}
}
