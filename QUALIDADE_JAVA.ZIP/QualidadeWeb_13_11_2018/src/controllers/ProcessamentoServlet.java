package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.ws.BindingProvider;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.google.gson.Gson;
import com.sas.iom.SASIOMDefs.GenericError;
import com.sun.org.apache.xerces.internal.dom.ElementNSImpl;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.NotificacaoDAO;
import DAO.ObservacaoDAO;
import backgroundProcesses.tarefaDiaria;
import conectores.ConectorSAS;
import model.Base;
import model.ColunaTabela;
import model.Observacao;
import sharepoint.ListsRequest;
import sharepoint.GetListItems;
import sharepoint.GetListItemsResponse;
import sharepoint.Lists;
import sharepoint.ListsSoap;

public class ProcessamentoServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		RequestDispatcher rd;

		/*
		 * try { getBasesSAS(); } catch (IOException e1) { e1.printStackTrace(); }
		 */
		rd = request.getRequestDispatcher("/WEB-INF/View/processamento.jsp");
		try {
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String log = "";
		PrintWriter out = response.getWriter();

		try {
			ListsSoap port = sharePointListsAuth();
			ListsRequest listRequest = new ListsRequest();

			String listName = "Qualidade Exemplo";
			String rowLimit = "1";
			ArrayList<String> listColumnNames = new ArrayList<String>();
			listColumnNames.add("NomeBase");
			listColumnNames.add("ID");

			GetListItems getList = new GetListItems();

			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
					.parse(new InputSource(
							new StringReader("<Query>" + "<OrderBy>" + "<FieldRef Name='ID' Ascending=\"FALSE\"/>" + "</OrderBy>" + "</Query>")));

			GetListItems.Query queryxml = new GetListItems.Query();
			queryxml.getContent().add(doc.getDocumentElement());

			doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
					.parse(new InputSource(new StringReader("<QueryOptions>" + "<ViewAttributes Scope='RecursiveAll'/>"
							+ "<DateInUtc>TRUE</DateInUtc>" + "</QueryOptions>")));
			GetListItems.QueryOptions queryxmloptions = new GetListItems.QueryOptions();
			queryxmloptions.getContent().add(doc.getDocumentElement());

			getList.setViewName("");
			getList.setRowLimit(rowLimit);
			getList.setViewFields(null);
			getList.setListName(listName);
			getList.setWebID("");

			// Displays the lists items in the console
			List<HashMap<String, String>> items = displaySharePointList(port, listName, listColumnNames, rowLimit,
					getList, queryxml, queryxmloptions);
			
			String stringid = items.get(0).values().toString().replace("[","").replaceAll("]", "").split(", ")[1];
			
			int id = Integer.parseInt(stringid);

			List<HashMap<String, String>> itemsUpdate = new ArrayList<HashMap<String, String>>();
			
			
			HashMap<String, String> item = new HashMap<String, String>();
			item.put("NomeBase", "OLIVEIRA");
			itemsUpdate.add(item);

			log = listRequest.insertListItem(port, listName, items);
			// request.deleteListItem(port, listName, items);
		
			Gson gson = new Gson();
			String json = gson.toJson(log);
			out.write(json); // Write response body.
			
		} catch (Exception ex) {
			System.err.println(ex);
		}

	}

	public static ListsSoap sharePointListsAuth() throws Exception {
		ListsSoap port = null;
		try {
			Lists service = new Lists();
			port = service.getListsSoap();
			((BindingProvider) port).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
					"http://shp.net.bradesco.com.br/risk/dtm/imi/dq/_vti_bin/Lists.asmx");
		} catch (Exception e) {
			throw new Exception("Error: " + e.toString());
		}
		return port;
	}

	public static List<HashMap<String, String>> displaySharePointList(ListsSoap port, String listName,
			ArrayList<String> listColumnNames, String rowLimit, GetListItems getList, GetListItems.Query queryxml,
			GetListItems.QueryOptions queryxmloptions) throws Exception {

		List<HashMap<String, String>> allitems = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> items = new HashMap<String, String>();

		if (port != null && listName != null && listColumnNames != null && rowLimit != null) {
			try {

				// Calling the List Web Service
				GetListItemsResponse.GetListItemsResult result = port.getListItems(getList.getListName(),
						getList.getViewName(), queryxml, getList.getViewFields(), getList.getRowLimit(),
						queryxmloptions, getList.getWebID());
				Object listResult = result.getContent().get(0);
				if ((listResult != null) && (listResult instanceof ElementNSImpl)) {
					ElementNSImpl node = (ElementNSImpl) listResult;

					NodeList list = node.getElementsByTagName("z:row");

					for (int i = 0; i < list.getLength(); i++) {

						NamedNodeMap attributes = list.item(i).getAttributes();
						items = new HashMap<String, String>();

						for (String columnName : listColumnNames) {
							String internalColumnName = "ows_" + columnName;
							if (attributes.getNamedItem(internalColumnName) != null) {
								System.out.println(
										columnName + ": " + attributes.getNamedItem(internalColumnName).getNodeValue());

								items.put(columnName, attributes.getNamedItem(internalColumnName).getNodeValue());

							} else {
								throw new Exception("Couldn't find the '" + columnName + "' column in the '" + listName
										+ "' list in SharePoint.\n");
							}
						}
						allitems.add(items);
					}
				} else {
					throw new Exception(listName + " list response from SharePoint is either null or corrupt\n");
				}
			} catch (Exception ex) {
				throw new Exception("Exception. See stacktrace." + ex.toString() + "\n");
			}
			return allitems;
		}
		return allitems;
	}

}
