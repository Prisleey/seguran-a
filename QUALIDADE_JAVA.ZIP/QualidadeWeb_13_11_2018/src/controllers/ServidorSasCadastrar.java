package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.RegraDAO;
import model.Regra;
import model.Resposta;
import model.ServidorSAS;


public class ServidorSasCadastrar extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		
		RequestDispatcher rd;
		
		
		if (request.getParameter("id") != null) {
			
			int idServidor = Integer.parseInt(request.getParameter("id"));
			System.out.println("id �: " + idServidor);
			
			ServidorSAS servSAS = new ServidorSAS();
			
			servSAS = getServidorSasById(idServidor);
			
			System.out.println("nome Servidor: " + servSAS.getNomeServidor());
			
			request.setAttribute("id", idServidor);
			request.setAttribute("nomeServidor", servSAS.getNomeServidor());
			request.setAttribute("hostName", servSAS.getHostName());
			request.setAttribute("porta", servSAS.getPorta());
			
		}
		
		
		rd = request.getRequestDispatcher("/WEB-INF/View/servidorSasCadastrar.jsp");
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {

		
			PrintWriter out = response.getWriter();
			response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
			response.setCharacterEncoding("UTF-8"); 
		
			int id = Integer.parseInt(request.getParameter("id"));
			String nomeServidor = request.getParameter("nomeServidor").trim();
			String hostName = request.getParameter("hostName").trim();
			int porta = Integer.parseInt(request.getParameter("porta").trim());
			
			Resposta resp = new Resposta();
			if(id > 0) { //update
				resp = updateServidorSasById(id, nomeServidor, hostName, porta);
			}else { //insert
				resp = inserirServidorSAS(nomeServidor, hostName, porta);
			}
			
			out.write(resp.getMensagem() + ";" + resp.getTipo());
			
		
	}
	
	//edita servidor SAS na base SERVIDORES_SAS
	private Resposta inserirServidorSAS(String nomeServidor, String hostname, int porta) {

		GerenciadorDeConexao sqlServer = null;
		Resposta resp = new Resposta();
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resp = baseDAO.inserirServidorSAS(nomeServidor, hostname, porta);
			sqlServer.encerrar();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resp;
	}
	
	//pega um servidorSAS por ID
	private ServidorSAS getServidorSasById(int idServidor){
		GerenciadorDeConexao sqlServer;
		ServidorSAS servSAS = new ServidorSAS();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		servSAS = baseDAO.getServidorSasByIdWorkSpace(idServidor);
		sqlServer.encerrar();
		
		return servSAS;
			
	}
	
	//edita um servidor sas, baseado no ID fornecido
	public Resposta updateServidorSasById(int idServidor, String nomeServidor, String hostName, int porta) {
		
		GerenciadorDeConexao sqlServer = null;
		Resposta resp = new Resposta();
		
		sqlServer = new GerenciadorDeConexao();
		sqlServer.iniciar();
		BaseDAO baseDAO = sqlServer.getObjetoBase();
		resp = baseDAO.updateServidorSasById(idServidor, nomeServidor, hostName, porta);
		sqlServer.encerrar();
		
		return resp;
		
		
	}
}
