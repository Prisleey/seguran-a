package controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.GerenciadorDeConexao;
import DAO.ObservacaoDAO;
import DAO.RegraDAO;
import model.Observacao;

@SuppressWarnings("serial")
public class BIPSIServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		RequestDispatcher rd;
		
		int idCalc = Integer.parseInt(request.getParameter("idCalc"));
		ArrayList<String[]> linhasTabela = new ArrayList<String[]>();
		String nome = request.getParameter("nome");
		String coluna = request.getParameter("coluna");
		
		request.setAttribute("nomeBase", nome);
		request.setAttribute("nomeColuna", coluna);
				
		linhasTabela = getAmostraPorIDCOL(idCalc);
		request.setAttribute("linhasPSI", linhasTabela);
		
		
		rd = request.getRequestDispatcher("/WEB-INF/View/BIPSI.jsp");
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private ArrayList<String[]> getAmostraPorIDCOL(int idCol) {
		GerenciadorDeConexao sqlServer = null;
		ArrayList<String[]> listaColuna = new ArrayList<String[]>();
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO obsDAO = sqlServer.getObjetoRegraDAO();
			listaColuna = obsDAO.getAmostraPorIDCOL(idCol); 
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return listaColuna;
	}


}

