package controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.GerenciadorDeConexao;
import DAO.ObservacaoDAO;
import DAO.RegraDAO;
import model.Base;

public class ListaPSIServlet extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		
		RequestDispatcher rd;
				
		ArrayList<String[]> listaColunas = listarBasesPSI();
		System.out.println(listaColunas);
		request.setAttribute("listaColunas", listaColunas);
		
		rd = request.getRequestDispatcher("/WEB-INF/View/ListaPSI.jsp");
		
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private ArrayList<String[]> listarBasesPSI() {
		
		GerenciadorDeConexao sqlServer = null;
		ArrayList<String[]> listaColunas = new ArrayList<String[]>();
				
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO obsDAO = sqlServer.getObjetoRegraDAO();
			listaColunas = obsDAO.listarBasesPSI();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return listaColunas;
		
		
	}
}
