package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.NotificacaoDAO;
import DAO.ObservacaoDAO;
import DAO.RegraDAO;
import model.Base;
import model.ColunaTabela;
import model.Observacao;

public class TableauServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		RequestDispatcher rd;

		System.out.println("Chegou em Tableau");
		int idRegra = -1;
		String nomeBase = "";
		String dtIni = "";
		String dtFim = "";

		ArrayList<ArrayList<Object>> listaQtdeNot_Met = new ArrayList<ArrayList<Object>>();
		listaQtdeNot_Met = getMetricas_QtdeNotif(idRegra, nomeBase, dtIni, dtFim);

		ArrayList<ArrayList<Object>> listaQtdeBases = new ArrayList<ArrayList<Object>>();
		listaQtdeBases = getQtdeBasesNotif(idRegra, nomeBase, dtIni, dtFim);

		ArrayList<ArrayList<Object>> listaQtdeAreas = new ArrayList<ArrayList<Object>>();
		listaQtdeAreas = getQtdeNotifAreas(idRegra, nomeBase, dtIni, dtFim);

		ArrayList<List> bases = new ArrayList<List>();
		bases = getBasesNotificacao();

		ArrayList<String[]> metricas = new ArrayList<String[]>();
		metricas = getMetricasNotificacao();

		ArrayList<String[]> dias = new ArrayList<String[]>();
		dias = getQtdeNotiByDia(idRegra, nomeBase, dtIni, dtFim);// jubhiub

		ArrayList<String> datas = new ArrayList<String>();
		datas = getDataMinMaxNotificacoes();

		String[] dtMinMax = new String[2];

		dtMinMax[0] = datas.get(0) + " 00:00";
		dtMinMax[1] = datas.get(1) + " 23:59";

		String[] coresBases = generateColorsBases(listaQtdeBases);
		String[] coresAreas = generateColorsAreas(listaQtdeAreas);
		String[] coresMetricas = generateColorsMetrica(listaQtdeNot_Met);

		int qtdeBasesCadas = getQtdeBasesCadastradas();
		int qtdeColunas = getQtdeColunasCadastradas();
		int qtdeBasesErros = getQtdeErrosBases();
		int qtdeAreasAtend = getQtdeAreasAtendidas();

		request.setAttribute("Qtde_Notif_Metricas", listaQtdeNot_Met);
		request.setAttribute("Qtde_Notif_Bases", listaQtdeBases);
		request.setAttribute("Qtde_Notif_Areas", listaQtdeAreas);
		request.setAttribute("Qtde_Notif_Dias", dias);
		request.setAttribute("Bases", bases);
		request.setAttribute("Metricas", metricas);
		request.setAttribute("CoresMetricas", coresMetricas);
		request.setAttribute("CoresBases", coresBases);
		request.setAttribute("CoresAreas", coresAreas);
		request.setAttribute("qtdeBasesQualidade", qtdeBasesCadas);
		request.setAttribute("qtdeColunasCadas", qtdeColunas);
		request.setAttribute("qtdeBasesErros", qtdeBasesErros);
		request.setAttribute("qtdeAreasatend", qtdeAreasAtend);
		request.setAttribute("Datas", dtMinMax);

		rd = request.getRequestDispatcher("/WEB-INF/View/dashBoardTableau.jsp");
		try {
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
												// expect.
		response.setCharacterEncoding("UTF-8");

		String headerName = request.getHeader("headerAjax").trim();

		if (headerName.equals("porBases")) {

			int idTb = Integer.valueOf(request.getParameter("id"));
			int idRegra = Integer.valueOf(request.getParameter("regra"));

			if (idRegra == 1) {
				List<Object> lista = new ArrayList<Object>();
				List<Observacao> linhasTabela;
				Base base = new Base();
				int tamanho = 0;
				int[] maxmin = new int[2];

				base = getBasePeloID(idTb);
				if (base.getPeriodicidade().equals("Di�ria")) {
					tamanho = 60;
				} else if (base.getPeriodicidade().equals("Mensal")) {
					tamanho = 12;
				} else if (base.getPeriodicidade().equals("Semanal")) {
					tamanho = 36;
				} else if (base.getPeriodicidade().equals("Anual")) {
					tamanho = 60;
				} else if (base.getPeriodicidade().equals("Semestral")) {
					tamanho = 60;
				} else if (base.getPeriodicidade().equals("Trimestral")) {
					tamanho = 60;
				}
				linhasTabela = getAmostraPorID(idTb, tamanho);
				maxmin = getMaxMin(linhasTabela);
				lista.add(idRegra);
				lista.add(linhasTabela);
				lista.add(maxmin);
				Gson gson = new Gson();
				String json = gson.toJson(lista);
				out.write(json); // Write response body.
			} else if (idRegra != 1) {
				List<Object> lista_jsp = new ArrayList<Object>();
				String nomeBase = "";
				String dtIni = "";
				String dtFim = "";
				Base base = getBasePeloID(idTb);
				nomeBase = base.getNomeBase();
				ArrayList<ArrayList<Object>> listaNotif = new ArrayList<ArrayList<Object>>();
				ArrayList<Object> row = new ArrayList<Object>();
				ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();

				ArrayList<String[]> dias = new ArrayList<String[]>();
				dias = getQtdeNotiByDia(idRegra, nomeBase, dtIni, dtFim);

				for (int i = 0; i < dias.size(); i++) {
					row = new ArrayList<Object>();
					row.add(dias.get(i)[0]);
					row.add(dias.get(i)[1]);
					lista.add(row);
				}
				lista_jsp.add(idRegra);
				lista_jsp.add(lista);
				Gson gson = new Gson();
				String json = gson.toJson(lista_jsp);
				out.write(json);
			} else {
				List<Object> lista_jsp = new ArrayList<Object>();
				ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();
				lista_jsp.add(idRegra);
				lista_jsp.add(lista);
				Gson gson = new Gson();
				String json = gson.toJson(lista_jsp);
				out.write(json);
			}

		} else if (headerName.equals("porMetricas")) {

			int idRegra = 0;
			if (request.getParameter("metrica") != null) {
				idRegra = Integer.parseInt(request.getParameter("metrica"));
			} else if (request.getParameter("metrica") == "") {
				idRegra = -1;
			}
			String nomeBase = "";
			String dtIni = "";
			String dtFim = "";

			ArrayList<ArrayList<Object>> listaNotif = new ArrayList<ArrayList<Object>>();
			ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();
			ArrayList<Object> row = new ArrayList<Object>();

			listaNotif = getQtdeBasesNotif(idRegra, nomeBase, dtIni, dtFim);
			String[] coresBases = generateColorsBases(listaNotif);

			for (int i = 0; i < listaNotif.size(); i++) {
				row = new ArrayList<Object>();
				row.add(listaNotif.get(i).get(0));
				row.add(listaNotif.get(i).get(1));
				row.add(listaNotif.get(i).get(2));
				row.add(coresBases[i]);
				lista.add(row);
			}
			Gson gson = new Gson();
			String json = gson.toJson(lista);
			out.write(json); // Write response body.

		} else if (headerName.equals("todosGraficos")) {

			int idRegra = -1;
			String nomeBase = "";
			String dtIni = "";
			String dtFim = "";
			int idTb = 0;

			ArrayList<ArrayList<Object>> listadias_aux = new ArrayList<ArrayList<Object>>();
			ArrayList<Object> row_aux = new ArrayList<Object>();
			ArrayList<String[]> dias = new ArrayList<String[]>();
			ArrayList<Object> listaNotif = new ArrayList<Object>();

			if (request.getParameter("metrica") != null) {
				idRegra = Integer.parseInt((String) request.getParameter("metrica"));
			}
			if (request.getParameter("base") != null) {
				nomeBase = (String) request.getParameter("base");
			}
			if (request.getParameter("dtIni") != null) {
				dtIni = (String) request.getParameter("dtIni");
			}
			if (request.getParameter("dtFim") != null) {
				dtFim = (String) request.getParameter("dtFim");
			}
			if (request.getParameter("id") != null) {
				idTb = Integer.valueOf(request.getParameter("id"));
			}

			if (idRegra == 1 && idTb > 0) {
				List<Object> lista = new ArrayList<Object>();
				List<Observacao> linhasTabela;
				Base base = new Base();
				int tamanho = 0;
				int[] maxmin = new int[2];

				base = getBasePeloID(idTb);
				if (base.getPeriodicidade().equals("Di�ria")) {
					tamanho = 60;
				} else if (base.getPeriodicidade().equals("Mensal")) {
					tamanho = 12;
				} else if (base.getPeriodicidade().equals("Semanal")) {
					tamanho = 36;
				} else if (base.getPeriodicidade().equals("Anual")) {
					tamanho = 60;
				} else if (base.getPeriodicidade().equals("Semestral")) {
					tamanho = 60;
				} else if (base.getPeriodicidade().equals("Trimestral")) {
					tamanho = 60;
				}
				linhasTabela = getAmostraPorID(idTb, tamanho);
				maxmin = getMaxMin(linhasTabela);

				listaNotif.add(idRegra);
				listaNotif.add(linhasTabela);
				listaNotif.add(maxmin);
			} else if (idRegra != 1 && idTb > 0) {
				List<Object> lista_jsp = new ArrayList<Object>();
				Base base = getBasePeloID(idTb);
				nomeBase = base.getNomeBase();

				ArrayList<Object> row = new ArrayList<Object>();
				ArrayList<ArrayList<Object>> lista = new ArrayList<ArrayList<Object>>();

				dias = getQtdeNotiByDia(idRegra, nomeBase, dtIni, dtFim);

				for (int i = 0; i < dias.size(); i++) {
					row = new ArrayList<Object>();
					row.add(dias.get(i)[0]);
					row.add(dias.get(i)[1]);
					lista.add(row);
				}

				listaNotif.add(idRegra);
				listaNotif.add(dias);
			} else if (idRegra < 0 && idTb > 0) {
				dias = getQtdeNotiByDia(idRegra, nomeBase, dtIni, dtFim);
				listaNotif.add(idRegra + 100);
				listaNotif.add(dias);
			} else if (idRegra == 1 && idTb == 0) {
				dias = getQtdeNotiByDia(idRegra, nomeBase, dtIni, dtFim);
				listaNotif.add(idRegra + 100);
				listaNotif.add(dias);
			} else {
				dias = getQtdeNotiByDia(idRegra, nomeBase, dtIni, dtFim);
				listaNotif.add(idRegra);
				listaNotif.add(dias);
			}

			ArrayList<String[]> listaQtdeNotifMet = new ArrayList<String[]>();
			ArrayList<ArrayList<Object>> listaQtdeNot_Met = new ArrayList<ArrayList<Object>>();

			listaQtdeNot_Met = getMetricas_QtdeNotif(idRegra, nomeBase, dtIni, dtFim);
			String[] coresMetricas = generateColorsMetrica(listaQtdeNot_Met);

			String[] row = new String[3];
			for (int i = 0; i < coresMetricas.length; i++) {
				row = new String[3];
				row[0] = String.valueOf(listaQtdeNot_Met.get(i).get(0));
				row[1] = String.valueOf(listaQtdeNot_Met.get(i).get(1));
				row[2] = (coresMetricas[i]);
				listaQtdeNotifMet.add(row);
			}

			ArrayList<String[]> listaBasesNotif = new ArrayList<String[]>();
			ArrayList<ArrayList<Object>> listaQtdeBases = new ArrayList<ArrayList<Object>>();

			listaQtdeBases = getQtdeBasesNotif(idRegra, nomeBase, dtIni, dtFim);
			String[] coresBases = new String[listaQtdeBases.size()];
			if (listaQtdeBases.size() >= 1) {
				coresBases = generateColorsBases(listaQtdeBases);
			}

			for (int i = 0; i < coresBases.length; i++) {
				row = new String[3];
				row[0] = String.valueOf(listaQtdeBases.get(i).get(0));
				row[1] = String.valueOf(listaQtdeBases.get(i).get(1));
				row[2] = (coresBases[i]);
				listaBasesNotif.add(row);
			}

			for (int i = 0; i < dias.size(); i++) {
				row_aux = new ArrayList<Object>();
				row_aux.add(dias.get(i)[0]);
				row_aux.add(dias.get(i)[1]);
				listadias_aux.add(row_aux);
			}

			ArrayList<List> lista = new ArrayList<List>();
			lista.add(listaNotif);
			lista.add(listaBasesNotif);
			lista.add(listaQtdeNotifMet);

			Gson gson = new Gson();
			String json = gson.toJson(lista);
			out.write(json); // Write response body.

		}
	}

	public ArrayList<List> getNomesMetricas() {
		ArrayList<List> listaNotif = new ArrayList<List>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			listaNotif = notifDAO.getNomesMetricas();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaNotif;
	}

	public ArrayList<List> getQtdeNotificacaoPorIDRegra(int idRegra, String nomeBase, String dtIni, String dtFim) {
		ArrayList<List> listaNotifPorRegra = new ArrayList<List>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			listaNotifPorRegra = notifDAO.getQtdeNotificacaoPorIDRegra(idRegra, nomeBase, dtIni, dtFim);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaNotifPorRegra;
	}

	public ArrayList<ArrayList<Object>> getMetricas_QtdeNotif(int idRegra, String nomeBase, String dtIni,
			String dtFim) {
		ArrayList<List> listaNotifPorRegra = new ArrayList<List>();
		listaNotifPorRegra = getQtdeNotificacaoPorIDRegra(idRegra, nomeBase, dtIni, dtFim);

		ArrayList<ArrayList<Object>> listaQtdeMet = new ArrayList<ArrayList<Object>>();
		ArrayList<Object> row = new ArrayList<Object>();

		ArrayList<List> listaMetricas = new ArrayList<List>();
		listaMetricas = getNomesMetricas();

		for (int i = 0; i < listaNotifPorRegra.size(); i++) {
			row = new ArrayList<Object>();
			for (int j = 0; j < listaMetricas.size(); j++) {
				if (listaNotifPorRegra.get(i).get(0).equals(listaMetricas.get(j).get(0))) {
					row.add(listaNotifPorRegra.get(i).get(1));
					row.add(listaMetricas.get(j).get(1));
					listaQtdeMet.add(row);
				}
			}
		}

		return listaQtdeMet;
	}

	public ArrayList<ArrayList<Object>> getQtdeBasesNotif(int idRegra, String nomeBase, String dtIni, String dtFim) {
		ArrayList<ArrayList<Object>> listaNotif = new ArrayList<ArrayList<Object>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			listaNotif = notifDAO.getQtdeBasesNotif(idRegra, nomeBase, dtIni, dtFim);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaNotif;
	}

	public ArrayList<List> getBasesNotificacao() {
		ArrayList<List> bases = new ArrayList<List>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getBasesNotificacao();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<Object>> getNotificacaopelaBase(String nomeBase) {
		ArrayList<ArrayList<Object>> bases = new ArrayList<ArrayList<Object>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacaopelaBase(nomeBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<Object>> getQtdeNotifBase(String base) {
		ArrayList<ArrayList<Object>> listaNotifPorRegra = new ArrayList<ArrayList<Object>>();
		listaNotifPorRegra = getNotificacaopelaBase(base);

		ArrayList<ArrayList<Object>> listaQtdeMet = new ArrayList<ArrayList<Object>>();
		ArrayList<Object> row = new ArrayList<Object>();

		ArrayList<List> listaMetricas = new ArrayList<List>();
		listaMetricas = getNomesMetricas();

		for (int i = 0; i < listaNotifPorRegra.size(); i++) {
			row = new ArrayList<Object>();
			for (int j = 0; j < listaMetricas.size(); j++) {
				if (listaNotifPorRegra.get(i).get(0).equals(listaMetricas.get(j).get(0))) {
					row.add(listaNotifPorRegra.get(i).get(1));
					row.add(listaMetricas.get(j).get(1));
					listaQtdeMet.add(row);
				}
			}
		}

		return listaQtdeMet;
	}

	public String[] generateColorsBases(ArrayList<ArrayList<Object>> lista) {
		String[] colors = new String[lista.size()];
		String cor = "";
		switch (lista.size()) {
		case 1:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			break;
		case 2:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 3:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 128 + "," + 85 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 4:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 153 + "," + 64 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 78 + "," + 127 + "," + 0 + ",1)";
			colors[3] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 5:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 178 + "," + 43 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 128 + "," + 85 + "," + 0 + ",1)";
			colors[3] = "rgba(" + 78 + "," + 127 + "," + 0 + ",1)";
			colors[4] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 6:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 178 + "," + 43 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 128 + "," + 85 + "," + 0 + ",1)";
			colors[3] = "rgba(" + 78 + "," + 127 + "," + 0 + ",1)";
			colors[4] = "rgba(" + 28 + "," + 169 + "," + 0 + ",1)";
			colors[5] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 7:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 203 + "," + 22 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 153 + "," + 64 + "," + 0 + ",1)";
			colors[3] = "rgba(" + 128 + "," + 85 + "," + 0 + ",1)";
			colors[4] = "rgba(" + 78 + "," + 127 + "," + 0 + ",1)";
			colors[5] = "rgba(" + 53 + "," + 148 + "," + 0 + ",1)";
			colors[6] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 8:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 203 + "," + 22 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 153 + "," + 64 + "," + 0 + ",1)";
			colors[3] = "rgba(" + 128 + "," + 85 + "," + 0 + ",1)";
			colors[4] = "rgba(" + 103 + "," + 106 + "," + 0 + ",1)";
			colors[5] = "rgba(" + 78 + "," + 127 + "," + 0 + ",1)";
			colors[6] = "rgba(" + 28 + "," + 169 + "," + 0 + ",1)";
			colors[7] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 9:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 203 + "," + 22 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 178 + "," + 43 + "," + 0 + ",1)";
			colors[3] = "rgba(" + 153 + "," + 64 + "," + 0 + ",1)";
			colors[4] = "rgba(" + 128 + "," + 85 + "," + 0 + ",1)";
			colors[5] = "rgba(" + 78 + "," + 127 + "," + 0 + ",1)";
			colors[6] = "rgba(" + 53 + "," + 148 + "," + 0 + ",1)";
			colors[7] = "rgba(" + 28 + "," + 169 + "," + 0 + ",1)";
			colors[8] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		case 10:
			colors[0] = "rgba(" + 255 + "," + 0 + "," + 0 + ",1)";
			colors[1] = "rgba(" + 203 + "," + 22 + "," + 0 + ",1)";
			colors[2] = "rgba(" + 178 + "," + 43 + "," + 0 + ",1)";
			colors[3] = "rgba(" + 153 + "," + 64 + "," + 0 + ",1)";
			colors[4] = "rgba(" + 128 + "," + 85 + "," + 0 + ",1)";
			colors[5] = "rgba(" + 103 + "," + 106 + "," + 0 + ",1)";
			colors[6] = "rgba(" + 78 + "," + 127 + "," + 0 + ",1)";
			colors[7] = "rgba(" + 53 + "," + 148 + "," + 0 + ",1)";
			colors[8] = "rgba(" + 28 + "," + 169 + "," + 0 + ",1)";
			colors[9] = "rgba(" + 0 + "," + 255 + "," + 0 + ",1)";
			break;
		default:
			System.out.println("N�o h� mais m�tricas");
		}

		return colors;
	}

	public String[] generateColorsAreas(ArrayList<ArrayList<Object>> lista) {

		String[] colors = new String[lista.size()];
		String cor = "";
		for (int i = 0; i < lista.size(); i++) {
			switch ((String) lista.get(i).get(0)) {
			case "DGD":
				cor = "rgba(" + 24 + "," + 61 + "," + 94 + ",1)";
				break;
			case "DPOC":
				cor = "rgba(" + 53 + "," + 130 + "," + 150 + ",1)";
				break;
			case "DCIR":
				cor = "rgba(" + 91 + "," + 109 + "," + 161 + ",1)";
				break;
			case "Cr�dito":
				cor = "rgba(" + 45 + "," + 165 + "," + 170 + ",1)";
				break;
			case "DEF":
				cor = "rgba(" + 117 + "," + 191 + "," + 163 + ",1)";
				break;
			case "DJUR":
				cor = "rgba(" + 0 + "," + 255 + "," + 127 + ",1)";
				break;
			default:
				System.out.println("N�o h� mais m�tricas");
			}
			colors[i] = cor;
		}

		return colors;
	}

	public String[] generateColorsMetrica(ArrayList<ArrayList<Object>> lista) {

		String[] colors = new String[lista.size()];
		String cor = "";
		for (int i = 0; i < lista.size(); i++) {
			switch ((String) lista.get(i).get(1)) {
			case "Integridade":
				cor = "rgba(" + 8 + "," + 27 + "," + 162 + ",1)";
				break;
			case "Range":
				cor = "rgba(" + 20 + "," + 63 + "," + 91 + ",1)";
				break;
			case "Missing":
				cor = "rgba(" + 42 + "," + 82 + "," + 149 + ",1)";
				break;
			case "Observa��o":
				cor = "rgba(" + 45 + "," + 165 + "," + 170 + ",1)";
				break;
			case "Duplicidade":
				cor = "rgba(" + 117 + "," + 191 + "," + 163 + ",1)";
				break;
			case "PSI":
				cor = "rgba(" + 50 + "," + 120 + "," + 255 + ",1)";
				break;
			case "Dom�nio":
				cor = "rgba(" + 0 + "," + 255 + "," + 127 + ",1)";
				break;
			case "Base Vazia":
				cor = "rgba(" + 255 + "," + 50 + "," + 0 + ",1)";
				break;
			default:
				System.out.println("N�o h� mais m�tricas");
			}
			colors[i] = cor;
		}

		return colors;
	}

	public String[] generateColorsMetrica_Dias(ArrayList<String[]> lista) {

		String[] colors = new String[lista.size()];
		String cor = "";
		for (int i = 0; i < lista.size(); i++) {
			switch ((String) lista.get(i)[1]) {
			case "Integridade":
				cor = "rgba(" + 8 + "," + 27 + "," + 162 + ",1)";
				break;
			case "Range":
				cor = "rgba(" + 20 + "," + 63 + "," + 91 + ",1)";
				break;
			case "Missing":
				cor = "rgba(" + 42 + "," + 82 + "," + 149 + ",1)";
				break;
			case "Observa��o":
				cor = "rgba(" + 45 + "," + 165 + "," + 170 + ",1)";
				break;
			case "Duplicidade":
				cor = "rgba(" + 117 + "," + 191 + "," + 163 + ",1)";
				break;
			case "PSI":
				cor = "rgba(" + 50 + "," + 120 + "," + 255 + ",1)";
				break;
			case "Dom�nio":
				cor = "rgba(" + 0 + "," + 255 + "," + 127 + ",1)";
				break;
			case "Base Vazia":
				cor = "rgba(" + 255 + "," + 50 + "," + 0 + ",1)";
				break;
			default:
				System.out.println("N�o h� mais m�tricas");
			}
			colors[i] = cor;
		}

		return colors;
	}

	public ArrayList<ArrayList<Object>> getQtdeNotifAreas(int idRegra, String nomeBase, String dtIni, String dtFim) {

		ArrayList<ArrayList<Object>> areas = new ArrayList<ArrayList<Object>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			areas = notifDAO.getQtdeNotifAreas(idRegra, nomeBase, dtIni, dtFim);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return areas;
	}

	public ArrayList<String[]> getMetricasNotificacao() {
		ArrayList<String[]> metricas = new ArrayList<String[]>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			metricas = notifDAO.getMetricasNotificacao();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return metricas;
	}

	public int getQtdeBasesCadastradas() {

		int qtde = 0;
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			qtde = regraDAO.getQtdeBasesCadastradas();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return qtde;
	}

	public int getQtdeErrosBases() {
		int qtde = 0;
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			qtde = regraDAO.getQtdeErrosBases();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return qtde;
	}

	public int getQtdeAreasAtendidas() {
		int qtde = 0;
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			qtde = regraDAO.getQtdeAreasAtendidas();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return qtde;
	}

	public int getQtdeColunasCadastradas() {
		int qtde = 0;
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			qtde = regraDAO.getQtdeColunasCadastradas();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return qtde;
	}

	public ArrayList<String[]> getQtdeNotiByDia(int idRegra, String nomeBase, String dtIni, String dtFim) {
		ArrayList<String[]> dias = new ArrayList<String[]>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			dias = regraDAO.getQtdeNotiByDia(idRegra, nomeBase, dtIni, dtFim);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return dias;
	}

	public ArrayList<String> getDataMinMaxNotificacoes() {
		ArrayList<String> datas = new ArrayList<String>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			datas = notifDAO.getDataMinMaxNotificacoes();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return datas;
	}

	public Base getBasePeloID(int id) {
		GerenciadorDeConexao sqlServer = null;
		Base base;
		base = new Base();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			base = baseDAO.getBasePeloID(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		return base;
	}

	private List getAmostraPorID(int id, int tamanho) {
		GerenciadorDeConexao sqlServer = null;
		List<Observacao> linhasTabela = new ArrayList();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			linhasTabela = obsDAO.getAmostraPorID(id, tamanho);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return linhasTabela;
	}

	public int[] getMaxMin(List<Observacao> linhasTabela) {

		int[] max_min_amp = new int[3];

		ArrayList<Double> nobs = new ArrayList<Double>();
		ArrayList<Double> lim_inf_ama = new ArrayList<Double>();
		ArrayList<Double> lim_inf_ver = new ArrayList<Double>();
		ArrayList<Double> lim_sup_ama = new ArrayList<Double>();
		ArrayList<Double> lim_sup_ver = new ArrayList<Double>();
		ArrayList<Double> media = new ArrayList<Double>();

		for (Observacao obs : linhasTabela) {
			nobs.add(obs.getNumObs());
			lim_inf_ver.add(obs.getLmtInfVer());
			lim_inf_ama.add(obs.getLmtInfAma());
			lim_sup_ama.add(obs.getLmtSupAma());
			lim_sup_ver.add(obs.getLmtSupVer());
			media.add(obs.getMedia());
		}

		ArrayList<Double> maxList = new ArrayList<Double>();
		ArrayList<Double> minList = new ArrayList<Double>();
		maxList.add(Collections.max(nobs));
		maxList.add(Collections.max(lim_inf_ver));
		maxList.add(Collections.max(lim_inf_ama));
		maxList.add(Collections.max(lim_sup_ama));
		maxList.add(Collections.max(lim_sup_ver));
		maxList.add(Collections.max(media));

		minList.add(Collections.min(nobs));
		minList.add(Collections.min(lim_inf_ver));
		minList.add(Collections.min(lim_inf_ama));
		minList.add(Collections.min(lim_sup_ama));
		minList.add(Collections.min(lim_sup_ver));
		minList.add(Collections.min(media));

		max_min_amp[0] = (int) Math.floor(Collections.max(maxList));
		max_min_amp[1] = (int) Math.floor(Collections.min(minList));
		max_min_amp[2] = (int) Math.floor((max_min_amp[0] - max_min_amp[1]) / 5);

		return max_min_amp;
	}

}
