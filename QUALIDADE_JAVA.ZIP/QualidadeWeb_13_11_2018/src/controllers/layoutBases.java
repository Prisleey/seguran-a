package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import conectores.ConectorSAS;
import model.ColunaTabela;
import model.ServidorSAS;

//SERVLET PARA FAZER O LAYOUT AUTOMATICO DAS BASES DO SAS
public class layoutBases extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		RequestDispatcher rd;
		
		
		System.out.println("ENTROU NO SERVLET DE LAYOUT!");
		
	}
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		
		String lib = request.getParameter("conexao");
		String nomeBase = request.getParameter("nomeBase");
		int workSpace = Integer.parseInt(request.getParameter("workSpace"));
		
		ServidorSAS servidorSAS = new ServidorSAS();
		servidorSAS = getServidorSasByIdWorkSpace(workSpace);
		ConectorSAS sas = new ConectorSAS();
		List<ColunaTabela> colunasLayout = null;
		try {
			sas.iniciar("", "", servidorSAS.getHostName(), servidorSAS.getPorta());
			colunasLayout = sas.getLayoutBaseSAS(lib, ""+nomeBase+"");
			System.out.println("LIB: " + lib + ". Base: " + nomeBase + ". WorkSpace: " + workSpace);
		} catch (IOException e) {			
			e.printStackTrace();
		} finally {
			sas.encerrar();
		}
		
		Gson gson = new Gson();
		String json = gson.toJson(colunasLayout);
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
	    response.setCharacterEncoding("UTF-8"); 
		out.write(json);      // Write response body.
	}
	
	
	public ServidorSAS getServidorSasByIdWorkSpace(int idWorkSpace){
		GerenciadorDeConexao sqlServer = null;
		ServidorSAS servSAS = new ServidorSAS();
		try {
			sqlServer = new GerenciadorDeConexao();
			
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			servSAS = baseDAO.getServidorSasByIdWorkSpace(idWorkSpace);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}		
		return servSAS;
	}
}
