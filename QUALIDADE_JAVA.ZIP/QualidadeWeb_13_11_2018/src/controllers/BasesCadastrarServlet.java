package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.RegraDAO;
import DAO.tabelaXDAO;
import model.Base;
import model.ColunaTabela;
import model.ModeloX;
import model.Resposta;
import model.ServidorSAS;
import model.Setor;

public class BasesCadastrarServlet extends HttpServlet  {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException{
		RequestDispatcher rd;
		
		int id;
		if(request.getParameter("id") != null) {
			id = Integer.parseInt(request.getParameter("id"));
		}else {
			id = 0;
		}
		
		//carrega lista de setores a partir do banco de dados.
		List<Setor> lSetores = listarSetores();
		request.setAttribute("listaSetores", lSetores);
		
		if(id > 0) { //update
			Base base = new Base();
			base = getBasePeloID(id);
			request.setAttribute("baseAtual", base);
			request.setAttribute("colunasAtuais", base.getColunas());
			request.setAttribute("idAtual", id);
			request.setAttribute("idDoSetor", base.getSetor().getIdSetor());
			/*
			List<ColunaTabela> colunas = new ArrayList();
			colunas = base.getColunas();
			
			for(ColunaTabela obj : colunas) {
				System.out.println("nome da coluna �: " + obj.getNomeColuna());
			}
			*/
			
		}else {
			//se o ID for zero eu sei que � um input, se for algo diferente � um load/update
			request.setAttribute("idAtual", id);
			
			
		}
			
		System.out.println("o ID �: " + id);
		
		rd = request.getRequestDispatcher("/WEB-INF/View/basesCadastrar.jsp");
		try{
			rd.forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
		
		String headerName = request.getHeader("headerAjax").trim();
		
		if(headerName.equals("editCol")) { //editar coluna do layout individualmente baseado no ID da coluna
			int idCol = Integer.parseInt(request.getParameter("idCol"));
			String nomeCol = request.getParameter("nomeCol");
			int tipoCol = Integer.parseInt(request.getParameter("tipoCol"));
			int tamanhoCol = Integer.parseInt(request.getParameter("tamanhoCol"));
			String matricula = request.getParameter("matricula"); //matricula de quem est� editando a coluna
			
			ColunaTabela col = new ColunaTabela();
			col.setIdColuna(idCol);
			col.setNomeColuna(nomeCol);
			col.setTipoColuna(tipoCol);
			col.setTamanhoColuna(tamanhoCol);
			
			updateColunaPeloId(col, matricula);
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
		    response.setCharacterEncoding("UTF-8");
		    out.write("Coluna editada com sucesso");       // Write response body.
			
			System.out.println("ID: " + idCol + "NOME: " + nomeCol + " TIPO: " + tipoCol + " Tamnho: " + tamanhoCol);
			
		}else if(headerName.equals("deleteCol")) {
			
			int idColuna = Integer.parseInt(request.getParameter("idColuna"));
			int idTb = Integer.parseInt(request.getParameter("idTb"));
			deleteRegraByIdCol(idColuna);
			deleteColunaByID(idTb, idColuna);
			
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
		    response.setCharacterEncoding("UTF-8");
		    out.write("Coluna deletada com sucesso");       // Write response body.
		    
		}else if(headerName.equals("insertUpdate")) {
			//Retornando
			int id = Integer.parseInt(request.getParameter("idVal"));
			String nomeBase = request.getParameter("nomeBase");
			String conexao = request.getParameter("conexao");
			String matResponsavel = request.getParameter("matResp");
			String emailResponsavel = request.getParameter("emailResp");
			String tipoBase = request.getParameter("tipoBase");
			Double limSup = Double.parseDouble(request.getParameter("limSup")); 
			Double limInf = Double.parseDouble(request.getParameter("limInf"));
			int setorBase = Integer.parseInt(request.getParameter("setorBase"));
			int tipoLayout = Integer.parseInt(request.getParameter("layoutOpt")); //1 - automatico, 2 - manual
			String periodicidade = request.getParameter("periodicidade");
			String safrada = request.getParameter("safra");
			String increm_full = request.getParameter("increm_full");
			int safra = 0;
			if (safrada.equals("N�o")) {
				safra = 1;
			}
			
			int contador = Integer.parseInt(request.getParameter("contador"));
			int contadorLabel;
			
			Resposta resultadoOperacao = new Resposta(); 
			
			ColunaTabela coluna;
			List<ColunaTabela> listaColunas;
			listaColunas = new ArrayList();
			

			
			Base base = new Base();
			base.setNomeBase(nomeBase);
			base.setConexao(conexao);
			base.setMatriculaResponsavel(matResponsavel);
			base.setEmailResponsavel(emailResponsavel);
			base.setTipoBase(tipoBase);
			base.setSetor(new Setor(setorBase)); //como a base tem um objeto setor, mas s� me interessa o ID, eu passo um objeto com o segundo construtor que s� necessita do ID.
			base.setLimiteSuperior(limSup);
			base.setLimiteInferior(limInf);
			base.setTipoLayout(tipoLayout);
			base.setPeriodicidade(periodicidade);
			base.setSafrada(safra);
			base.setIncrem_full(increm_full);
			if (periodicidade.equals("Di�ria")) {
				base.setTamanhoAmostra(30);
			} else if (periodicidade.equals("Mensal")) {
				base.setTamanhoAmostra(6);
			} else if (periodicidade.equals("Semanal")) {
				base.setTamanhoAmostra(12);
			} else if (periodicidade.equals("Quinzenal")) {
				base.setTamanhoAmostra(8);
			} else if (periodicidade.equals("Trimestral")) {
				base.setTamanhoAmostra(3);
			} else if (periodicidade.equals("Semestral")) {
				base.setTamanhoAmostra(2);
			} else if (periodicidade.equals("Anual")) {
				base.setTamanhoAmostra(2);
			}
			if(tipoLayout == 1) {
				String nomeBaseLayout = request.getParameter("nomeBaseLayout").trim();
				base.setNomeBaseLayout(nomeBaseLayout);	
			} else {
				base.setNomeBaseLayout("N/A"); //apenas um workaround, na realidade o campo no banco de dados n�o deveria ser NOT NULL
			}
			
			if(request.getParameter("servidorSAS") != null) {
				int idServ = Integer.parseInt(request.getParameter("servidorSAS"));
				ServidorSAS serv = new ServidorSAS();
				serv.setIdServidor(idServ);
				base.setServidorSAS(serv);
			}
			
			String matriculaUpdate = "i-354217";
			
			//CRIANDO A COLUNA GENERICA NA QUAL SERAO ATRELADAS AS METRICAS DE OBSERVACAO E DUPLICIDADE NAS NOTIFICACOES
			ColunaTabela colGenerica = new ColunaTabela();
			colGenerica.setNomeColuna("BASE_TODA");
			colGenerica.setTipoColuna(1); //tanto faz o tipo, essa coluna n�o ser� considerada na integridade.
			colGenerica.setTamanhoColuna(0);
			colGenerica.setNumOrdem(0);
			colGenerica.setColunaAutomatica(2); //coluna generica
			listaColunas.add(colGenerica); //add a coluna generica na lista, antes de adicionar as demais.
			
			for(int i = 0; i < contador; i++) {
				contadorLabel = i+1;
				coluna = new ColunaTabela();
				coluna.setNomeColuna(request.getParameter("nomeColuna"+contadorLabel));
				coluna.setTipoColuna(Integer.parseInt(request.getParameter("tipoColuna"+contadorLabel)));
				coluna.setTamanhoColuna(Integer.parseInt(request.getParameter("tamanhoCol"+contadorLabel)));
				coluna.setNumOrdem(i+1);
				coluna.setColunaAutomatica(1);
				listaColunas.add(coluna);
			}
			
			//UPDATE
			if(id > 0) {
				base.setIdTabela(id);
				if(request.getParameter("nomeBaseLayout") != null) {
					base.setNomeBaseLayout(request.getParameter("nomeBaseLayout").trim());
				}else {
					base.setNomeBaseLayout("");
				}
				
				updateBasePeloID(base, matriculaUpdate);
				
				//Apaga todas as colunas para depois inserir, dar update seria muito custoso
				//deleteColunas(id);
				
				//insere as colunas novamente
				resultadoOperacao = inserirColunas(listaColunas, id, matriculaUpdate);
				
				
				
			}else{
				//INSERT
							
				int novoID = 0;
				try{
					novoID = inserirTabela(base, matriculaUpdate);
				}catch(Exception ex) {
					resultadoOperacao.setMensagem("Ocorreu um erro ao inserir a base: " + ex.getMessage());
					resultadoOperacao.setTipo(2); //erro
					throw new NullPointerException("Ocorreu um erro ao inserir a base: " + ex.getMessage());
				}
				
				if(novoID > 0) {
					/*ultimo paramentro n�o � a matricula do resposavel pela base, e sim
					 a matricula de quem inseriu ou modificou ela, como uma log */
					resultadoOperacao = inserirColunas(listaColunas, novoID, matriculaUpdate);
				}else {
					resultadoOperacao.setMensagem("Ouve um erro ao inserir a base");
					resultadoOperacao.setTipo(2); //erro
				}
				
				
				
				System.out.println("conexao: " + conexao);
				String resposta = "Registro Cadastrado com sucesso! Conex�o: " + conexao; 
				
				
		    
			}
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
		    response.setCharacterEncoding("UTF-8"); 
		    out.write(resultadoOperacao.getMensagem() + ";" + resultadoOperacao.getTipo());       // Write response body.
		    
		}else if(headerName.equals("servidorSAS")) {
			System.out.println("aqui");
			List<ServidorSAS> servidores = listarServidoresSAS();
			Gson gson = new Gson();
			String json = gson.toJson(servidores);
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
		    response.setCharacterEncoding("UTF-8"); 
			out.write(json);      // Write response body.
		}else if (headerName.equals("updateApenasCampos")){ //quando � feito update apenas dos campos no layout automatico
			int id = Integer.parseInt(request.getParameter("idVal"));
			String nomeBase = request.getParameter("nomeBase");
			String conexao = request.getParameter("conexao");
			String matResponsavel = request.getParameter("matResp");
			String tipoBase = request.getParameter("tipoBase");
			Double limSup = Double.parseDouble(request.getParameter("limSup")); 
			Double limInf = Double.parseDouble(request.getParameter("limInf"));
			int setorBase = Integer.parseInt(request.getParameter("setorBase"));
			String periodicidade = request.getParameter("periodicidade");
			int safrada = Integer.parseInt(request.getParameter("safra"));
			
			Base base = new Base();
			base.setIdTabela(id);
			base.setNomeBase(nomeBase);
			base.setConexao(conexao);
			base.setMatriculaResponsavel(matResponsavel);
			base.setTipoBase(tipoBase);
			base.setSetor(new Setor(setorBase)); //como a base tem um objeto setor, mas s� me interessa o ID, eu passo um objeto com o segundo construtor que s� necessita do ID.
			base.setLimiteSuperior(limSup);
			base.setLimiteInferior(limInf);
			base.setPeriodicidade(periodicidade);
			base.setSafrada(safrada);
			
			if(request.getParameter("servidorSAS") != null) {
				int idServ = Integer.parseInt(request.getParameter("servidorSAS"));
				ServidorSAS serv = new ServidorSAS();
				serv.setIdServidor(idServ);
				base.setServidorSAS(serv);
			}
			
			String matriculaUpdate = "i354217";
			Resposta resultadoOperacao = new Resposta();
			
			resultadoOperacao = updateBasePeloID(base, matriculaUpdate);
			
			PrintWriter out = response.getWriter();
			response.setContentType("text/plain");  // Set content type of the response so that jQuery knows what it can expect.
		    response.setCharacterEncoding("UTF-8"); 
		    out.write(resultadoOperacao.getMensagem() + ";" + resultadoOperacao.getTipo());       // Write response body.
		    
		}
	}

	private int inserirTabela(Base obj, String matricula) {
		
		int resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); //abrindo a conex�o
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resposta = baseDAO.inserirTabela(obj, matricula); //resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resposta;
	}
	
	public Resposta inserirColunas(List<ColunaTabela> colunas, int idTabela, String matricula) {
		
		Resposta resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resposta = baseDAO.inserirColunas(colunas, idTabela, matricula);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resposta;
		
	}
	
	private Base getBasePeloID(int id) {
		
		Base base = new Base();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			base = baseDAO.getBasePeloID(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return base;
	}
	
	private Resposta updateBasePeloID(Base objBase, String matricula) {
		
		GerenciadorDeConexao sqlServer = null;
		Resposta resp = new Resposta();
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resp = baseDAO.updateBasePeloID(objBase, matricula);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resp;
	}
	
	private void updateColunaPeloId(ColunaTabela coluna, String matriculaEdit) {
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			baseDAO.updateColunaPeloId(coluna, matriculaEdit);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	private void deleteColunas(int id) {
		
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			baseDAO.deleteColunas(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	private void deleteRegraByIdCol(int idColuna) {
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			regraDAO.deleteRegraByIdCol(idColuna);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	private void deleteColunaByID(int idTb, int idCol) {
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			baseDAO.deleteColunaByID(idTb, idCol);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	private List<ServidorSAS> listarServidoresSAS(){
		GerenciadorDeConexao sqlServer = null;
		List<ServidorSAS> servidores;
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO b = sqlServer.getObjetoBase();
			servidores = b.listarServidoresSAS();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return servidores;
		
		
	}
	
	private List<Setor> listarSetores(){
		GerenciadorDeConexao sqlServer = null;
		List<Setor> setores;
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			setores = bDAO.listarSetores();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return setores;
	}
	
	public int getIDSetor(String nomeSetor) {
		int resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); //abrindo a conex�o
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resposta = baseDAO.getIDSetor(nomeSetor); //resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return resposta;
	}
}
