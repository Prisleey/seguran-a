package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.NotificacaoDAO;
import DAO.ObservacaoDAO;
import model.Base;
import model.ColunaTabela;
import model.Observacao;

@SuppressWarnings("serial")
public class BIServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		RequestDispatcher rd;

		int idCalc = Integer.parseInt(request.getParameter("idCalc"));
		Base base = new Base();
		List<Observacao> linhasTabela;
		String nome = request.getParameter("nome");
		int[] maxmin = new int[2];

		request.setAttribute("nomeBase", nome);
		int tamanho = 0;
		base = getBasePeloID(idCalc);
		if (base.getPeriodicidade().equals("Di�ria")) {
			tamanho = 60;
		} else if (base.getPeriodicidade().equals("Mensal")) {
			tamanho = 12;
		} else if (base.getPeriodicidade().equals("Semanal")) {
			tamanho = 36;
		} else if (base.getPeriodicidade().equals("Anual")) {
			tamanho = 60;
		} else if (base.getPeriodicidade().equals("Semestral")) {
			tamanho = 60;
		} else if (base.getPeriodicidade().equals("Trimestral")) {
			tamanho = 60;
		}
		linhasTabela = getAmostraPorID(idCalc, tamanho);
		maxmin = getMaxMin(linhasTabela);

		List<String[]> linhasObser = new ArrayList<>();
		String[] row = new String[17];
		for (int i = 0; i < linhasTabela.size(); i++) {
			row = new String[17];
			row[0] = String.valueOf(linhasTabela.get(i).getIdTabela());
			row[1] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getNumObs()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[2] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getDesvio()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[3] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getMedia()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[4] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getRangeIndividual()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[5] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getMediaRange()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[6] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getLmtInfVer()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[7] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getLmtInfAma()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[8] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getLmtSupAma()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[9] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getLmtSupVer()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[10] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getDesvioNecess()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[11] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getDesvioCima()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[12] = String.valueOf(new BigDecimal(String.valueOf(linhasTabela.get(i).getDesvioBaixo()))
					.divide(new BigDecimal(1), 2, RoundingMode.UP));
			row[13] = String.valueOf(linhasTabela.get(i).getFlag());
			row[14] = linhasTabela.get(i).getDataFlag();
			row[15] = String.valueOf(linhasTabela.get(i).getConsiderar());
			row[16] = linhasTabela.get(i).getNomeBase();
			linhasObser.add(row);
		}
		request.setAttribute("linhasTabela", linhasObser);
		request.setAttribute("max_min", maxmin);

		rd = request.getRequestDispatcher("/WEB-INF/View/BI.jsp");
		try {
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
												// expect.
		response.setCharacterEncoding("UTF-8");
		String headerName = request.getHeader("headerAjax").trim();

		if (headerName.equals("desconsiderar")) {

			String dtModificacao = "";
			String justificativa = "";
			String nomeBase = "";
			int id = 0;
			Base base = new Base();
			

			if (request.getParameter("justificativa") != null) {
				justificativa = (String) request.getParameter("justificativa");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}
			
			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			base = getBasePeloId(id);

			int ok = 0;

			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

			Calendar cal_hoje = Calendar.getInstance();
			String dtHoje = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(cal_hoje.getTime());

			if (!existeJustificativaObservacao(id, nomeBase, dtModificacao)) {
				insertJustificativaNotificacoesObservacao(id,nomeBase, dtHoje, dtModificacao, justificativa);
				updateStatusBasesObservacao(nomeBase, dtModificacao);
				desconsiderarFlagObservacao(id,nomeBase, dtModificacao);
			} else {
				desconsiderarFlagObservacao(id,nomeBase, dtModificacao);
			}

			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.
		} else if (headerName.equals("considerar")) {
			String dtModificacao = "";
			String nomeBase = "";
			int id = 0;
			Base base = new Base();

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}
			
			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			base = getBasePeloId(id);

			int ok = 0;

			
			considerarFlagObservacao(id, nomeBase, dtModificacao);
			
			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.
		}
	}

	private List getAmostraPorID(int id, int tamanho) {
		GerenciadorDeConexao sqlServer = null;
		List<Observacao> linhasTabela = new ArrayList();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			linhasTabela = obsDAO.getAmostraPorID(id, tamanho);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return linhasTabela;
	}

	public Base getBasePeloID(int id) {
		GerenciadorDeConexao sqlServer = null;
		Base base;
		base = new Base();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			base = baseDAO.getBasePeloID(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		return base;
	}

	public int[] getMaxMin(List<Observacao> linhasTabela) {

		int[] max_min_amp = new int[3];

		ArrayList<Double> nobs = new ArrayList<Double>();
		ArrayList<Double> lim_inf_ama = new ArrayList<Double>();
		ArrayList<Double> lim_inf_ver = new ArrayList<Double>();
		ArrayList<Double> lim_sup_ama = new ArrayList<Double>();
		ArrayList<Double> lim_sup_ver = new ArrayList<Double>();
		ArrayList<Double> media = new ArrayList<Double>();

		for (Observacao obs : linhasTabela) {
			nobs.add(obs.getNumObs());
			lim_inf_ver.add(obs.getLmtInfVer());
			lim_inf_ama.add(obs.getLmtInfAma());
			lim_sup_ama.add(obs.getLmtSupAma());
			lim_sup_ver.add(obs.getLmtSupVer());
			media.add(obs.getMedia());
		}

		ArrayList<Double> maxList = new ArrayList<Double>();
		ArrayList<Double> minList = new ArrayList<Double>();
		maxList.add(Collections.max(nobs));
		maxList.add(Collections.max(lim_inf_ver));
		maxList.add(Collections.max(lim_inf_ama));
		maxList.add(Collections.max(lim_sup_ama));
		maxList.add(Collections.max(lim_sup_ver));
		maxList.add(Collections.max(media));

		minList.add(Collections.min(nobs));
		minList.add(Collections.min(lim_inf_ver));
		minList.add(Collections.min(lim_inf_ama));
		minList.add(Collections.min(lim_sup_ama));
		minList.add(Collections.min(lim_sup_ver));
		minList.add(Collections.min(media));

		max_min_amp[0] = new BigDecimal(Math.floor(Collections.max(maxList))).intValueExact();
		max_min_amp[1] = new BigDecimal(Math.floor(Collections.min(minList))).intValueExact();
		max_min_amp[2] = new BigDecimal(Math.floor((max_min_amp[0] - max_min_amp[1]) / 5)).intValueExact();

		return max_min_amp;
	}

	public boolean existeJustificativaObservacao(int idTB, String nomeBase, String dataModificacao) {
		GerenciadorDeConexao sqlServer = null;
		boolean justificativa = false;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			justificativa = bDAO.existeJustificativaObservacao(idTB, nomeBase, dataModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return justificativa;
	}

	public void desconsiderarFlagObservacao(int idTB, String nomeBase, String dataModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.desconsiderarFlagObservacao(idTB, nomeBase, dataModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void considerarFlagObservacao(int idTB, String nomeBase, String dataModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.considerarFlagObservacao(idTB, nomeBase, dataModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public Base getBasePeloId(int id) {
		Base base = new Base();
		List<ColunaTabela> colunas = new ArrayList();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			base = baseDAO.getBasePeloID(id);
			colunas = baseDAO.getColunasPeloID(id);
			base.addListaColunas(colunas);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return base;

	}

	public void insertJustificativaNotificacoesObservacao(int idTB, String nomeBase, String dtJustificativa, String dtModificacao,
			String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaNotificacoesObservacao(idTB, nomeBase, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void updateStatusBasesObservacao(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesObservacao(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

}
