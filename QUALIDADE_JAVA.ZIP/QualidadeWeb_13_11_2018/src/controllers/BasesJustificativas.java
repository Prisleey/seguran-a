package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.ws.BindingProvider;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.google.gson.Gson;
import com.sun.org.apache.xerces.internal.dom.ElementNSImpl;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.NotificacaoDAO;
import model.Base;
import model.ColunaTabela;
import model.Email;
import model.StatusBases;

import sharepoint.GetListItems;
import sharepoint.GetListItemsResponse;
import sharepoint.Lists;
import sharepoint.ListsRequest;
import sharepoint.ListsSoap;

public class BasesJustificativas extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		RequestDispatcher rd;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

		List<StatusBases> bases = new ArrayList<StatusBases>();
		ArrayList<String> datas = new ArrayList<String>();
		datas = getDataMinMaxJustificativas();
		String dtOntem = "";
		String dtHoje = "";
		String[] dtMinMax = new String[2];
		Gson gson = new Gson();
		String json = "";

		Calendar cal_1 = Calendar.getInstance();

		if (datas.size() > 0) {
			if (datas.get(0) != null) {

				dtOntem = formatter.format(cal_1.getTime());
				dtHoje = datas.get(1);

				try {
					cal_1.setTime(formatter.parse(dtHoje));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				cal_1.add(Calendar.MINUTE, 5);
				dtHoje = formatter.format(cal_1.getTime());

				try {
					cal_1.setTime(formatter.parse(datas.get(1)));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				cal_1.add(Calendar.HOUR_OF_DAY, -48);
				dtOntem = formatter.format(cal_1.getTime());

				bases = getBasesJustificativasporData(dtOntem, dtHoje);

				gson = new Gson();
				json = gson.toJson(bases);
				request.setAttribute("Bases", json);
				System.out.println(bases);

				dtMinMax[0] = datas.get(0);
				dtMinMax[1] = dtHoje;
			}
		}

		request.setAttribute("Datas", dtMinMax);
		request.setAttribute("DT_hoje", dtHoje);
		request.setAttribute("DT_ontem", dtOntem);

		System.out.println("Chegou em Bases Justificativas");

		rd = request.getRequestDispatcher("/WEB-INF/View/basesJustificativas.jsp");
		try {
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
												// expect.
		response.setCharacterEncoding("UTF-8");
		String headerName = request.getHeader("headerAjax").trim();

		if (headerName.equals("atualizarJustificativas")) {
			String dtIni = "";
			String dtFim = "";

			if (request.getParameter("dtIni") != null) {
				dtIni = (String) request.getParameter("dtIni");
			}
			if (request.getParameter("dtFim") != null) {
				dtFim = (String) request.getParameter("dtFim");
			}

			System.out.println("DT INIC: " + dtIni + " DT FIM: " + dtFim);
			List<StatusBases> bases = new ArrayList<StatusBases>();

			bases = getBasesJustificativasporData(dtIni, dtFim);

			Gson gson = new Gson();
			String json = gson.toJson(bases);
			System.out.println(json.length());
			out.write(json); // Write response body.
		} else if (headerName.equals("detalhesBases")) {
			Base base = new Base();
			String nomeBase = "";
			String dtModificacao = "";
			int id = 0;
			List<List> listaTodos = new ArrayList<List>();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			ArrayList<ArrayList<String>> listaIntegridade = new ArrayList<ArrayList<String>>();
			ArrayList<ArrayList<String>> listaObservacao = new ArrayList<ArrayList<String>>();
			ArrayList<ArrayList<String>> listaDuplicidade = new ArrayList<ArrayList<String>>();
			ArrayList<ArrayList<String>> listaDominio = new ArrayList<ArrayList<String>>();
			ArrayList<ArrayList<String>> listaMissing = new ArrayList<ArrayList<String>>();
			ArrayList<ArrayList<String>> listaRange = new ArrayList<ArrayList<String>>();
			ArrayList<ArrayList<String>> listaPSI = new ArrayList<ArrayList<String>>();

			listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);
			listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);
			listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);
			listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);
			listaRange = getNotificacoesRange(nomeBase, dtModificacao);
			base = getBasePeloId(id);
			listaObservacao = getNotificacoesObservacao(id, nomeBase, dtModificacao);
			listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

			if (listaIntegridade.size() > 0) {
				listaTodos.add(listaIntegridade);
			}
			if (listaDuplicidade.size() > 0) {
				listaTodos.add(listaDuplicidade);
			}
			if (listaDominio.size() > 0) {
				listaTodos.add(listaDominio);
			}
			if (listaMissing.size() > 0) {
				listaTodos.add(listaMissing);
			}
			if (listaRange.size() > 0) {
				listaTodos.add(listaRange);
			}
			if (listaObservacao.size() > 0) {
				listaTodos.add(listaObservacao);
			}
			if (listaPSI.size() > 0) {
				listaTodos.add(listaPSI);
			}

			Gson gson = new Gson();
			String json = gson.toJson(listaTodos);
			System.out.println(json.length());
			out.write(json); // Write response body.
		} else if (headerName.equals("enviarEmailResponsavel")) {
			String nomeBase = "";
			String dtModificacao = "";
			String dtQualidade = "";
			int id = 0;
			int ok = 0;
			Base base = new Base();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}
			
			if (request.getParameter("dtQualidade") != null) {
				dtQualidade = (String) request.getParameter("dtQualidade");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			base = getBasePeloId(id);
			Email em = new Email();

			String[] login = getLoginSAS();
			String usuario = login[0];
			String senha = "cebola08";

			String destinatario = getEmailResponsavelByID(id);
			if (getStatusEmail(nomeBase, dtModificacao, dtQualidade) != 1) {
				if (!destinatario.equals("")) {

					String remetente = "adrean.cebola@bradesco.com.br";
					String assunto = "Notifica��es da base: " + nomeBase;

					String texto = "";

					texto = "<html><head><style>body {font-size:11.0pt;font-family:" + "\"Calibri\", sans-serif;}table "
							+ "{border-collapse:collapse;width:800px;}td,th{padding:4px;border:1px solid "
							+ "black;text-align: center;}</style></head><body>";

					texto += "<p>A base <b>" + nomeBase
							+ "</b> sofreu erro(s) em uma ou mais m�tricas, como segue abaixo:</p>";

					ArrayList<ArrayList<String>> listaIntegridade = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaObservacao = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaDuplicidade = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaDominio = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaMissing = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaRange = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaPSI = new ArrayList<ArrayList<String>>();

					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);
					listaObservacao = getNotificacoesObservacao(id, nomeBase, dtModificacao);
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							texto += "<h4><b>Integridade:</b></h4>";
							texto += "<table><thead><tr><th>CAMPO</h><th>TIPO CADASTRO</th><th>TAMANHO CADASTRO</th><th>TIPO ATUAL</th><th>TAMANHO ATUAL</th>"
									+ "</tr></thead><tbody>";
							for (int i = 0; i < listaIntegridade.size(); i++) {
								texto += "<tr><td align='center'>" + listaIntegridade.get(i).get(1)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(2)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(3)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(4)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(5) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							texto += "<h4><b>Duplicidade:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_DUP_PORC</th><th>QTDE_DUP</th><th>QTDE_INFO_DUP</th></thead><tbody>";

							for (int i = 0; i < listaDuplicidade.size(); i++) {
								texto += "<tr><td align='center'>" + listaDuplicidade.get(i).get(1)
										+ "</td><td align='center'>" + listaDuplicidade.get(i).get(2)
										+ "</td><td align='center'>" + listaDuplicidade.get(i).get(3)
										+ "</td><td align='center'>" + listaDuplicidade.get(i).get(4) + "</td></tr>";
							}
							texto += "</tbody></table><br><br>";
						}
					}
					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							texto += "<h4><b>Dominio:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_DOM_PORC</th><th>QTDE_DOM</th><th>VALORES_DOMINIO</th></thead><tbody>";
							for (int i = 0; i < listaDominio.size(); i++) {
								texto += "<tr><td align='center'>" + listaDominio.get(i).get(1)
										+ "</td><td align='center'>" + listaDominio.get(i).get(2)
										+ "</td><td align='center'>" + listaDominio.get(i).get(3)
										+ "</td><td align='center'>" + listaDominio.get(i).get(4) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							texto += "<h4><b>Missing:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_MIS_PORC</th><th>QTDE_MIS</th></thead><tbody>";
							for (int i = 0; i < listaMissing.size(); i++) {
								texto += "<tr><td align='center'>" + listaMissing.get(i).get(1)
										+ "</td><td align='center'>" + listaMissing.get(i).get(2)
										+ "</td><td align='center'>" + listaMissing.get(i).get(3) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							texto += "<h4><b>Range:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_RANGE_PORC</th><th>QTDE_RANGE</th></thead><tbody>";
							for (int i = 0; i < listaRange.size(); i++) {
								texto += "<tr><td align='center'>" + listaRange.get(i).get(1)
										+ "</td><td align='center'>" + listaRange.get(i).get(2)
										+ "</td><td align='center'>" + listaRange.get(i).get(3) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							texto += "<h4><b>Observa��o:</b></h4>";
							texto += "<table><thead><th>NOBS</th><th>DESV_NECESSARIO</th><th>QTD_DESV_ABAIXO</th><th>QTD_DESV_ACIMA</th></thead><tbody>";
							for (int i = 0; i < listaObservacao.size(); i++) {
								texto += "<tr><td align='center'>" + listaObservacao.get(i).get(0)
										+ "</td><td align='center'>" + listaObservacao.get(i).get(1)
										+ "</td><td align='center'>" + listaObservacao.get(i).get(2)
										+ "</td><td align='center'>" + listaObservacao.get(i).get(3) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							texto += "<h4><b>PSI:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_PORC</th>></thead><tbody>";
							for (int i = 0; i < listaPSI.size(); i++) {
								texto += "<tr><td align='center'>" + listaPSI.get(i).get(0) + "</td><td align='center'>"
										+ listaPSI.get(i).get(2) + "</td></tr>";
							}
							texto += "</tbody></table>";
						}
					}
					texto += "<br>Por gentileza, responder esse email com a justificiativa parra esse(s) erro(s).";
					texto += "<br>Atenciosamente Qualidade DGD.<br><br>BANCO BRADESCO S/A<br>"
							+ "4852 / Departamento de Gest�o de Dados<br>Qualidade de Dados" + "</body></html>";

					try {
						em.enviarEmail(usuario, senha, remetente, destinatario, assunto, texto);
						updateStatusEmail(nomeBase, dtModificacao, dtQualidade);
					} catch (AddressException e1) {
						e1.printStackTrace();
						ok = -2;
					} catch (UnsupportedEncodingException e1) {
						e1.printStackTrace();
						ok = -2;
					} catch (MessagingException e1) {
						e1.printStackTrace();
						ok = -2;
					}

				} else {
					ok = 1;
				}
			} else {
				ok = -2;
			}
			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.

		} else if (headerName.equals("InsertSharepoint")) {
			String nomeBase = "";
			String dtModificacao = "";
			String dtQualidade = "";
			int id = 0;
			int ok = 0;
			Base base = new Base();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}
			
			if (request.getParameter("dtQualidade") != null) {
				dtQualidade = (String) request.getParameter("dtQualidade");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			base = getBasePeloId(id);

			String destinatario = getMatResponsavelByID(id);
			if (getStatusEmail(nomeBase, dtModificacao, dtQualidade) != 1) {
				if (!destinatario.equals("")) {

					String texto = "";

					texto = "<html><head><style>body {font-size:11.0pt;font-family:" + "\"Calibri\", sans-serif;}table "
							+ "{border-collapse:collapse;width:800px;}td,th{padding:4px;border:1px solid "
							+ "black;text-align: center;}</style></head><body>";

					texto += "<p>A base <b>" + nomeBase
							+ "</b> sofreu erro(s) em uma ou mais m�tricas, como segue abaixo:</p>";

					ArrayList<ArrayList<String>> listaIntegridade = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaObservacao = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaDuplicidade = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaDominio = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaMissing = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaRange = new ArrayList<ArrayList<String>>();
					ArrayList<ArrayList<String>> listaPSI = new ArrayList<ArrayList<String>>();

					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);
					listaObservacao = getNotificacoesObservacao(id, nomeBase, dtModificacao);
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							texto += "<h4><b>Integridade:</b></h4>";
							texto += "<table><thead><tr><th>CAMPO</h><th>TIPO CADASTRO</th><th>TAMANHO CADASTRO</th><th>TIPO ATUAL</th><th>TAMANHO ATUAL</th>"
									+ "</tr></thead><tbody>";
							for (int i = 0; i < listaIntegridade.size(); i++) {
								texto += "<tr><td align='center'>" + listaIntegridade.get(i).get(1)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(2)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(3)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(4)
										+ "</td><td align='center'>" + listaIntegridade.get(i).get(5) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							texto += "<h4><b>Duplicidade:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_DUP_PORC</th><th>QTDE_DUP</th><th>QTDE_INFO_DUP</th></thead><tbody>";

							for (int i = 0; i < listaDuplicidade.size(); i++) {
								texto += "<tr><td align='center'>" + listaDuplicidade.get(i).get(1)
										+ "</td><td align='center'>" + listaDuplicidade.get(i).get(2)
										+ "</td><td align='center'>" + listaDuplicidade.get(i).get(3)
										+ "</td><td align='center'>" + listaDuplicidade.get(i).get(4) + "</td></tr>";
							}
							texto += "</tbody></table><br><br>";
						}
					}
					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							texto += "<h4><b>Dominio:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_DOM_PORC</th><th>QTDE_DOM</th><th>VALORES_DOMINIO</th></thead><tbody>";
							for (int i = 0; i < listaDominio.size(); i++) {
								texto += "<tr><td align='center'>" + listaDominio.get(i).get(1)
										+ "</td><td align='center'>" + listaDominio.get(i).get(2)
										+ "</td><td align='center'>" + listaDominio.get(i).get(3)
										+ "</td><td align='center'>" + listaDominio.get(i).get(4) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							texto += "<h4><b>Missing:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_MIS_PORC</th><th>QTDE_MIS</th></thead><tbody>";
							for (int i = 0; i < listaMissing.size(); i++) {
								texto += "<tr><td align='center'>" + listaMissing.get(i).get(1)
										+ "</td><td align='center'>" + listaMissing.get(i).get(2)
										+ "</td><td align='center'>" + listaMissing.get(i).get(3) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							texto += "<h4><b>Range:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_RANGE_PORC</th><th>QTDE_RANGE</th></thead><tbody>";
							for (int i = 0; i < listaRange.size(); i++) {
								texto += "<tr><td align='center'>" + listaRange.get(i).get(1)
										+ "</td><td align='center'>" + listaRange.get(i).get(2)
										+ "</td><td align='center'>" + listaRange.get(i).get(3) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							texto += "<h4><b>Observa��o:</b></h4>";
							texto += "<table><thead><th>NOBS</th><th>DESV_NECESSARIO</th><th>QTD_DESV_ABAIXO</th><th>QTD_DESV_ACIMA</th></thead><tbody>";
							for (int i = 0; i < listaObservacao.size(); i++) {
								texto += "<tr><td align='center'>" + listaObservacao.get(i).get(0)
										+ "</td><td align='center'>" + listaObservacao.get(i).get(1)
										+ "</td><td align='center'>" + listaObservacao.get(i).get(2)
										+ "</td><td align='center'>" + listaObservacao.get(i).get(3) + "</td></tr>";
							}
							texto += "</tbody></table><br>";
						}
					}
					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							texto += "<h4><b>PSI:</b></h4>";
							texto += "<table><thead><th>CAMPO</th><th>QTDE_PORC</th>></thead><tbody>";
							for (int i = 0; i < listaPSI.size(); i++) {
								texto += "<tr><td align='center'>" + listaPSI.get(i).get(0) + "</td><td align='center'>"
										+ listaPSI.get(i).get(2) + "</td></tr>";
							}
							texto += "</tbody></table>";
						}
					}

					try {
						String url = "http://shp.net.bradesco.com.br/risk/dtm/imi/dq/_vti_bin/Lists.asmx";
						ListsSoap port = sharePointListsAuth(url);
						ListsRequest listRequest = new ListsRequest();
						String log = "";

						String listName = "Qualidade Exemplo";
						String rowLimit = "1";
						ArrayList<String> listColumnNames = new ArrayList<String>();
						listColumnNames.add("ID");

						GetListItems getList = new GetListItems();

						Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
								.parse(new InputSource(
										new StringReader("<Query><OrderBy><FieldRef Name='ID' Ascending=\"FALSE\"/></OrderBy></Query>")));

						GetListItems.Query queryxml = new GetListItems.Query();
						queryxml.getContent().add(doc.getDocumentElement());

						doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
								.parse(new InputSource(new StringReader("<QueryOptions><ViewAttributes Scope='RecursiveAll'/>"
										+ "<DateInUtc>TRUE</DateInUtc></QueryOptions>")));
						GetListItems.QueryOptions queryxmloptions = new GetListItems.QueryOptions();
						queryxmloptions.getContent().add(doc.getDocumentElement());

						getList.setViewName("");
						getList.setRowLimit(rowLimit);
						getList.setViewFields(null);
						getList.setListName(listName);
						getList.setWebID("");
						
						int idItem = 0;
						// Displays the lists items in the console
						List<HashMap<String, String>> items = displaySharePointList(port, listName, listColumnNames, rowLimit,
								getList, queryxml, queryxmloptions);
						if (items.size() > 0) {
							String stringid = items.get(0).values().toString().replace("[","").replaceAll("]", "").split(", ")[0];
							
							idItem = Integer.parseInt(stringid);
						}
						
						idItem += 1;
						
						updateIdItemSPStatusBases(nomeBase, dtModificacao, dtQualidade, idItem);
						updateStatusEmail(nomeBase, dtModificacao, dtQualidade);

						List<HashMap<String, String>> itemsUpdate = new ArrayList<HashMap<String, String>>();
						
						HashMap<String, String> item = new HashMap<String, String>();
						item.put("Title", nomeBase);
						item.put("Libname", base.getConexao());
						item.put("DataQualidade", dtQualidade);
						item.put("Periodicidade", base.getPeriodicidade());
						item.put("Responsavel", "-1;#corp\\i" + destinatario.substring(1, destinatario.length()));
						item.put("SLA", "2");
						item.put("Descricao", texto);
						item.put("Status", "Enviado ao Respons�vel");
						item.put("Reincidente", "N�o");
						itemsUpdate.add(item);

						log = listRequest.insertListItem(port, listName, itemsUpdate);
						
						if (!log.contains("Update com sucesso!!")) {
							ok = 2;
						}
						
										
					} catch (Exception ex) {
						System.err.println(ex);
						ok = 2;
					}

				} else {
					ok = 1;
				}
			} else {
				ok = -2;
			}
			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.

		} else if (headerName.equals("Justificativa")) {
			String nomeBase = "";
			String campo = "";
			String dtModificacao = "";
			String justificativa = "";
			int metrica = 0;
			int id = 0;
			int ok = 0;
			Base base = new Base();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("campo") != null) {
				campo = (String) request.getParameter("campo");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			if (request.getParameter("justificativa") != null) {
				justificativa = (String) request.getParameter("justificativa");
			}

			if (request.getParameter("metrica") != null) {
				metrica = Integer.parseInt(request.getParameter("metrica"));
			}

			if (justificativa.length() > 20 && justificativa.length() <= 255) {

				base = getBasePeloId(id);
				List<List> listaTodos = new ArrayList<List>();
				ArrayList<ArrayList<String>> listaIntegridade = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaObservacao = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaDuplicidade = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaDominio = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaMissing = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaRange = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaPSI = new ArrayList<ArrayList<String>>();

				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

				Calendar cal_hoje = Calendar.getInstance();
				String dtHoje = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(cal_hoje.getTime());
				
				try {
					cal_hoje.setTime(formatter.parse(dtHoje));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				cal_hoje.add(Calendar.HOUR, -1);
				dtHoje = formatter.format(cal_hoje.getTime());
				

				if (metrica == 0) {

					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);
					listaObservacao = getNotificacoesObservacao(id, nomeBase, dtModificacao);
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							insertJustificativaIntegridade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesIntegridade(nomeBase, dtModificacao);
							ok = 1;
						}
					}
					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							insertJustificativaNotificacoesObservacao(id, nomeBase, dtHoje,
									listaObservacao.get(0).get(4), justificativa);
							updateStatusBasesObservacao(nomeBase, dtModificacao);
							ok = 1;
						}
					}
					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							insertJustificativaDuplicidade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesDuplicidade(nomeBase, dtModificacao);
							ok = 1;
						}
					}
					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							insertJustificativaDominio(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesDominio(nomeBase, dtModificacao);
							ok = 1;
						}
					}
					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							insertJustificativaMissing(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesMissing(nomeBase, dtModificacao);
							ok = 1;
						}
					}
					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							insertJustificativaRange(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesRange(nomeBase, dtModificacao);
							ok = 1;
						}
					}
					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							insertJustificativaPSI(id, nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesPSI(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				} else if (metrica == 1) {
					listaObservacao = getNotificacoesObservacao(id, nomeBase, dtModificacao);

					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							insertJustificativaNotificacoesObservacao(id, nomeBase, listaObservacao.get(0).get(4),
									dtHoje, justificativa);
							updateStatusBasesObservacao(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				} else if (metrica == 2) {
					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							insertJustificativaIntegridade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesIntegridade(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				} else if (metrica == 3) {
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);

					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							insertJustificativaRange(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesRange(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				} else if (metrica == 5) {
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);

					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							insertJustificativaDominio(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesDominio(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				} else if (metrica == 4) {
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);

					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							insertJustificativaMissing(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesMissing(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				} else if (metrica == 6) {
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);

					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							insertJustificativaDuplicidade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesDuplicidade(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				} else if (metrica == 7) {
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							insertJustificativaPSI(id, nomeBase, campo, dtHoje, dtModificacao, justificativa);
							updateStatusBasesPSI(nomeBase, dtModificacao);
							ok = 1;
						}
					}
				}
			} else {
				ok = -1;
			}

			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.

		} else if (headerName.equals("NovaJustificativa")) {
			String nomeBase = "";
			String campo = "";
			String dtModificacao = "";
			String justificativa = "";
			int metrica = 0;
			int id = 0;
			int ok = 0;
			Base base = new Base();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("campo") != null) {
				campo = (String) request.getParameter("campo");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			if (request.getParameter("justificativa") != null) {
				justificativa = (String) request.getParameter("justificativa");
			}

			if (request.getParameter("metrica_nova") != null) {
				metrica = Integer.parseInt(request.getParameter("metrica_nova"));
			}

			if (justificativa.length() > 20 && justificativa.length() <= 255) {

				base = getBasePeloId(id);
				List<List> listaTodos = new ArrayList<List>();
				ArrayList<ArrayList<String>> listaIntegridade = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaObservacao = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaDuplicidade = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaDominio = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaMissing = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaRange = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaPSI = new ArrayList<ArrayList<String>>();

				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

				Calendar cal_hoje = Calendar.getInstance();
				String dtHoje = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(cal_hoje.getTime());
				
				try {
					cal_hoje.setTime(formatter.parse(dtHoje));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				cal_hoje.add(Calendar.HOUR, -1);
				dtHoje = formatter.format(cal_hoje.getTime());

				if (metrica == 0) {

					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);
					listaObservacao = getNotificacoesObservacao(id, nomeBase, dtModificacao);
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							insertNovaJustificativaIntegridade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							insertNovaJustificativaNotificacoesObservacao(id, nomeBase, dtHoje,
									listaObservacao.get(0).get(4), justificativa);
							ok = 1;
						}
					}
					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							insertNovaJustificativaDuplicidade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							insertNovaJustificativaDominio(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							insertNovaJustificativaMissing(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							insertNovaJustificativaRange(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							insertNovaJustificativaPSI(id, nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
				} else if (metrica == 1) {
					listaObservacao = getNotificacoesObservacao(id, nomeBase, dtModificacao);

					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							insertNovaJustificativaNotificacoesObservacao(id, nomeBase, dtHoje,
									listaObservacao.get(0).get(4), justificativa);
							ok = 1;
						}
					}
				} else if (metrica == 2) {
					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							insertNovaJustificativaIntegridade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
				} else if (metrica == 3) {
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);

					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							insertNovaJustificativaRange(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
				} else if (metrica == 5) {
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);

					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							insertNovaJustificativaDominio(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
				} else if (metrica == 4) {
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);

					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							insertNovaJustificativaMissing(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
				} else if (metrica == 6) {
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);

					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							insertNovaJustificativaDuplicidade(nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
				} else if (metrica == 7) {
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							insertNovaJustificativaPSI(id, nomeBase, campo, dtHoje, dtModificacao, justificativa);
							ok = 1;
						}
					}
				}
			} else {
				ok = -1;
			}

			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.

		} else if (headerName.equals("EditarJustificativa")) {
			String nomeBase = "";
			String campo = "";
			String dtModificacao = "";
			String justificativa = "";
			String dtJustificativaOld = "";
			int metrica = 0;
			int idTb = 0;
			int ok = 0;
			Base base = new Base();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("campo") != null) {
				campo = (String) request.getParameter("campo");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}
			
			if (request.getParameter("dtJustificativaOld") != null) {
				dtJustificativaOld = (String) request.getParameter("dtJustificativaOld");
			}

			if (request.getParameter("id") != null) {
				idTb = Integer.parseInt(request.getParameter("id"));
			}

			if (request.getParameter("justificativa") != null) {
				justificativa = (String) request.getParameter("justificativa");
			}

			if (request.getParameter("metrica_nova") != null) {
				metrica = Integer.parseInt(request.getParameter("metrica_nova"));
			}

			if (justificativa.length() > 20 && justificativa.length() <= 255) {

				base = getBasePeloId(idTb);
				List<List> listaTodos = new ArrayList<List>();
				ArrayList<ArrayList<String>> listaIntegridade = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaObservacao = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaDuplicidade = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaDominio = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaMissing = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaRange = new ArrayList<ArrayList<String>>();
				ArrayList<ArrayList<String>> listaPSI = new ArrayList<ArrayList<String>>();

				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

				Calendar cal_hoje = Calendar.getInstance();
				String dtJustificativa = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(cal_hoje.getTime());
				
				try {
					cal_hoje.setTime(formatter.parse(dtJustificativa));
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				cal_hoje.add(Calendar.HOUR, -1);
				dtJustificativa = formatter.format(cal_hoje.getTime());

				if (metrica == 0) {

					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);
					listaObservacao = getNotificacoesObservacao(idTb, nomeBase, dtModificacao);
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							updateJustificativaIntegridade(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							updateJustificativaObservacao(idTb, nomeBase, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							updateJustificativaDuplicidade(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							updateJustificativaDominio(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							updateJustificativaMissing(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							updateJustificativaRange(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							updateJustificativaPSI(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				} else if (metrica == 1) {
					listaObservacao = getNotificacoesObservacao(idTb, nomeBase, dtModificacao);

					if (listaObservacao.size() > 0) {
						if (!listaObservacao.get(0).get(0).equals("0")) {
							updateJustificativaObservacao(idTb, nomeBase, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				} else if (metrica == 2) {
					listaIntegridade = getNotificacoesIntegridade(nomeBase, dtModificacao);

					if (listaIntegridade.size() > 0) {
						if (!listaIntegridade.get(0).get(0).equals("0")) {
							updateJustificativaIntegridade(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				} else if (metrica == 3) {
					listaRange = getNotificacoesRange(nomeBase, dtModificacao);

					if (listaRange.size() > 0) {
						if (!listaRange.get(0).get(0).equals("0")) {
							updateJustificativaRange(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				} else if (metrica == 5) {
					listaDominio = getNotificacoesDominio(nomeBase, dtModificacao);

					if (listaDominio.size() > 0) {
						if (!listaDominio.get(0).get(0).equals("0")) {
							updateJustificativaDominio(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				} else if (metrica == 4) {
					listaMissing = getNotificacoesMissing(nomeBase, dtModificacao);

					if (listaMissing.size() > 0) {
						if (!listaMissing.get(0).get(0).equals("0")) {
							updateJustificativaMissing(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				} else if (metrica == 6) {
					listaDuplicidade = getNotificacoesDuplicidade(nomeBase, dtModificacao);

					if (listaDuplicidade.size() > 0) {
						if (!listaDuplicidade.get(0).get(0).equals("0")) {
							updateJustificativaDuplicidade(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				} else if (metrica == 7) {
					listaPSI = getNotificacoesPSI(nomeBase, dtModificacao);

					if (listaPSI.size() > 0) {
						if (!listaPSI.get(0).get(0).equals("0")) {
							updateJustificativaPSI(idTb, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
									dtJustificativaOld);
							ok = 1;
						}
					}
				}
			} else {
				ok = -1;
			}

			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.

		} else if (headerName.equals("DesconsiderarQtdeRegistrosObserv")) {
			String nomeBase = "";
			String dtModificacao = "";
			String justificativa = "";
			int id = 0;
			Base base = new Base();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			base = getBasePeloId(id);

			int ok = 0;

			if (existeJustificativaObservacao(id, nomeBase, dtModificacao)) {
				desconsiderarFlagObservacao(id, nomeBase, dtModificacao);
				ok = 1;
			} else {
				ok = -1;
			}

			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.
		} else if (headerName.equals("ConsiderarQtdeRegistrosObserv")) {
			String nomeBase = "";
			String dtModificacao = "";
			String justificativa = "";
			int id = 0;
			Base base = new Base();

			if (request.getParameter("nomeBase") != null) {
				nomeBase = (String) request.getParameter("nomeBase");
			}

			if (request.getParameter("dtModificacao") != null) {
				dtModificacao = (String) request.getParameter("dtModificacao");
			}

			if (request.getParameter("id") != null) {
				id = Integer.parseInt(request.getParameter("id"));
			}

			base = getBasePeloId(id);

			int ok = 0;

			considerarFlagObservacao(id, nomeBase, dtModificacao);

			Gson gson = new Gson();
			String json = gson.toJson(ok);
			System.out.println(json.length());
			out.write(json); // Write response body.
		}
	}

	private void updateIdItemSPStatusBases(String nomeBase, String dtModificacao, String dtQualidade, int id) {
		
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateIdItemSPStatusBases(nomeBase, dtModificacao, dtQualidade, id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
	}

	public ArrayList<String> getDataMinMaxJustificativas() {
		ArrayList<String> datas = new ArrayList<String>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			datas = notifDAO.getDataMinMaxJustificativas();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return datas;
	}

	public List<StatusBases> getBasesJustificativasporData(String dtIni, String dtFim) {
		List<StatusBases> bases = new ArrayList<StatusBases>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getBasesJustificativasporData(dtIni, dtFim);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<String>> getNotificacoesDuplicidade(String nomeBase, String dtModificacao) {

		ArrayList<ArrayList<String>> bases = new ArrayList<ArrayList<String>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacoesDuplicidade(nomeBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<String>> getNotificacoesDominio(String nomeBase, String dtModificacao) {

		ArrayList<ArrayList<String>> bases = new ArrayList<ArrayList<String>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacoesDominio(nomeBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<String>> getNotificacoesMissing(String nomeBase, String dtModificacao) {

		ArrayList<ArrayList<String>> bases = new ArrayList<ArrayList<String>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacoesMissing(nomeBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<String>> getNotificacoesRange(String nomeBase, String dtModificacao) {

		ArrayList<ArrayList<String>> bases = new ArrayList<ArrayList<String>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacoesRange(nomeBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<String>> getNotificacoesIntegridade(String nomeBase, String dtModificacao) {
		ArrayList<ArrayList<String>> bases = new ArrayList<ArrayList<String>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacoesIntegridade(nomeBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<String>> getNotificacoesPSI(String nomeBase, String dtModificacao) {
		ArrayList<ArrayList<String>> bases = new ArrayList<ArrayList<String>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacoesPSI(nomeBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public ArrayList<ArrayList<String>> getNotificacoesObservacao(int id, String nomeBase, String dtModificacao) {
		ArrayList<ArrayList<String>> bases = new ArrayList<ArrayList<String>>();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			bases = notifDAO.getNotificacoesObservacao(id, nomeBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	public Base getBasePeloId(int id) {
		Base base = new Base();
		List<ColunaTabela> colunas = new ArrayList();
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			base = baseDAO.getBasePeloID(id);
			colunas = baseDAO.getColunasPeloID(id);
			base.addListaColunas(colunas);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return base;

	}

	private String[] getLoginSAS() {
		GerenciadorDeConexao sqlServer = null;
		String[] login = new String[2];

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			login = bDAO.getLoginSAS();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return login;
	}

	public String getMatResponsavelByID(int id) {
		GerenciadorDeConexao sqlServer = null;
		String email = "";

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			email = bDAO.getMatResponsavelByID(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return email;
	}
	
	public String getEmailResponsavelByID(int id) {
		GerenciadorDeConexao sqlServer = null;
		String email = "";

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			email = bDAO.getEmailResponsavelByID(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return email;
	}

	public void updateStatusEmail(String nomeBase, String dtModificacao, String dtQualidade) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusEmail(nomeBase, dtModificacao, dtQualidade);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public int getStatusEmail(String nomeBase, String dataModificacao, String dataQualidade) {
		GerenciadorDeConexao sqlServer = null;
		int status = 0;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			status = bDAO.getStatusEmail(nomeBase, dataModificacao, dataQualidade);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return status;
	}

	public void insertJustificativaNotificacoesObservacao(int idTB, String nomeBase, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaNotificacoesObservacao(idTB, nomeBase, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertJustificativaIntegridade(String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaIntegridade(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertJustificativaDuplicidade(String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaDuplicidade(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertJustificativaDominio(String nomeBase, String campo, String dtModificacao, String dtJustificativa,
			String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaDominio(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertJustificativaMissing(String nomeBase, String campo, String dtModificacao, String dtJustificativa,
			String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaMissing(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertJustificativaRange(String nomeBase, String campo, String dtModificacao, String dtJustificativa,
			String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaRange(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertJustificativaPSI(int idTB, String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertJustificativaPSI(idTB, nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertNovaJustificativaNotificacoesObservacao(int idTB, String nomeBase, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertNovaJustificativaNotificacoesObservacao(idTB, nomeBase, dtModificacao, dtJustificativa,
					justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertNovaJustificativaIntegridade(String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertNovaJustificativaIntegridade(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertNovaJustificativaDuplicidade(String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertNovaJustificativaDuplicidade(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertNovaJustificativaDominio(String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertNovaJustificativaDominio(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertNovaJustificativaMissing(String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertNovaJustificativaMissing(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertNovaJustificativaRange(String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertNovaJustificativaRange(nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void insertNovaJustificativaPSI(int idTB, String nomeBase, String campo, String dtModificacao,
			String dtJustificativa, String justificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.insertNovaJustificativaPSI(idTB, nomeBase, campo, dtModificacao, dtJustificativa, justificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateStatusBasesObservacao(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesObservacao(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateStatusBasesIntegridade(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesIntegridade(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateStatusBasesDuplicidade(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesDuplicidade(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateStatusBasesDominio(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesDominio(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateStatusBasesMissing(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesMissing(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateStatusBasesRange(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesRange(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateStatusBasesPSI(String nomeBase, String dtJustificativa) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateStatusBasesPSI(nomeBase, dtJustificativa);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public boolean existeJustificativaObservacao(int idTB, String nomeBase, String dataModificacao) {
		GerenciadorDeConexao sqlServer = null;
		boolean justificativa = false;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			justificativa = bDAO.existeJustificativaObservacao(idTB, nomeBase, dataModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return justificativa;
	}

	public void desconsiderarFlagObservacao(int idTB, String nomeBase, String dataModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.desconsiderarFlagObservacao(idTB, nomeBase, dataModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void considerarFlagObservacao(int idTB, String nomeBase, String dataModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.considerarFlagObservacao(idTB, nomeBase, dataModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public static ListsSoap sharePointListsAuth(String url) throws Exception {
		ListsSoap port = null;
		try {
			Lists service = new Lists();
			port = service.getListsSoap();
			((BindingProvider) port).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
					url);
		} catch (Exception e) {
			throw new Exception("Error: " + e.toString());
		}
		return port;
	}

	public static List<HashMap<String, String>> displaySharePointList(ListsSoap port, String listName,
			ArrayList<String> listColumnNames, String rowLimit, GetListItems getList, GetListItems.Query queryxml,
			GetListItems.QueryOptions queryxmloptions) throws Exception {

		List<HashMap<String, String>> allitems = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> items = new HashMap<String, String>();

		if (port != null && listName != null && listColumnNames != null && rowLimit != null) {
			try {

				// Calling the List Web Service
				GetListItemsResponse.GetListItemsResult result = port.getListItems(getList.getListName(),
						getList.getViewName(), queryxml, getList.getViewFields(), getList.getRowLimit(),
						queryxmloptions, getList.getWebID());
				Object listResult = result.getContent().get(0);
				if ((listResult != null) && (listResult instanceof ElementNSImpl)) {
					ElementNSImpl node = (ElementNSImpl) listResult;

					NodeList list = node.getElementsByTagName("z:row");

					for (int i = 0; i < list.getLength(); i++) {

						NamedNodeMap attributes = list.item(i).getAttributes();
						items = new HashMap<String, String>();

						for (String columnName : listColumnNames) {
							String internalColumnName = "ows_" + columnName;
							if (attributes.getNamedItem(internalColumnName) != null) {
								System.out.println(
										columnName + ": " + attributes.getNamedItem(internalColumnName).getNodeValue());

								items.put(columnName, attributes.getNamedItem(internalColumnName).getNodeValue());

							} else {
								throw new Exception("Couldn't find the '" + columnName + "' column in the '" + listName
										+ "' list in SharePoint.\n");
							}
						}
						allitems.add(items);
					}
				} else {
					throw new Exception(listName + " list response from SharePoint is either null or corrupt\n");
				}
			} catch (Exception ex) {
				throw new Exception("Exception. See stacktrace." + ex.toString() + "\n");
			}
			return allitems;
		}
		return allitems;
	}
	
	public void updateJustificativaPSI(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateJustificativaPSI(idTB, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
					dtJustificativaOld);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void updateJustificativaDuplicidade(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateJustificativaDuplicidade(idTB, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
					dtJustificativaOld);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void updateJustificativaDominio(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateJustificativaDominio(idTB, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
					dtJustificativaOld);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void updateJustificativaRange(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateJustificativaRange(idTB, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
					dtJustificativaOld);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void updateJustificativaMissing(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateJustificativaMissing(idTB, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
					dtJustificativaOld);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void updateJustificativaObservacao(int idTB, String nomeBase, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateJustificativaObservacao(idTB, nomeBase, dtJustificativa, dtModificacao, justificativa,
					dtJustificativaOld);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void updateJustificativaIntegridade(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO bDAO = sqlServer.getObjetoNotificacaoDAO();
			bDAO.updateJustificativaIntegridade(idTB, nomeBase, campo, dtJustificativa, dtModificacao, justificativa,
					dtJustificativaOld);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

}
