package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.RegraDAO;
import backgroundProcesses.tarefaDiaria;
import conectores.ConectorSAS;
import model.Base;
import model.ColunaTabela;
import model.Regra;
import model.Resposta;
import model.ServidorSAS;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONString;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class RegrasCadastrarServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		RequestDispatcher rd;

		List listaElementos = listaBasesRegras();

		// listarTodos() - listar todas as bases cadastradas
		List<Base> listaBases;
		listaBases = (List<Base>) listaElementos.get(0);
		request.setAttribute("listaDeBases", listaBases);

		List<Regra> listaRegras;
		listaRegras = (List<Regra>) listaElementos.get(1);
		request.setAttribute("listaDeRegras", listaRegras);

		int idCol = 0;
		int idRegra = 0;
		int idTb = 0;
		int contador = 0;

		if (request.getParameter("idCol") != null && request.getParameter("idRegra") != null) {
			idCol = Integer.parseInt(request.getParameter("idCol"));
			idRegra = Integer.parseInt(request.getParameter("idRegra"));
			idTb = Integer.parseInt(request.getParameter("idTb"));

			if (idCol > 0 && idRegra == 7) {
				int tipo = getTipoColuna(idCol);
				request.setAttribute("tipoCol", tipo);
				ArrayList<String> detalhes = new ArrayList<String>();
				detalhes = getDetalhesColunaPeloID(idCol);
				String[] detalheaux = detalhes.get(0).split(",");
				String[] detalhenew = new String[detalheaux.length - 1];
				String baseline = detalheaux[0];
				request.setAttribute("baseline", baseline);

				for (int i = 0; i < detalhenew.length; i++) {
					detalhenew[i] = detalheaux[i + 1];
				}

				if (tipo == 1) {
					ArrayList<String[]> faixas = new ArrayList<String[]>();
					int cont = 0;
					for (int i = 0; i < detalhenew.length / 2; i++) {
						String[] faixa = new String[2];
						for (int j = 0; j < faixa.length; j++) {
							faixa[j] = String.valueOf(new BigDecimal(detalhenew[cont]));
							cont++;
						}
						faixas.add(faixa);
					}
					request.setAttribute("faixas", faixas);
					contador = faixas.size();
					request.setAttribute("contador", contador);

					String[] valores_regra = new String[5 + faixas.size() * 2];
					valores_regra[0] = String.valueOf(idCol);
					valores_regra[1] = String.valueOf(idTb);
					valores_regra[2] = String.valueOf(idRegra);
					valores_regra[3] = baseline;
					valores_regra[4] = String.valueOf(tipo);
					int aux = 0;
					for (int i = 0; i < faixas.size(); i++) {
						for (int j = 0; j < 2; j++) {
							valores_regra[aux + 5] = String.valueOf(faixas.get(i)[j]);
							aux++;
						}
					}
					request.setAttribute("valores_regra", valores_regra);
				} else {

					ArrayList<String> faixas = new ArrayList<String>();
					for (int i = 0; i < detalhenew.length; i++) {
						faixas.add(detalhenew[i]);
					}
					request.setAttribute("faixas", faixas);
					contador = faixas.size();
					request.setAttribute("contador", contador);

					String[] valores_regra = new String[5 + faixas.size()];
					valores_regra[0] = String.valueOf(idCol);
					valores_regra[1] = String.valueOf(idTb);
					valores_regra[2] = String.valueOf(idRegra);
					valores_regra[3] = baseline;
					valores_regra[4] = String.valueOf(tipo);
					for (int i = 0; i < faixas.size(); i++) {
						valores_regra[i + 5] = faixas.get(i);
					}
					request.setAttribute("valores_regra", valores_regra);
				}

				request.setAttribute("idCol", idCol);
				request.setAttribute("contador", contador);
			}
		}
		request.setAttribute("idCol", idCol);
		request.setAttribute("contador", contador);

		rd = request.getRequestDispatcher("/WEB-INF/View/regrasCadastrar.jsp");
		try {
			rd.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/plain"); // Set content type of the response so that jQuery knows what it can
												// expect.
		response.setCharacterEncoding("UTF-8"); // You want world domination, huh?

		String headerName = request.getHeader("headerAjax").trim();
		System.out.println("header" + headerName + "colunas");

		if (headerName.equals("submit")) {
			Gson gson = new Gson();
			JsonObject json = gson.fromJson(request.getParameter("meuJson"), JsonObject.class);
			int tipo = json.get("tipo").getAsInt();
			int idTabela = json.get("idTabela").getAsInt();
			int idRegra = json.get("idRegra").getAsInt();
			int idColuna = json.get("idColuna").getAsInt();
			String matricula = json.get("matricula").getAsString();

			System.out.println("idtb: " + json.get("idTabela").getAsInt());
			Regra regra = new Regra();
			if (tipo == 1) { // regras gerais

				String detalhe = json.get("detalhe").getAsString();

				regra.setIdRegra(idRegra);
				regra.setIdColuna(idColuna);
				regra.setIdTabela(idTabela);
				regra.setDetalheRegra(detalhe);

			} else { // regras de range

				String range1 = json.get("range1").getAsString();
				String range2 = json.get("range2").getAsString();

				regra.setIdRegra(idRegra);
				regra.setIdColuna(idColuna);
				regra.setIdTabela(idTabela);
				regra.setDetalheRegra(range1);
				regra.setDetalheRegra2(range2);

			}
			Resposta resp = new Resposta();
			resp = inserirRegraDetalhe(tipo, regra, matricula);

			out.write(resp.getMensagem() + ";" + resp.getTipo());
		} else if (headerName.equals("submitDUP")) {
			Gson gson = new Gson();
			JsonObject json = gson.fromJson(request.getParameter("meuJson"), JsonObject.class);
			int tipo = json.get("tipo").getAsInt();
			int idTabela = json.get("idTabela").getAsInt();
			int idRegra = json.get("idRegra").getAsInt();
			int idColuna = json.get("idColuna").getAsInt();
			String matricula = json.get("matricula").getAsString();

			System.out.println("idtb: " + tipo);
			Regra regra = new Regra();

			String detalhe = json.get("detalhe").getAsString();

			regra.setIdRegra(idRegra);
			regra.setIdColuna(idColuna);
			regra.setIdTabela(idTabela);
			regra.setDetalheRegra(detalhe);

			if (idRegra == 6) {
				String[] multiIds = json.get("multiColunas").getAsString().split(",");
				regra.setMultiIds(multiIds);
			}

			Resposta resp = new Resposta();
			resp = inserirRegraDuplicidade(tipo, regra, matricula);

			out.write(resp.getMensagem() + ";" + resp.getTipo());

		} else if (headerName.equals("submitPSI")) {

			Gson gson = new Gson();
			JsonObject json = gson.fromJson(request.getParameter("json"), JsonObject.class);
			int tipo = json.get("tipo").getAsInt();
			int idTabela = json.get("idTabela").getAsInt();
			int idRegra = json.get("idRegra").getAsInt();
			int idColuna = json.get("idColuna").getAsInt();
			String nmColuna = json.get("nmcoluna").getAsString();
			String matricula = json.get("matricula").getAsString();

			System.out.println("idtb: " + tipo);
			Regra regra = new Regra();

			ConectorSAS sas = new ConectorSAS();
			tarefaDiaria tarefa = new tarefaDiaria();

			ServidorSAS servSAS = tarefa.getServidorSASByIdTabela(idTabela);
			try {
				sas.iniciar("", "", servSAS.getHostName(), servSAS.getPorta());
				
				
				if (!sas.getLog().contains("Falha na conex�o com o servidor")) {

					if (tipo == 3) {

						String baseline = json.get("baseline").getAsString();

						int contador = json.get("contador").getAsInt();
						Resposta resp = null;
						String detalhe = baseline;

						JsonArray min = json.get("min").getAsJsonArray();
						JsonArray max = json.get("max").getAsJsonArray();

						for (int i = 0; i < contador; i++) {

							detalhe += "," + min.get(i).toString().replace("\"", "") + ","
									+ max.get(i).toString().replace("\"", "");
						}

						regra = new Regra();
						regra.setIdTabela(idTabela);
						regra.setIdRegra(idRegra);
						regra.setIdColuna(idColuna);
						regra.setDetalheRegra(detalhe);

						ColunaTabela coluna = new ColunaTabela();
						coluna.setIdColuna(idColuna);
						coluna.setTipoColuna(1);
						coluna.setNomeColuna(nmColuna);
						coluna.addRegra(regra);

						Base base = getBase(idTabela);
						String lib = "\"" + base.getConexao() + "\"";

						ArrayList<ArrayList<String>> freq = tarefa.prepararDadosPSISAS(sas, lib, baseline, coluna, 1);
						ArrayList<ArrayList<String>> tabela = new ArrayList<ArrayList<String>>();
						tabela = sas.baseSAS("SELECT * FROM WORK.MAX_MIN");
						regra.setDetalheRegra2(freq.toString().replace("[", "").replace("]", ""));
						resp = new Resposta();

						if (Double.parseDouble(tabela.get(0).get(0)) > Double
								.parseDouble(max.get(max.size() - 1).toString().replace("\"", ""))
								&& Double.parseDouble(tabela.get(0).get(1)) < Double
										.parseDouble(min.get(1).toString().replace("\"", ""))) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores valores fora da faixa.\n Valores:"
											+ tabela.toString().replace("[", "").replace("]", ""));
							resp.setTipo(2);
						} else if (Double.parseDouble(tabela.get(0).get(1)) < Double
								.parseDouble(min.get(0).toString().replace("\"", ""))) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores valores fora da faixa.\n Valores:"
											+ new BigDecimal(tabela.get(0).get(1)).longValue());
							resp.setTipo(2);
						} else if (Double.parseDouble(tabela.get(0).get(0)) > Double
								.parseDouble(max.get(max.size() - 1).toString().replace("\"", ""))) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores valores fora da faixa.\n Valores:"
											+ new BigDecimal(tabela.get(0).get(0)).longValue());
							resp.setTipo(2);
						} else {
							resp = inserirRegraDetalhe(tipo, regra, matricula);
						}
						//sas.encerrar();
						out.write(resp.getMensagem() + ";" + resp.getTipo());

						// Tipo=4 quando a coluna � tipo num�rico para a PSI
					} else if (tipo == 4) {

						String baseline = json.get("baseline").getAsString();

						int contador = json.get("contador").getAsInt();
						Resposta resp = null;
						String detalhe = baseline;

						JsonArray valor = json.get("valor").getAsJsonArray();

						for (int i = 0; i < contador; i++) {
							detalhe += "," + valor.get(i);
						}

						regra = new Regra();
						regra.setIdTabela(idTabela);
						regra.setIdRegra(idRegra);
						regra.setIdColuna(idColuna);
						regra.setDetalheRegra(detalhe);

						ColunaTabela coluna = new ColunaTabela();
						coluna.setIdColuna(idColuna);
						coluna.setTipoColuna(2);
						coluna.setNomeColuna(nmColuna);
						coluna.addRegra(regra);

						Base base = getBase(idTabela);
						String lib = base.getConexao();

						ArrayList<ArrayList<String>> freq = tarefa.prepararDadosPSISAS(sas, lib, baseline, coluna, 1);
						ArrayList<ArrayList<String>> tabela = new ArrayList<ArrayList<String>>();
						tabela = sas.baseSAS("SELECT * FROM WORK.VALORES_FORA");

						String[] freq_inc = new String[freq.size()];
						for (int i = 0; i < freq_inc.length; i++) {
							freq_inc[i] = freq.get(0).get(i);
						}

						regra.setDetalheRegra2(freq_inc.toString());
						resp = new Resposta();

						if (tabela.size() > 0) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores valores fora da faixa.\n Valores:"
											+ tabela.toString().replace("[", "").replace("]", ""));
							resp.setTipo(2);
						} else {
							resp = inserirRegraDetalhe(tipo, regra, matricula);
						}
						//sas.encerrar();
						out.write(resp.getMensagem() + ";" + resp.getTipo());
					}
				} else {
					Resposta resp = new Resposta();
					resp.setMensagem(
							"N�o foi poss�vel inserir a m�trica, pois o servidor SAS est� fora do ar. Por favor tente mais tarde!");
					resp.setTipo(2);
					out.write(resp.getMensagem() + ";" + resp.getTipo());
				}
				//sas.encerrar();				
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				sas.encerrar();
			}

		} else if (headerName.equals("colunas")) {
			int id = Integer.parseInt(request.getParameter("id"));
			List<ColunaTabela> listaColunas;

			listaColunas = getColunasPeloID(id);
			Gson gson = new Gson();
			String json = gson.toJson(listaColunas);

			out.write(json); // Write response body.

		} else if (headerName.equals("detalhes")) {
			int idTb = Integer.parseInt(request.getParameter("idTb"));
			int idCol = Integer.parseInt(request.getParameter("idCol"));
			int idRegra = Integer.parseInt(request.getParameter("idRegra"));

			System.out.println("TESTE TESTE TESTE TESTE");

			Regra regra;
			regra = getDetalheRegraById(idTb, idCol, idRegra);

			String resposta = regra.getDetalheRegra() + ";" + regra.getDetalheRegra2();

			out.write(resposta);

		} else if (headerName.equals("edit")) { // update na tabela
			Gson gson = new Gson();
			JsonObject json = gson.fromJson(request.getParameter("meuJson"), JsonObject.class);
			int tipo = json.get("tipo").getAsInt();
			int idTabela = json.get("idTabela").getAsInt();
			int idRegra = json.get("idRegra").getAsInt();
			int idColuna = json.get("idColuna").getAsInt();
			String matricula = json.get("matricula").getAsString();

			System.out.println("idtb: " + tipo);
			Regra regra = new Regra();
			if (tipo == 1) { // regras gerais

				String detalhe = json.get("detalhe").getAsString();

				regra.setIdRegra(idRegra);
				regra.setIdColuna(idColuna);
				regra.setIdTabela(idTabela);
				regra.setDetalheRegra(detalhe);

			} else { // regras de range

				String range1 = json.get("range1").getAsString();
				String range2 = json.get("range2").getAsString();

				regra.setIdRegra(idRegra);
				regra.setIdColuna(idColuna);
				regra.setIdTabela(idTabela);
				regra.setDetalheRegra(range1);
				regra.setDetalheRegra2(range2);

			}
			Resposta resp = new Resposta();
			resp = updateRegraDetalhe(tipo, regra, matricula);

			out.write(resp.getMensagem() + ";" + resp.getTipo());
		} else if (headerName.equals("editPSI")) { // update na tabela
			Gson gson = new Gson();
			JsonObject json = gson.fromJson(request.getParameter("json"), JsonObject.class);
			int tipo = json.get("tipo").getAsInt();
			int idTabela = json.get("idTabela").getAsInt();
			int idRegra = json.get("idRegra").getAsInt();
			int idColuna = json.get("idColuna").getAsInt();
			String nmColuna = json.get("nmcoluna").getAsString();
			String matricula = json.get("matricula").getAsString();

			System.out.println("idtb: " + tipo);
			Regra regra = new Regra();

			ConectorSAS sas = new ConectorSAS();
			tarefaDiaria tarefa = new tarefaDiaria();

			ServidorSAS servSAS = tarefa.getServidorSASByIdTabela(idTabela);
			try {
				sas.iniciar("", "", servSAS.getHostName(), servSAS.getPorta());
				
				if (!sas.getLog().contains("Falha na conex�o com o servidor")) {

					if (tipo == 3) {

						String baseline = json.get("baseline").getAsString();

						int contador = json.get("contador").getAsInt();
						Resposta resp = null;
						String detalhe = baseline;

						JsonArray min = json.get("min").getAsJsonArray();
						JsonArray max = json.get("max").getAsJsonArray();

						for (int i = 0; i < contador; i++) {

							detalhe += "," + min.get(i).toString().replace("\"", "") + ","
									+ max.get(i).toString().replace("\"", "");
						}

						regra = new Regra();
						regra.setIdTabela(idTabela);
						regra.setIdRegra(idRegra);
						regra.setIdColuna(idColuna);
						regra.setDetalheRegra(detalhe);

						ColunaTabela coluna = new ColunaTabela();
						coluna.setIdColuna(idColuna);
						coluna.setTipoColuna(1);
						coluna.setNomeColuna(nmColuna);
						coluna.addRegra(regra);

						Base base = getBase(idTabela);
						String lib = "\"" + base.getConexao() + "\"";

						ArrayList<ArrayList<String>> freq = tarefa.prepararDadosPSISAS(sas, lib, baseline, coluna, 1);

						if (freq.size() < contador) {
							int tam = contador - freq.size();
							for (int i = 0; i < tam; i++) {
								ArrayList<String> novasFreqs = new ArrayList<String>();
								novasFreqs.add("0");
								novasFreqs.add(baseline);
								freq.add(novasFreqs);
							}
						}

						ArrayList<ArrayList<String>> tabela = new ArrayList<ArrayList<String>>();
						tabela = sas.baseSAS("SELECT * FROM WORK.MAX_MIN");
						regra.setDetalheRegra2(freq.toString().replace("[", "").replace("]", ""));
						resp = new Resposta();

						if (Double.parseDouble(tabela.get(0).get(0)) > Double
								.parseDouble(max.get(max.size() - 1).toString().replace("\"", ""))
								&& Double.parseDouble(tabela.get(0).get(1)) < Double
										.parseDouble(min.get(0).toString().replace("\"", ""))) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores valores fora da faixa.\n Valores:"
											+ tabela.toString().replace("[", "").replace("]", "")
											+ "Favor, rever os valores das faixas e/ou Baseline.");
							resp.setTipo(2);
						} else if (Double.parseDouble(tabela.get(0).get(1)) < Double
								.parseDouble(min.get(0).toString().replace("\"", ""))) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores valores fora da faixa.\n Valores:"
											+ new BigDecimal(tabela.get(0).get(1)).longValue()
											+ "Favor, rever os valores das faixas e/ou Baseline.");
							resp.setTipo(2);
						} else if (Double.parseDouble(tabela.get(0).get(0)) > Double
								.parseDouble(max.get(max.size() - 1).toString().replace("\"", ""))) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores valores fora da faixa.\n Valores:"
											+ new BigDecimal(tabela.get(0).get(0)).longValue()
											+ "Favor, rever os valores das faixas e/ou Baseline.");
							resp.setTipo(2);
						} else {
							resp = updateRegraDetalhe(tipo, regra, matricula);
						}
						//sas.encerrar();
						out.write(resp.getMensagem() + ";" + resp.getTipo());

						// Tipo=4 quando a coluna � tipo num�rico para a PSI
					} else if (tipo == 4) {

						String baseline = json.get("baseline").getAsString();

						int contador = json.get("contador").getAsInt();
						Resposta resp = null;
						String detalhe = baseline;

						JsonArray valor = json.get("valor").getAsJsonArray();

						for (int i = 0; i < contador; i++) {
							detalhe += "," + valor.get(i);
						}

						regra = new Regra();
						regra.setIdTabela(idTabela);
						regra.setIdRegra(idRegra);
						regra.setIdColuna(idColuna);
						regra.setDetalheRegra(detalhe);

						ColunaTabela coluna = new ColunaTabela();
						coluna.setIdColuna(idColuna);
						coluna.setTipoColuna(2);
						coluna.setNomeColuna(nmColuna);
						coluna.addRegra(regra);

						Base base = getBase(idTabela);
						String lib = base.getConexao();

						ArrayList<ArrayList<String>> freq = tarefa.prepararDadosPSISAS(sas, lib, baseline, coluna, 1);
						ArrayList<ArrayList<String>> tabela = new ArrayList<ArrayList<String>>();
						tabela = sas.baseSAS("SELECT * FROM WORK.VALORES_FORA");

						String[] freq_inc = new String[freq.size()];
						for (int i = 0; i < freq_inc.length; i++) {
							freq_inc[i] = freq.get(0).get(i);
						}

						regra.setDetalheRegra2(freq_inc.toString());
						resp = new Resposta();

						if (tabela.size() > 0) {
							resp.setMensagem(
									"N�o foi poss�vel inserir a m�trica, pois existem valores fora da faixa.\n Valores:"
											+ tabela.toString().replace("[", "").replace("]", "")
											+ "Favor, rever os valores das faixas e/ou Baseline.");
							resp.setTipo(2);
						} else {
							resp = updateRegraDetalhe(tipo, regra, matricula);
						}
						//sas.encerrar();
						out.write(resp.getMensagem() + ";" + resp.getTipo());

					}
				} else {
					Resposta resp = new Resposta();
					resp.setMensagem(
							"N�o foi poss�vel inserir a m�trica, pois o servidor SAS est� fora do ar. Por favor tente mais tarde!");
					resp.setTipo(2);
					out.write(resp.getMensagem() + ";" + resp.getTipo());
				}
				//sas.encerrar();				
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				sas.encerrar();
			}
		}

	}

	public Base getBase(int id) {

		GerenciadorDeConexao sqlServer = null;
		Base base;
		base = new Base();
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			base = baseDAO.getBasePeloID(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		return base;

	}

	// lista todas as bases cadastradas
	private List<Base> listarTodos() {
		GerenciadorDeConexao sqlServer = null;
		List<Base> listaBases;
		listaBases = new ArrayList();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			listaBases = baseDAO.listarTodos();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaBases;

	}

	// lista as regras, mas n�o seus detalhes
	private List<Regra> listarRegras() {
		GerenciadorDeConexao sqlServer = null;
		List<Regra> listaRegras;
		listaRegras = new ArrayList();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			listaRegras = regraDAO.listarRegras();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaRegras;
	}

	// lista regras e bases de uma vez s� para aumentar a performance
	private List listaBasesRegras() {
		List listaElementos = new ArrayList();

		GerenciadorDeConexao sqlServer = null;
		try {
			List<Regra> listaRegras;
			listaRegras = new ArrayList();
			List<Base> listaBases;
			listaBases = new ArrayList();

			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			listaRegras = regraDAO.listarRegras();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			listaBases = baseDAO.listarTodos();

			listaElementos.add(listaBases);
			listaElementos.add(listaRegras);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaElementos;
	}

	// esse metodo ser� utilizado quando o usu�rio escolher uma base, ent�o
	// atualizando a lista de colunas daquela base para o usu�rio
	private List<ColunaTabela> getColunasPeloID(int id) {

		GerenciadorDeConexao sqlServer = null;
		List<ColunaTabela> colunas;

		try {
			colunas = new ArrayList();
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO base = sqlServer.getObjetoBase();
			colunas = base.getColunasPeloID(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return colunas;
	}

	private Resposta inserirRegraDuplicidade(int tipo, Regra regra, String matricula) {

		Resposta resp = new Resposta();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			resp = regraDAO.inserirRegraDuplicidade(tipo, regra, matricula);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return resp;
	}

	private Resposta inserirRegraDetalhe(int tipo, Regra regra, String matricula) {

		Resposta resp = new Resposta();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			resp = regraDAO.inserirRegraDetalhe(tipo, regra, matricula);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return resp;
	}

	private Regra getDetalheRegraById(int idTb, int idCol, int idRegra) {
		Regra regra = new Regra();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			regra = regraDAO.getDetalheRegraById(idTb, idCol, idRegra);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return regra;
	}

	private Resposta updateRegraDetalhe(int tipo, Regra regra, String matricula) {
		Resposta resp = new Resposta();

		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			resp = regraDAO.updateRegraDetalhe(tipo, regra, matricula);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return resp;
	}

	public int getTipoColuna(int idCol) {
		GerenciadorDeConexao sqlServer = null;
		int tipo = 0;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			tipo = regraDAO.getTipoColuna(idCol);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return tipo;
	}

	public ArrayList<String> getDetalhesColunaPeloID(int idCol) {
		GerenciadorDeConexao sqlServer = null;
		ArrayList<String> detalhes = new ArrayList<String>();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			detalhes = regraDAO.getDetalhesColunaPeloID(idCol);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return detalhes;
	}
}
