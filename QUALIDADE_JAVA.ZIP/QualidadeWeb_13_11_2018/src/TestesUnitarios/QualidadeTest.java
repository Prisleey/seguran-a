package TestesUnitarios;

import static org.junit.Assert.*;

import org.junit.Test;

import backgroundProcesses.tarefaDiaria;
import model.Base;

public class QualidadeTest {
	
	@Test
	public void testarGetBasePeloId() {
		/*
		 	testa se o metodo getBasePeloId est� retornando um objeto do tipo base, como deveria
		 */
		tarefaDiaria tf = new tarefaDiaria();
		Base baseReal = tf.getBasePeloId(1);
		assertTrue(baseReal instanceof Base);
	}
}
