package backgroundProcesses;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;


//executa a qualidade em um intervalo de tempo pr� definido

@WebListener
public class ExecutorQualidade implements ServletContextListener {

	 private ScheduledExecutorService scheduler;

	 
	 @Override
	public void contextInitialized(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		scheduler = Executors.newScheduledThreadPool(4);
		System.out.println("Executor Qualidade");
		scheduler.scheduleAtFixedRate(new ThreadAuxiliar(), 0, 03, TimeUnit.HOURS); //roda a qualidade a cada 3 horas.
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		scheduler.shutdownNow();
	}

	

}
