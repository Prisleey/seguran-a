package backgroundProcesses;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/*thread secundaria que inicia a thread principal.
 * tem como objetivo permitir que N threads de qualidade rodem ao mesmo tempo.
 * Com apenas um scheduler, � apenas possivel rodar 1 thread por vez, por isso precisamos das 2 para rodar N threads.
 */
public class ThreadAuxiliar implements Runnable {
	
	private ExecutorService executorService;
	
	@Override
	public void run() {
		// TODO Auto-generated method stub

		

		Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		
		executorService = Executors.newCachedThreadPool();
		executorService.submit(new QualidadeAutomatica());
		
		//new Thread(new QualidadeAutomatica()).start(); //inicia uma nova instancia da thread da qualidade.
		
		/*
		 NAO � MAIS NECESSARIO
		ScheduledExecutorService scheduler;
		scheduler = Executors.newSingleThreadScheduledExecutor();
		scheduler.scheduleAtFixedRate(new QualidadeAutomatica(), 0, 1, TimeUnit.SECONDS);
		*/
		 
	}

}
