package backgroundProcesses;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimerTask;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import com.sas.iom.SASIOMDefs.GenericError;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.NotificacaoDAO;
import DAO.ObservacaoDAO;
import DAO.RegraDAO;
import conectores.ConectorSAS;
import model.Base;
import model.ColunaTabela;
import model.Email;
import model.Notificacao;
import model.Observacao;
import model.ObservacaoDiario;
import model.Regra;
import model.Resposta;
import model.ServidorSAS;
import model.Setor;
import model.StatusBases;;

//Thread que contem o processo de qualidade.
public class QualidadeAutomatica implements Runnable {

	long tempoInicio = System.currentTimeMillis();
	private volatile boolean shutdown;
	private int statusObservacao;
	private int statusIntegridade;
	private int statusDuplicidade;
	private int statusDominio;
	private int statusMissing;
	private int statusRange;
	private int statusPSI;
	List<StatusBases> statusBases;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void run() {
		ConectorSAS sas = new ConectorSAS();

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

		// por enquanto, como apenas rodamos SAS, eu verifico direto se a qualidade do
		// SAS est� ativa.
		if (qualidadeEstaAtiva("SAS")) {
			System.out.println("QUALIDADE ATIVA!");
			System.out.println("FOI, COME�OOU A THREAD: " + sdf.format(cal.getTime()));

			ServidorSAS servSAS = getServidorSASByIdTabela(18);
			try {
				sas.iniciar("", "", servSAS.getHostName(), servSAS.getPorta());
				try {
					String log = sas.ComandoSAS("libname TESTE '/sasdata/DGD/bi/';");
					if (!log.contains("successfully assigned as follows")) {
						System.out.println("SAS est� inoperante!!");
						shutdown();
					} else {
						System.out.println("SAS est� OK!!");
					}
				} catch (GenericError e) {
					e.printStackTrace();
				}
			} catch (IOException e) {

				e.printStackTrace();
			} finally {
				sas.encerrar();				
			}
			while (!shutdown) {
				// PROCESSO DE VERIFICACAO DE NOVAS BASES NA QUALIDADE

				// String dataUltimaBaseSAS = getUltimaDataBaseSAS(); // pega a data da ultima
				// base sas que rodou no
				// // sistema
				// ArrayList<ArrayList<String>> novasBasesSAS =
				// getNovasBasesSAS(dataUltimaBaseSAS);
				// List<List<String>> basesCadastradasSAS = getAtributosBases("SAS");
				// List basesRodar = new ArrayList();
				// List basesNaoCadastradas = new ArrayList();
				//
				// int cont2 = 1;
				// for (ArrayList<String> obj : novasBasesSAS) {
				// String nomeBase = obj.get(0).trim().toUpperCase();
				// String caminhoBase = obj.get(2).trim();
				//
				// boolean achouBase = false;
				//
				// // checa se as novas bases est�o cadastradas no sistema, caso n�o esteja
				// manda
				// // um email para os monitores.
				// if (checarSeBaseExiste(nomeBase) == 1) {
				// // novas bases que tem um modelo cadastrado
				// System.out.println("CONTEM");
				// basesRodar.add(new Base(nomeBase, caminhoBase));
				// achouBase = true;
				// } else {
				// System.out.println("NAO CONTEM. IR� CADASTRAR A BASE: " + nomeBase);
				// String conexao = obj.get(2).trim();
				// String increm_full = obj.get(3).trim();
				// String periodicidade = obj.get(4).trim();
				// String safrada = obj.get(5).trim();
				// int safra = 0;
				// if (safrada.equals("1.0")) {
				// safra = 1;
				// }
				// String matResponsavel = "i354217";
				// String emailResponsavel = "adrean.cebola@bradesco.com.br";
				// String tipoBase = "SAS";
				// Double limSup = 3.0;
				// Double limInf = -3.0;
				// int setorBase = 1;
				// int tipoLayout = 1; // 1 - automatico, 2 - manual
				// String nomeBaseLayout = obj.get(1).trim();
				//
				// ColunaTabela coluna;
				// List<ColunaTabela> listaColunas;
				// listaColunas = new ArrayList();
				//
				// List<ColunaTabela> listaColunas_cadastrar;
				// listaColunas_cadastrar = new ArrayList();
				//
				// Resposta resultadoOperacao = new Resposta();
				// Base base = new Base();
				//
				// base.setNomeBase(nomeBase);
				// base.setConexao(conexao);
				// base.setMatriculaResponsavel(matResponsavel);
				// base.setEmailResponsavel(emailResponsavel);
				// base.setTipoBase(tipoBase);
				// base.setSetor(new Setor(setorBase)); // como a base tem um objeto setor, mas
				// s� me interessa
				// // o ID, eu passo um objeto com o segundo construtor
				// // que s� necessita do ID.
				// base.setLimiteSuperior(limSup);
				// base.setLimiteInferior(limInf);
				// base.setTipoLayout(tipoLayout);
				// base.setPeriodicidade(periodicidade);
				// base.setSafrada(safra);
				// base.setIncrem_full(increm_full);
				// base.setNomeBaseLayout(nomeBaseLayout);
				// if (periodicidade.equals("Di�ria")) {
				// base.setTamanhoAmostra(30);
				// } else if (periodicidade.equals("Mensal")) {
				// base.setTamanhoAmostra(6);
				// } else if (periodicidade.equals("Semanal")) {
				// base.setTamanhoAmostra(12);
				// } else if (periodicidade.equals("Quinzenal")) {
				// base.setTamanhoAmostra(8);
				// } else if (periodicidade.equals("Trimestral")) {
				// base.setTamanhoAmostra(3);
				// } else if (periodicidade.equals("Semestral")) {
				// base.setTamanhoAmostra(2);
				// } else if (periodicidade.equals("Anual")) {
				// base.setTamanhoAmostra(2);
				// }
				//
				// ServidorSAS serv = new ServidorSAS();
				// serv.setIdServidor(4);
				// base.setServidorSAS(serv);
				//
				// String matriculaUpdate = "i-354217";
				//
				// // CRIANDO A COLUNA GENERICA NA QUAL SERAO ATRELADAS AS METRICAS DE
				// OBSERVACAO E
				// // DUPLICIDADE NAS NOTIFICACOES
				// ColunaTabela colGenerica = new ColunaTabela();
				// colGenerica.setNomeColuna("BASE_TODA");
				// colGenerica.setTipoColuna(1); // tanto faz o tipo, essa coluna n�o ser�
				// considerada na
				// // integridade.
				// colGenerica.setTamanhoColuna(0);
				// colGenerica.setNumOrdem(0);
				// colGenerica.setColunaAutomatica(2); // coluna generica
				// listaColunas.add(colGenerica); // add a coluna generica na lista, antes de
				// adicionar as
				// // demais.
				// listaColunas_cadastrar = sas.getLayoutBaseSAScontador(conexao,
				// nomeBaseLayout, cont2);
				//
				// for (int i = 0; i < listaColunas_cadastrar.size(); i++) {
				// coluna = new ColunaTabela();
				// coluna.setNomeColuna(listaColunas_cadastrar.get(i).getNomeColuna());
				// coluna.setTipoColuna(listaColunas_cadastrar.get(i).getTipoColuna());
				// coluna.setTamanhoColuna(listaColunas_cadastrar.get(i).getTamanhoColuna());
				// coluna.setNumOrdem(i + 1);
				// coluna.setColunaAutomatica(1);
				// listaColunas.add(coluna);
				// }
				//
				// int novoID = 0;
				// try {
				// novoID = inserirTabela(base, matriculaUpdate);
				// } catch (Exception ex) {
				// resultadoOperacao.setMensagem("Ocorreu um erro ao inserir a base: " +
				// ex.getMessage());
				// resultadoOperacao.setTipo(2); // erro
				// throw new NullPointerException("Ocorreu um erro ao inserir a base: " +
				// ex.getMessage());
				// }
				//
				// if (novoID > 0) {
				// /*
				// * ultimo paramentro n�o � a matricula do resposavel pela base, e sim a
				// * matricula de quem inseriu ou modificou ela, como uma log
				// */
				// resultadoOperacao = inserirColunas(listaColunas, novoID, matriculaUpdate);
				// } else {
				// resultadoOperacao.setMensagem("Ouve um erro ao inserir a base");
				// resultadoOperacao.setTipo(2); // erro
				// }
				//
				// System.out.println("conexao: " + conexao);
				//
				// }
				// if (!achouBase) { // caso nao tenha achado a base, adiciona a lsita de bases
				// a cadastrar
				// basesNaoCadastradas.add(new Base(nomeBase, caminhoBase));
				// }
				// cont2++;
				// }
				//
				// // inserindo as bases novas
				//
				// InsereNovasBasesAutomaticas(basesRodar, "SAS");
				// if (!novasBasesSAS.isEmpty()) {
				// String dataUltimaBase = novasBasesSAS.get(0).get(7).trim().substring(0, 19);
				// System.out.println("CHEGOU AO FIM: " + dataUltimaBase);
				// updateQualidadeLastRun(dataUltimaBase, "SAS");
				// }
				//
				// if (!basesNaoCadastradas.isEmpty()) { // se a lista NAO esta vazia, envia o
				// email
				// enviaEmailBasesSemCadastro(basesNaoCadastradas,
				// "adrean.cebola@bradesco.com.br");
				// }

				// COME�A A QUALIDADE DE FATO
				try {

					updateQualidadeRunning(1);
					List<Regra> regras;
					double[] nobs2 = null;
					String[] datas = null;
					String[] modate = null;

					// String lib = "'/sasdata/DPOC/comum/ALM_CDI/FUNDOS/BASES'";
					// String base = "'FUND_03001_2018'";

					// lista das bases cadastradas no sistema, que ser�o parametro para o que o
					// sistema vai rodar em qualidade
					List<Base> listaBasesCadastradas = listarTodos();
					List listaElementos = new ArrayList();
					List<Base> bases = new ArrayList();

					for (Base obj : listaBasesCadastradas) {
						statusBases = new ArrayList();
						statusObservacao = 0;
						statusIntegridade = 0;
						statusDuplicidade = 0;
						statusDominio = 0;
						statusMissing = 0;
						statusRange = 0;
						statusPSI = 0;
						String tipoDaBase = obj.getTipoBase();
						String base = obj.getNomeBase();
						System.out.println("ENTROU NA BASE: " + base);
						String test = "";
						switch (tipoDaBase) {

						case "SAS": // no caso da base ser do tipo SAS

//							if (jaExecutouQualidade(obj.getIdTabela())) {
//								System.out.println("ESSA BASE J� PASSOU PELA QUALIDADE");
//							} else {

								System.out.println("Entrou no SAS: " + tipoDaBase);
								long tempoInicioPrep = System.currentTimeMillis();

								servSAS = getServidorSASByIdTabela(obj.getIdTabela());
								try {
									sas.iniciar("", "", servSAS.getHostName(), servSAS.getPorta());
									String log = sas.getLog();
									if (!log.contains("You are running SAS 9.")) {
										System.out.println("SAS est� inoperante!!");
										shutdown();
									} else {
										System.out.println("SAS est� OK!!");
										
										// String baseCadastro = "";
										// String[] basesSplit = obj.getNomeBase().trim().split("_");
										// if (basesSplit[basesSplit.length - 1].contains("AAAA")) {
										// for (int i = 0; i < basesSplit.length - 1; i++) {
										// baseCadastro += basesSplit[i] + "_";
										// }
										// } else {
										// for (int i = 0; i < basesSplit.length; i++) {
										// baseCadastro += basesSplit[i] + "_";
										// }
										// }

										// List<String> basesQueVaoRodar =
										// gerarListaBasesRodarAutomatico(obj.getNomeBase(),
										// "SAS"); // pega//
										// do//
										// BASES_RUN_AUTOMATICA
										// List<String> basesQueVaoRodar = new ArrayList<String>();
										// if (!basesQueVaoRodar.isEmpty()) {
										// if (!sas.getLog().contains("Falha na conex�o com o servidor")) {
										// int baseJaRodou;
										// int contErros = 0;
										//
										// String stringBases = basesQueVaoRodar.toString();
										// // retirando os [] da string
										// stringBases = stringBases.substring(2, stringBases.length() - 2);
										// String lib = "";
										// if (obj.getConexao().length() > 9) {
										// lib = "'" + obj.getConexao() + "'";
										// } else {
										// lib = obj.getConexao();
										// }
										// String base2 = obj.getNomeBase();
										// List nomesDasBases = new ArrayList();
										// Base baseOrigem;
										// int numNotif = 0;
										// double qtdeReg = 0;
										//
										// baseOrigem = getBasePeloId(obj.getIdTabela());
										// String ultimaData = "";
										// ultimaData = getUltimaInsercaoRegbyId(obj.getIdTabela());
										// int tamanho_amostra = obj.getTamanhoAmostra();
										// // pega os nobs no caso de a base ser do sas
										// if ((obj.getPeriodicidade().equals("Mensal")
										// || obj.getPeriodicidade().equals("Trimestral")
										// || obj.getPeriodicidade().equals("Semestral"))
										// && obj.getSafrada() == 0) {
										// if (ultimaData == null || ultimaData == "") {
										// ultimaData = "0";
										// } else {
										// ultimaData = ultimaData.substring(0, 4) + ultimaData.substring(5, 7);
										// }
										// listaElementos = nobsBasesSASMensal(sas, lib, base2, ultimaData);
										// } else if ((obj.getPeriodicidade().equals("Di�ria")
										// || obj.getPeriodicidade().equals("Semanal")
										// || obj.getPeriodicidade().equals("Quinzenal"))
										// && obj.getSafrada() == 0) {
										// if (ultimaData == null || ultimaData == "") {
										// ultimaData = "0";
										// } else {
										// ultimaData = ultimaData.substring(3, 4) + ""
										// + ultimaData.substring(5, 7) + ultimaData.substring(8, 10);
										// }
										// listaElementos = nobsBasesSAS(sas, lib, base2, ultimaData);
										// } else if (obj.getSafrada() > 0 &&
										// obj.getIncrem_full().equals("INCREMENTAL")) {
										//
										// if (getQtdeRegBaseNSafrada(obj.getIdTabela()) > 0) {
										// qtdeReg = getQtdeRegBaseNSafrada(obj.getIdTabela());
										// }
										// listaElementos = nobsBasesSASNSafradaIncre(sas, lib, base2, qtdeReg);
										//
										// } else if (obj.getSafrada() > 0 && obj.getIncrem_full().equals("FULL")) {
										// SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
										//
										// listaElementos = nobsBasesSASNSafradaFull(sas, lib, base2);
										// datas = (String[]) listaElementos.get(1);
										// try {
										// Date data1 = formatter.parse(datas[0]);
										// if (ultimaData != "" && ultimaData != null) {
										// if (data1.after(formatter.parse(ultimaData))
										// || data1.equals(formatter.parse(ultimaData))) {
										// break;
										// }
										// }
										// } catch (ParseException e) {
										// e.printStackTrace();
										// }
										// } else {
										// break;
										// }
										//
										// nobs2 = (double[]) listaElementos.get(0);
										// datas = (String[]) listaElementos.get(1);
										// nomesDasBases = (List<String>) listaElementos.get(2);
										// modate = (String[]) listaElementos.get(3);
										// int idBaseToda = 0;
										// idBaseToda = getidBaseToda(obj.getIdTabela());
										// /*
										// * inicialmente rodar� integridade e observa��o na base como um todo
										// * obrigatoriamente. em seguida ir� coluna por coluna rodando as regras
										// * cadastradas para as colunas da tabela.
										// */
										//
										// // conec sas
										// if (nobs2.length >= 1 && nobs2[0] >= 0) {
										// System.out.println("**************** vai calc obs");
										// ArrayList<Double> nobs_amostra = getAmostraParaCalPorID(obj.getIdTabela(),
										// tamanho_amostra - 1);
										// ArrayList<Double> range_amostra = getRangeParaCalPorID(obj.getIdTabela(),
										// tamanho_amostra - 1);
										// ArrayList<Double> range_media = getRangeMediaParaCalPorID(obj.getIdTabela(),
										// tamanho_amostra - 1);
										//
										// ArrayList<Double> nobs_amostra_new;
										//
										// for (int i = 0; i < nobs2.length; i++) {
										// nobs_amostra_new = new ArrayList<Double>();
										// nobs_amostra.add(nobs2[i]);
										// for (int j = 0; j < tamanho_amostra; j++) {
										// nobs_amostra_new.add(nobs_amostra.get(i + j));
										// }
										// statusBases.add(calcObservacao(obj.getIdTabela(), idBaseToda,
										// nobs_amostra_new, range_amostra, range_media, modate,
										// nomesDasBases, i, tamanho_amostra, modate, obj));
										// }
										// }
										//
										// // conec sas - Prepara a base SAS para a regra de integridade
										// System.out.println("**************** vai preparar base integridade");
										// bases = preparaBaseIntegridadeSAS(sas, lib, stringBases); // bases que ser�o
										// // "testadas"
										// // pela
										// // integridade.
										//
										// ArrayList<String> basesComErroRange = new ArrayList();
										// List<ColunaTabela> listaCamposRange = new ArrayList();
										// listaCamposRange = listarCamposRange(baseOrigem.getIdTabela());
										//
										// if (listaCamposRange.size() < 1) {
										// statusRange = -1;
										// }
										//
										// int contador = 0;
										// for (ColunaTabela colTb : listaCamposRange) {
										// contador++;
										// ArrayList<ArrayList<String>> preparaRangeSAS = new ArrayList();
										// ArrayList<String> rangeList = new ArrayList();
										//
										// preparaRangeSAS = preparaDadosRangeSAS(sas, lib, stringBases, colTb, obj,
										// contador, qtdeReg);
										//
										// if (preparaRangeSAS.size() > 0) {
										// rangeList = range(preparaRangeSAS, colTb.getIdColuna(), obj);
										// basesComErroRange.addAll(rangeList);
										// statusRange = 1;
										// }
										//
										// // basesComErroRange = range(preparaDadosRangeSAS(sas, lib, stringBases,
										// // colTb),
										// // colTb.getIdColuna());
										// }
										// contador = 0;
										//
										// ArrayList<String> baseComErrosMissing = new ArrayList();
										// List<ColunaTabela> listaCamposMissing = new ArrayList();
										//
										// if (listaCamposMissing.size() < 1) {
										// statusMissing = -1;
										// String[] basePSI = stringBases.split(", ");
										// for (int i = 0; i < basePSI.length; i++) {
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase()
										// .equals(basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusMissing(statusMissing);
										// }
										// }
										// }
										// }
										//
										// listaCamposMissing = listarCamposMissing(baseOrigem.getIdTabela());
										// for (ColunaTabela m : listaCamposMissing) {
										// contador++;
										// ArrayList<ArrayList<String>> preparaMissingSAS = new ArrayList();
										// ArrayList<String> missingList = new ArrayList();
										//
										// preparaMissingSAS = prepararDadosMissingSAS(sas, lib, stringBases,
										// m.getNomeColuna(), obj, contador, qtdeReg);
										//
										// if (preparaMissingSAS.size() > 0) {
										// missingList = missing(preparaMissingSAS, m.getIdColuna(), obj);
										// baseComErrosMissing.addAll(missingList);
										// } else {
										// String[] basePSI = stringBases.split(", ");
										// for (int i = 0; i < basePSI.length; i++) {
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase().equals(
										// basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusMissing(statusMissing);
										// }
										// }
										// }
										// }
										//
										// }
										//
										// contador = 0;
										//
										// ArrayList<String> basesComErroDominio = new ArrayList();
										// List<ColunaTabela> listarCamposDominio = new ArrayList();
										//
										// if (listarCamposDominio.size() < 1) {
										// statusDominio = -1;
										// String[] basePSI = stringBases.split(", ");
										// for (int i = 0; i < basePSI.length; i++) {
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase()
										// .equals(basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusDominio(statusDominio);
										// }
										// }
										// }
										// }
										//
										// listarCamposDominio = listarCamposDominio(baseOrigem.getIdTabela());
										// for (ColunaTabela d : listarCamposDominio) {
										// contador++;
										// ArrayList<ArrayList<String>> preparaDominioSAS = new ArrayList();
										// ArrayList<String> dominioList = new ArrayList();
										//
										// preparaDominioSAS = prepararDadosDominioSAS(sas, lib, stringBases, d, obj,
										// contador, qtdeReg);
										//
										// if (preparaDominioSAS.size() > 0) {
										// dominioList = dominio(preparaDominioSAS, d.getIdColuna(),
										// d.getRegras().get(0).getDetalheRegra(), obj);
										// basesComErroDominio.addAll(dominioList);
										// } else {
										// String[] basePSI = stringBases.split(", ");
										// for (int i = 0; i < basePSI.length; i++) {
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase().equals(
										// basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusDominio(statusDominio);
										// }
										// }
										// }
										// }
										// }
										// contador = 0;
										//
										// ArrayList<String> basesComErroPSI = new ArrayList();
										// List<ColunaTabela> listarCamposPSI = new ArrayList();
										//
										// listarCamposPSI = listarCamposPSI(baseOrigem.getIdTabela());
										//
										// if (listarCamposPSI.size() < 1) {
										// statusPSI = -1;
										// String[] basePSI = stringBases.split(", ");
										// for (int i = 0; i < basePSI.length; i++) {
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase()
										// .equals(basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusPSI(statusPSI);
										// }
										// }
										// }
										// }
										//
										// for (ColunaTabela d : listarCamposPSI) {
										// contador++;
										// String[] basePSI = stringBases.split(",");
										// for (int i = 0; i < basePSI.length; i++) {
										//
										// ArrayList<ArrayList<String>> preparaPSISAS = new ArrayList();
										// ArrayList<String> PSIList = new ArrayList();
										// ArrayList<String> validarAtual = new ArrayList<String>();
										//
										// String freq = psiColuna(d.getIdColuna());
										//
										// validarAtual.add("7");
										// validarAtual.add(getIDTabelabyIDColIDRegra(d.getIdColuna(), 7) + "");
										//
										// String[] freq_1 = freq.split(",");
										// double[] frequencias_1 = new double[freq_1.length / 2];
										// int s = 0;
										// int cont = 0;
										// while (cont < freq_1.length) {
										// frequencias_1[s] = Double.parseDouble(freq_1[cont]);
										// cont += 2;
										// s++;
										// }
										//
										// //
										// String nmBase = basePSI[i].substring(1, basePSI[i].length() - 1);
										// preparaPSISAS = prepararDadosPSISAS(sas, lib.replace("'", ""), nmBase,
										// d, i, qtdeReg);
										//
										// validarAtual.add(nmBase);
										// validarAtual.add(d.getIdColuna() + "");
										// double[] frequencias_2 = new double[preparaPSISAS.size()];
										//
										// for (int j = 0; j < frequencias_2.length; j++) {
										// frequencias_2[j] = Double.parseDouble(preparaPSISAS.get(j).get(0));
										// }
										//
										// double[] psi = new double[frequencias_2.length];
										// double psi_final = 0;
										//
										// if (frequencias_2.length != frequencias_1.length) {
										// PSIList = PSI(-1, d, nmBase);
										// basesComErroPSI.addAll(PSIList);
										// } else {
										// // Calculo da m�trica de PSI com o Baseline cadastrado
										// for (int j = 0; j < frequencias_2.length; j++) {
										// if (frequencias_2[j] == 0 || frequencias_1[j] == 0) {
										// psi[j] = 0;
										// } else {
										// psi[j] = Math
										// .log(Math.abs(frequencias_2[j] / frequencias_1[j]))
										// * (frequencias_2[j] - frequencias_1[j]);
										// }
										//
										// psi_final = psi_final + psi[j];
										// }
										// validarAtual.add(psi_final + "");
										// // Conforme valores definidos pela regra de PSI, valores acima de
										// // 0.1
										// // devem
										// // ser
										// // verificados
										// if (psi_final >= 0.1) {
										// PSIList = PSI(psi_final, d, nmBase);
										// basesComErroPSI.addAll(PSIList);
										// statusPSI = 1;
										// }
										// String dtModificacao = "";
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase().equals(
										// basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusPSI(statusPSI);
										// dtModificacao = status_1.getDataModificacao();
										// }
										// }
										// inserirPSI(psi_final, d, nmBase, dtModificacao);
										//
										// }
										// }
										// }
										// contador = 0;
										//
										// ArrayList<String> baseComErrosDuplicidade = new ArrayList();
										// // List<ColunaTabela> listaCamposDuplicidade = new ArrayList();
										// List<Object> listaCamposDuplicidade;
										//
										// listaCamposDuplicidade = listarCamposDuplicidade(baseOrigem.getIdTabela());
										//
										// if (listaCamposDuplicidade.size() < 1) {
										// statusDuplicidade = -1;
										// String[] basePSI = stringBases.split(", ");
										// for (int i = 0; i < basePSI.length; i++) {
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase()
										// .equals(basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusDuplicidade(statusDuplicidade);
										// }
										// }
										// }
										// }
										//
										// // for(ColunaTabela duplic : listaCamposDuplicidade) {
										// if (listaCamposDuplicidade.size() > 0) {
										// if (listaCamposDuplicidade.get(0) != null) { // se for null n�o tem nenhuma
										// // regra
										// // cadastrada
										// // System.out.println("Coluna: " + duplic.getNomeColuna());
										// contador++;
										// ArrayList<ArrayList<String>> preparaDuplicidade = new ArrayList();
										// ArrayList<String> duplicidadeList = new ArrayList();
										//
										// preparaDuplicidade = prepararDadosDuplicidadeSAS(sas, lib, stringBases,
										// (String) listaCamposDuplicidade.get(0), obj, contador);
										//
										// if (preparaDuplicidade.size() > 0) {
										// duplicidadeList = duplicidade(preparaDuplicidade,
										// (Integer) listaCamposDuplicidade.get(1), obj);
										// baseComErrosDuplicidade.addAll(duplicidadeList);
										//
										// } else {
										// String[] basePSI = stringBases.split(", ");
										// for (int i = 0; i < basePSI.length; i++) {
										// for (StatusBases status_1 : statusBases) {
										// if (status_1.getNomeBase().equals(
										// basePSI[i].substring(1, basePSI[i].length() - 1))) {
										// status_1.setStatusDuplicidade(statusDuplicidade);
										// }
										// }
										// }
										// }
										// }
										// }
										// // }
										//
										// for (Base b : bases) {
										// System.out.println("come�ou loop");
										// if (b.isEstaVazia()) {
										// inserirNotificacao(idBaseToda, 0, b.getNomeBase(),
										// "Base vazia, verificar!"); // inserindo
										// // notifica��o;
										//
										// } else {
										//
										// int contErros2 = 0;
										//
										// if (basesComErroRange.contains(b.getNomeBase())) {
										// contErros2++;
										// }
										//
										// if (baseComErrosMissing.contains(b.getNomeBase())) {
										// contErros2++;
										// }
										//
										// if (basesComErroDominio.contains(b.getNomeBase())) {
										// contErros2++;
										// }
										//
										// if (baseComErrosDuplicidade.contains(b.getNomeBase())) {
										// contErros2++;
										// }
										//
										// if (basesComErroPSI.contains(b.getNomeBase())) {
										// contErros2++;
										// }
										//
										// System.out.println("*** BASE: " + b.getNomeBase());
										// System.out.println("**************** vai calcular a integridade");
										// contErros2 = contErros2 + integridade(baseOrigem, b);
										//
										// System.out.println("numero de erros da base " + b.getNomeBase() + ": "
										// + contErros2);
										// if (contErros2 == 0) { // n�o teve erros, ent�o tirar da lista de bases
										// // �
										// // rodar
										// deletarListaRun(b.getNomeBase());
										// }
										// }
										// }
										//
										// inserirStatusBases(statusBases);
										//
										// System.out.println("Tempo Total RODAR: "
										// + (System.currentTimeMillis() - tempoInicioPrep) / 1000);
										// } else {
										// System.out.println("N�o foi poss�vel conectar ao servidor da base!!!");
										// }
										// } else {
										if (!sas.getLog().contains("Falha na conex�o com o servidor")) {
											int baseJaRodou;
											int contErros = 0;
											String lib = "";
											if (obj.getConexao().length() > 9) {
												lib = "'" + obj.getConexao() + "'";
											} else {
												lib = obj.getConexao();
											}
											String base2 = obj.getNomeBase();
											List nomesDasBases = new ArrayList();
											Base baseOrigem;
											int numNotif = 0;
											double qtdeReg = 1;

											baseOrigem = getBasePeloId(obj.getIdTabela());
											String ultimaData = "";
											ultimaData = getUltimaInsercaoRegbyId(obj.getIdTabela());
											int tamanho_amostra = obj.getTamanhoAmostra();
											// pega os nobs no caso de a base ser do sas
											if ((obj.getPeriodicidade().equals("Mensal")
													|| obj.getPeriodicidade().equals("Trimestral")
													|| obj.getPeriodicidade().equals("Semestral")) && obj.getSafrada() == 0) {
												if (ultimaData == null || ultimaData == "") {
													ultimaData = "0";
												}
												listaElementos = nobsBasesSASMensal(sas, lib, base2, ultimaData,
														new BigDecimal(Math.round(100 * Math.random() * 50 * Math.random() * 25
																* Math.random() * 12 * Math.random())).intValueExact());
											} else if ((obj.getPeriodicidade().equals("Di�ria")
													|| obj.getPeriodicidade().equals("Semanal")
													|| obj.getPeriodicidade().equals("Quinzenal")) && obj.getSafrada() == 0) {
												if (ultimaData == null || ultimaData == "") {
													ultimaData = "0";
												}
												listaElementos = nobsBasesSAS(sas, lib, base2, ultimaData,
														new BigDecimal(Math.round(100 * Math.random() * 50 * Math.random() * 25
																* Math.random() * 12 * Math.random())).intValueExact(), tamanho_amostra);
											} else if (obj.getSafrada() > 0 && obj.getIncrem_full().equals("INCREMENTAL")) {

												if (getQtdeRegBaseNSafrada(obj.getIdTabela()) > 0) {
													qtdeReg = getQtdeRegBaseNSafrada(obj.getIdTabela());
												}
												listaElementos = nobsBasesSASNSafradaIncre(sas, lib, base2, qtdeReg);

											} else if (obj.getSafrada() > 0 && obj.getIncrem_full().equals("FULL")) {
												SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

												listaElementos = nobsBasesSASNSafradaFull(sas, lib, base2);
												datas = (String[]) listaElementos.get(3);
												try {
													Date data1 = formatter.parse(datas[0]);
													
													Calendar cal1 = Calendar.getInstance();
													Calendar cal2 = Calendar.getInstance();
													cal1.setTime(data1);
													if (ultimaData != "" && ultimaData != null) {
														cal2.setTime(formatter.parse(ultimaData));
														boolean sameDay = cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR) &&
												                  cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);

														if (sameDay) {
															break;
														}
													}
												} catch (ParseException e) {
													e.printStackTrace();
												}
											} else {
												break;
											}

											nobs2 = (double[]) listaElementos.get(0);
											datas = (String[]) listaElementos.get(1);
											nomesDasBases = (List<String>) listaElementos.get(2);
											modate = (String[]) listaElementos.get(3);
											int idBaseToda = 0;
											idBaseToda = getidBaseToda(obj.getIdTabela());

											/*
											 * inicialmente rodar� integridade e observa��o na base como um todo
											 * obrigatoriamente. em seguida ir� coluna por coluna rodando as regras
											 * cadastradas para as colunas da tabela.
											 */

											// conec sas
											if (nobs2.length >= 1 && nobs2[0] >= 0) {

												System.out.println("**************** vai calc obs");
												ArrayList<Double> nobs_amostra = getAmostraParaCalPorID(obj.getIdTabela(),
														tamanho_amostra - 1);
												ArrayList<Double> range_amostra = getRangeParaCalPorID(obj.getIdTabela(),
														tamanho_amostra - 1);
												ArrayList<Double> range_media = getRangeMediaParaCalPorID(obj.getIdTabela(),
														tamanho_amostra - 1);

												if (nobs_amostra.isEmpty()) {
													for (int i = 0; i < nobs2.length; i++) {
														nobs_amostra.add(nobs2[i]);
													}

													statusBases = calcObservacaoHist(obj.getIdTabela(), idBaseToda,
															nobs_amostra, modate, nomesDasBases, tamanho_amostra, modate, obj);
												} else {

													for (int i = 0; i < nobs2.length; i++) {
														String nbase = nomesDasBases.get(i).toString().trim();

														if (nbase.contains("\"")) {
															nbase = nbase.substring(1, nbase.length() - 1);
														}

														StatusBases status_1 = new StatusBases();
														status_1.setIdTb(obj.getIdTabela());
														status_1.setNomeBase(nbase);
														status_1.setDataModificacao(modate[i].trim());

														String dataDeHoje = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
																.format(new Date());

														status_1.setDataQualidade(dataDeHoje);
														status_1.setPeriodicidade(obj.getPeriodicidade());
														if (obj.getSafrada() == 0) {
															if (isReprocessamento(obj, nbase, modate[i].trim(), nobs2[i])) {
																status_1.setStatusReprocessamento(1);
															} else {
																status_1.setStatusReprocessamento(0);
															}
														}
														
														statusBases.add(status_1);
														
													}
													
													int reprocessamento = 0;
													for (int i = 0; i < nobs2.length; i++) {
														
														String nbase = nomesDasBases.get(i).toString().trim();

														if (nbase.contains("\"")) {
															nbase = nbase.substring(1, nbase.length() - 1);
														}
														
														reprocessamento = isReprocessamentoDelete(obj, nbase, modate[i].trim(), nobs2[i]);
													
														if (reprocessamento == -2) {
															statusBases.remove(i);
														}
													}

													if (obj.getSafrada() == 0) {
														listaElementos = new ArrayList();
														ultimaData = getUltimaInsercaoRegbyId(obj.getIdTabela());
														tamanho_amostra = obj.getTamanhoAmostra();
														// pega os nobs no caso de a base ser do sas
														if ((obj.getPeriodicidade().equals("Mensal")
																|| obj.getPeriodicidade().equals("Trimestral")
																|| obj.getPeriodicidade().equals("Semestral"))
																&& obj.getSafrada() == 0) {
															if (ultimaData == null || ultimaData == "") {
																ultimaData = "0";
															}
															listaElementos = nobsBasesSASMensal(sas, lib, base2, ultimaData,
																	new BigDecimal(Math.round(100 * Math.random() * 50 * Math.random() * 25
																			* Math.random() * 12 * Math.random())).intValueExact());
														} else if ((obj.getPeriodicidade().equals("Di�ria")
																|| obj.getPeriodicidade().equals("Semanal")
																|| obj.getPeriodicidade().equals("Quinzenal"))
																&& obj.getSafrada() == 0) {
															if (ultimaData == null || ultimaData == "") {
																ultimaData = "0";
															}
															listaElementos = nobsBasesSAS(sas, lib, base2, ultimaData,
																	new BigDecimal(Math.round(100 * Math.random() * 50 * Math.random() * 25
																			* Math.random() * 12 * Math.random())).intValueExact(), tamanho_amostra);
														} else {
															break;
														}
													}

													nobs2 = (double[]) listaElementos.get(0);
													datas = (String[]) listaElementos.get(1);
													nomesDasBases = (List<String>) listaElementos.get(2);
													modate = (String[]) listaElementos.get(3);
													idBaseToda = 0;
													idBaseToda = getidBaseToda(obj.getIdTabela());

													ArrayList<Double> nobs_amostra_new;
													ArrayList<Double> range_amostra_new;
													ArrayList<Double> range_media_new;

													for (int i = 0; i < nobs2.length; i++) {
														String nbase = nomesDasBases.get(i).toString().trim();

														if (nbase.contains("\"")) {
															nbase = nbase.substring(1, nbase.length() - 1);
														}

														nobs_amostra_new = new ArrayList<Double>();
														range_amostra_new = new ArrayList<Double>();
														range_media_new = new ArrayList<Double>();
														nobs_amostra.add(nobs2[i]);

//														 if (nobs_amostra.size() == tamanho_amostra) {
//															 int tamanho = obj.getTamanhoAmostra();
//															 tamanho_amostra = analisaHistorico(obj, tamanho);
//															 updateTamanhoAmostraBasePeloID(obj.getIdTabela(),
//															 tamanho_amostra);
//														 }

														for (int j = 0; j < nobs_amostra.size(); j++) {
															nobs_amostra_new.add(nobs_amostra.get(j));
														}
														for (int j = 0; j < range_amostra.size(); j++) {
															range_amostra_new.add(range_amostra.get(j));
															range_media_new.add(range_media.get(j));
														}
														statusObservacao = calcObservacao(obj.getIdTabela(), idBaseToda,
																nobs_amostra_new, range_amostra_new, range_media_new, modate,
																nomesDasBases, i, tamanho_amostra, modate, obj);

														for (StatusBases status_2 : statusBases) {
															if (status_2.getNomeBase().equals(nbase)) {
																status_2.setStatusObservacao(statusObservacao);
															}
														}

														nobs_amostra = getAmostraParaCalPorID(obj.getIdTabela(),
																tamanho_amostra - 1);
														range_amostra = getRangeParaCalPorID(obj.getIdTabela(),
																tamanho_amostra - 1);
														range_media = getRangeMediaParaCalPorID(obj.getIdTabela(),
																tamanho_amostra - 1);
													}
												}

												String stringBases = nomesDasBases.toString();
												stringBases = stringBases.substring(1, stringBases.length() - 1);
												// conec sas - Prepara a base SAS para a regra de integridade
												System.out.println("**************** vai preparar base integridade");
												bases = preparaBaseIntegridadeSAS(sas, lib, stringBases); // bases que ser�o
																											// "testadas"
																											// pela
																											// integridade.
												int contador = 0;
												ArrayList<String> baseComErrosDuplicidade = new ArrayList();
												// List<ColunaTabela> listaCamposDuplicidade = new ArrayList();
												List<Object> listaCamposDuplicidade;

												listaCamposDuplicidade = listarCamposDuplicidade(baseOrigem.getIdTabela());

												if (listaCamposDuplicidade.size() < 1) {
													statusDuplicidade = -1;
													if (stringBases.contains(",")) {
														String[] basePSI = stringBases.split(", ");
														for (int i = 0; i < basePSI.length; i++) {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		basePSI[i].substring(1, basePSI[i].length() - 1))) {
																	status_1.setStatusDuplicidade(statusDuplicidade);
																}
															}
														}
													} else {
														for (StatusBases status_1 : statusBases) {
															if (stringBases.contains("\"")) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {

																	status_1.setStatusDuplicidade(statusDuplicidade);
																}
															} else {
																if (status_1.getNomeBase().equals(stringBases)) {

																	status_1.setStatusDuplicidade(statusDuplicidade);
																}
															}
														}
													}
												}
												// for(ColunaTabela duplic : listaCamposDuplicidade) {
												if (listaCamposDuplicidade.size() > 0) {
													if (listaCamposDuplicidade.get(0) != null) { // se for null n�o tem
																									// nenhuma
																									// regra
														// cadastrada
														// System.out.println("Coluna: " + duplic.getNomeColuna());
														long tempo = System.currentTimeMillis();
														System.out.println("ENTROU NA BASE: " + base);
														System.out.println("ENTROU DUPLICIDADE");
														contador++;
														ArrayList<ArrayList<String>> preparaDuplicidade = new ArrayList();
														ArrayList<String> duplicidadeList = new ArrayList();

														preparaDuplicidade = prepararDadosDuplicidadeSAS(sas, lib, stringBases,
																(String) listaCamposDuplicidade.get(0), obj, contador);

														if (preparaDuplicidade.size() > 0) {
															duplicidadeList = duplicidade(preparaDuplicidade,
																	(Integer) listaCamposDuplicidade.get(1), obj);
															baseComErrosDuplicidade.addAll(duplicidadeList);
														} else {
															if (stringBases.contains(",")) {
																String[] basePSI = stringBases.split(", ");
																for (int i = 0; i < basePSI.length; i++) {
																	for (StatusBases status_1 : statusBases) {
																		if (status_1.getNomeBase().equals(basePSI[i]
																				.substring(1, basePSI[i].length() - 1))) {
																			if (status_1.getStatusDuplicidade() != 0) {

																			} else {
																				status_1.setStatusDuplicidade(statusDuplicidade);
																			}
																			
																		}
																	}
																}
															} else {
																for (StatusBases status_1 : statusBases) {
																	if (status_1.getNomeBase().equals(stringBases.substring(1,
																			stringBases.length() - 1))) {
																		if (status_1.getStatusDuplicidade() != 0) {

																		} else {
																			status_1.setStatusDuplicidade(statusDuplicidade);
																		}
																	}
																}
															}
														}
														System.out.println("A COLUNA RODOU EM: "
																+ (System.currentTimeMillis() - tempo) / 1000 + " segundos");
													}

												}

												contador = 0;

												ArrayList<String> basesComErroRange = new ArrayList();
												List<ColunaTabela> listaCamposRange = new ArrayList();
												listaCamposRange = listarCamposRange(baseOrigem.getIdTabela());

												if (listaCamposRange.size() < 1) {
													statusRange = -1;
													if (stringBases.contains(",")) {
														String[] basePSI = stringBases.split(", ");
														for (int i = 0; i < basePSI.length; i++) {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		basePSI[i].substring(1, basePSI[i].length() - 1))) {
																	status_1.setStatusRange(statusRange);
																}
															}
														}
													} else {
														for (StatusBases status_1 : statusBases) {
															if (stringBases.contains("\"")) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {

																	status_1.setStatusDuplicidade(statusRange);
																}
															} else {
																if (status_1.getNomeBase().equals(stringBases)) {

																	status_1.setStatusRange(statusRange);
																}
															}
														}
													}
												}

												for (ColunaTabela colTb : listaCamposRange) {
													long tempo = System.currentTimeMillis();
													System.out.println("ENTROU NA BASE: " + base);
													System.out.println("ENTROU RANGE");
													contador++;
													ArrayList<ArrayList<String>> preparaRangeSAS = new ArrayList();
													ArrayList<String> rangeList = new ArrayList();

													preparaRangeSAS = preparaDadosRangeSAS(sas, lib, stringBases, colTb, obj,
															contador, qtdeReg);

													if (preparaRangeSAS.size() > 0) {
														rangeList = range(preparaRangeSAS, colTb.getIdColuna(), obj);
														basesComErroRange.addAll(rangeList);
													} else {
														if (stringBases.contains(",")) {
															String[] basePSI = stringBases.split(", ");
															for (int i = 0; i < basePSI.length; i++) {
																for (StatusBases status_1 : statusBases) {
																	if (status_1.getNomeBase().equals(
																			basePSI[i].substring(1, basePSI[i].length() - 1))) {
																		if (status_1.getStatusRange() != 0) {

																		} else {
																			status_1.setStatusRange(statusRange);
																		}
																	}
																}
															}
														} else {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {
																	if (status_1.getStatusRange() != 0) {

																	} else {
																		status_1.setStatusRange(statusRange);
																	}
																}
															}
														}
													}
													System.out.println("A COLUNA RODOU EM: "
															+ (System.currentTimeMillis() - tempo) / 1000 + " segundos");
													// basesComErroRange = range(preparaDadosRangeSAS(sas, lib, stringBases,
													// colTb),
													// colTb.getIdColuna());
												}
												contador = 0;

												ArrayList<String> baseComErrosMissing = new ArrayList();
												List<ColunaTabela> listaCamposMissing = new ArrayList();

												listaCamposMissing = listarCamposMissing(baseOrigem.getIdTabela());

												if (listaCamposMissing.size() < 1) {
													statusMissing = -1;
													if (stringBases.contains(",")) {
														String[] basePSI = stringBases.split(", ");
														for (int i = 0; i < basePSI.length; i++) {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		basePSI[i].substring(1, basePSI[i].length() - 1))) {
																	status_1.setStatusMissing(statusMissing);
																}
															}
														}
													} else {
														for (StatusBases status_1 : statusBases) {
															if (stringBases.contains("\"")) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {

																	status_1.setStatusMissing(statusMissing);
																}
															} else {
																if (status_1.getNomeBase().equals(stringBases)) {

																	status_1.setStatusMissing(statusMissing);
																}
															}
														}
													}
												}

												for (ColunaTabela m : listaCamposMissing) {
													long tempo = System.currentTimeMillis();
													System.out.println("ENTROU NA BASE: " + base);
													System.out.println("ENTROU MISSING");
													contador++;
													ArrayList<ArrayList<String>> preparaMissingSAS = new ArrayList();
													ArrayList<String> missingList = new ArrayList();

													preparaMissingSAS = prepararDadosMissingSAS(sas, lib, stringBases,
															m.getNomeColuna(), obj, contador, qtdeReg);

													if (preparaMissingSAS.size() > 0) {
														missingList = missing(preparaMissingSAS, m.getIdColuna(), obj);
														baseComErrosMissing.addAll(missingList);
													} else {
														if (stringBases.contains(",")) {
															String[] basePSI = stringBases.split(", ");
															for (int i = 0; i < basePSI.length; i++) {
																for (StatusBases status_1 : statusBases) {
																	if (status_1.getNomeBase().equals(
																			basePSI[i].substring(1, basePSI[i].length() - 1))) {
																		
																		if (status_1.getStatusMissing() != 0) {

																		} else {
																			status_1.setStatusMissing(statusMissing);
																		}
																	}
																}
															}
														} else {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {
																	if (status_1.getStatusMissing() != 0) {

																	} else {
																		status_1.setStatusMissing(statusMissing);
																	}
																}
															}
														}
													}
													System.out.println("A COLUNA RODOU EM: "
															+ (System.currentTimeMillis() - tempo) / 1000 + " segundos");

												}

												contador = 0;

												ArrayList<String> basesComErroDominio = new ArrayList();
												List<ColunaTabela> listarCamposDominio = new ArrayList();

												listarCamposDominio = listarCamposDominio(baseOrigem.getIdTabela());

												if (listarCamposDominio.size() < 1) {
													statusDominio = -1;
													if (stringBases.contains(",")) {
														String[] basePSI = stringBases.split(", ");
														for (int i = 0; i < basePSI.length; i++) {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		basePSI[i].substring(1, basePSI[i].length() - 1))) {
																	status_1.setStatusDominio(statusDominio);
																}
															}
														}
													} else {
														for (StatusBases status_1 : statusBases) {
															if (stringBases.contains("\"")) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {

																	status_1.setStatusDominio(statusDominio);
																}
															} else {
																if (status_1.getNomeBase().equals(stringBases)) {

																	status_1.setStatusDominio(statusDominio);
																}
															}
														}
													}
												}

												for (ColunaTabela d : listarCamposDominio) {
													long tempo = System.currentTimeMillis();
													System.out.println("ENTROU NA BASE: " + base);
													System.out.println("ENTROU DOMINIO");
													contador++;
													ArrayList<ArrayList<String>> preparaDominioSAS = new ArrayList();
													ArrayList<String> dominioList = new ArrayList();

													preparaDominioSAS = prepararDadosDominioSAS(sas, lib, stringBases, d, obj,
															contador, qtdeReg);

													if (preparaDominioSAS.size() > 0) {
														dominioList = dominio(preparaDominioSAS, d.getIdColuna(),
																d.getRegras().get(0).getDetalheRegra(), obj);
														basesComErroDominio.addAll(dominioList);
													} else {
														if (stringBases.contains(",")) {
															String[] basePSI = stringBases.split(", ");
															for (int i = 0; i < basePSI.length; i++) {
																for (StatusBases status_1 : statusBases) {
																	if (status_1.getNomeBase().equals(
																			basePSI[i].substring(1, basePSI[i].length() - 1))) {
																		
																		if (status_1.getStatusDominio() != 0) {

																		} else {
																			status_1.setStatusDominio(statusDominio);
																		}
																	}
																}
															}
														} else {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {
																	if (status_1.getStatusDominio() != 0) {

																	} else {
																		status_1.setStatusDominio(statusDominio);
																	}

																}
															}
														}
													}
													System.out.println("A COLUNA RODOU EM: "
															+ (System.currentTimeMillis() - tempo) / 1000 + " segundos");
												}
												contador = 0;

												ArrayList<String> basesComErroPSI = new ArrayList();
												List<ColunaTabela> listarCamposPSI = new ArrayList();

												listarCamposPSI = listarCamposPSI(baseOrigem.getIdTabela());

												if (listarCamposPSI.size() < 1) {
													statusPSI = -1;
													if (stringBases.contains(",")) {
														String[] basePSI = stringBases.split(", ");
														for (int i = 0; i < basePSI.length; i++) {
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		basePSI[i].substring(1, basePSI[i].length() - 1))) {
																	status_1.setStatusPSI(statusPSI);
																}
															}
														}
													} else {
														for (StatusBases status_1 : statusBases) {
															if (stringBases.contains("\"")) {
																if (status_1.getNomeBase().equals(
																		stringBases.substring(1, stringBases.length() - 1))) {

																	status_1.setStatusPSI(statusPSI);
																}
															} else {
																if (status_1.getNomeBase().equals(stringBases)) {

																	status_1.setStatusPSI(statusPSI);
																}
															}
														}
													}
												}

												for (ColunaTabela d : listarCamposPSI) {
													long tempo = System.currentTimeMillis();
													System.out.println("ENTROU NA BASE: " + base);
													System.out.println("ENTROU PSI");
													contador++;
													String[] basePSI = stringBases.split(", ");
													for (int i = 0; i < basePSI.length; i++) {

														ArrayList<ArrayList<String>> preparaPSISAS = new ArrayList();
														ArrayList<String> PSIList = new ArrayList();
														ArrayList<String> validarAtual = new ArrayList<String>();

														String freq = psiColuna(d.getIdColuna());

														validarAtual.add("7");
														validarAtual.add(getIDTabelabyIDColIDRegra(d.getIdColuna(), 7) + "");

														String[] freq_1 = freq.split(",");
														double[] frequencias_1 = new double[freq_1.length / 2];
														int s = 0;
														int cont = 0;
														while (cont < freq_1.length) {
															frequencias_1[s] = Double.parseDouble(freq_1[cont]);
															cont += 2;
															s++;
														}

														//
														String nmBase = basePSI[i].substring(1, basePSI[i].length() - 1);
														preparaPSISAS = prepararDadosPSISAS(sas, lib.replace("'", ""), nmBase,
																d, i, qtdeReg);
														validarAtual.add(nmBase);
														validarAtual.add(d.getIdColuna() + "");
														double[] frequencias_2 = new double[preparaPSISAS.size()];

														for (int j = 0; j < frequencias_2.length; j++) {
															frequencias_2[j] = Double.parseDouble(preparaPSISAS.get(j).get(0));
														}

														double[] psi = new double[frequencias_2.length];
														double psi_final = 0;

														if (frequencias_2.length != frequencias_1.length) {
															PSIList = PSI(-1, d, nmBase);
															basesComErroPSI.addAll(PSIList);
															statusPSI = -1;
														} else {
															// Calculo da m�trica de PSI com o Baseline cadastrado
															for (int j = 0; j < frequencias_2.length; j++) {
																if (frequencias_2[j] == 0 || frequencias_1[j] == 0) {
																	psi[j] = 0;
																} else {
																	psi[j] = Math
																			.log(Math.abs(frequencias_2[j] / frequencias_1[j]))
																			* (frequencias_2[j] - frequencias_1[j]);
																}

																psi_final = psi_final + psi[j];
															}
															validarAtual.add(psi_final + "");
															// Conforme valores definidos pela regra de PSI, valores acima
															// de
															// 0.1
															// devem
															// ser
															// verificados
															if (psi_final >= 0.1) {
																PSIList = PSI(psi_final, d, nmBase);
																inserirNotificacaoPSI(obj.getIdTabela(), nmBase, d.getNomeColuna(), psi_final, modate[i]);
																basesComErroPSI.addAll(PSIList);
																statusPSI = 1;
															} else {
																statusPSI = 0;
															}
															String dtModificacao = "";
															for (StatusBases status_1 : statusBases) {
																if (status_1.getNomeBase().equals(
																		basePSI[i].substring(1, basePSI[i].length() - 1))) {
																	if (status_1.getStatusPSI() != 0) {

																	} else {
																		status_1.setStatusPSI(statusPSI);
																	}
																	dtModificacao = status_1.getDataModificacao();
																}
															}
															inserirPSI(psi_final, d, nmBase, dtModificacao);
														}
													}
													System.out.println("A COLUNA RODOU EM: "
															+ (System.currentTimeMillis() - tempo) / 1000 + " segundos");

												}
												contador = 0;

												// }

												for (Base b : bases) {
													System.out.println("come�ou loop");
													if (b.isEstaVazia()) {
														inserirNotificacao(0, 0, b.getNomeBase(), "Base vazia, verificar!"); // inserindo
																																// notifica��o;

													} else {

														int contErros2 = 0;

														if (basesComErroRange.contains(b.getNomeBase())) {
															contErros2++;
														}

														if (baseComErrosMissing.contains(b.getNomeBase())) {
															contErros2++;
														}

														if (basesComErroDominio.contains(b.getNomeBase())) {
															contErros2++;
														}

														if (baseComErrosDuplicidade.contains(b.getNomeBase())) {
															contErros2++;
														}

														if (basesComErroPSI.contains(b.getNomeBase())) {
															contErros2++;
														}

														System.out.println("*** BASE: " + b.getNomeBase());
														System.out.println("**************** vai calcular a integridade");
														contErros2 = contErros2 + integridade(baseOrigem, b);

														System.out.println("numero de erros da base " + b.getNomeBase() + ": "
																+ contErros2);
														if (contErros2 == 0) { // n�o teve erros, ent�o tirar da lista de //
																				// bases// � rodar
															deletarListaRun(b.getNomeBase());
														} else {
														}
													}
												}

											}
											inserirStatusBases(statusBases);

											System.out.println("Tempo Total RODAR: "
													+ (System.currentTimeMillis() - tempoInicioPrep) / 1000);
										} else {
											System.out.println("N�o foi poss�vel conectar ao servidor da base!!!");
										}
//									}
									// }
									// }										
									}
								} catch (IOException e) {
									e.printStackTrace();
								} finally {
									sas.encerrar();									
								}

						case "ORACLE":
							System.out.println("� oracle!: " + tipoDaBase);
							break;
						default:
							System.out.println("Erro: tipo da base invalido: : " + tipoDaBase);
							break;
						}
					}

					/*
					 * double[] nobs_teste =
					 * {97342.00,97228.00,97390.00,93705.00,94670.00,94077.00,96679.00,
					 * 92359.00,95871.00,93806.00,94820.00,94486.00,95775.00,95001.00,92398.00,
					 * 97000.00,94569.00,87000.00,93417.00,91255.00,92516.00,94025.00,95733.00,
					 * 93297.00,92399.00,96008.00,92832.00,94741.00,93689.00,94074.00};
					 */

					// System.out.println("**************** vai seleconar uma base pelo id");
					// Base baseInt = getBasePeloId(3); //fundos - base pre cadastrada pelo usu�rio
					// como modelo padr�o da base.

					// PrintWriter out = response.getWriter();
					// response.setContentType("text/plain"); // Set content type of the response so
					// that jQuery knows what it can expect.
					// response.setCharacterEncoding("UTF-8"); // You want world domination, huh?
					System.out.println("Tempo Total: " + (System.currentTimeMillis() - tempoInicio) / 1000);
					// out.write(base); // Write response body.

					// String hoje = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
					//
					// for (String nBase : getNomeBasesNotificacao(hoje)) {
					// Email em = new Email();
					//
					// String[] login = getLoginSAS();
					// String usuario = login[0];
					// String senha = login[1];
					// String remetente = "adrean.cebola@bradesco.com.br";
					// String destinatario = "adrean.cebola@bradesco.com.br";
					// String assunto = "Notifica��es da base: " + nBase + " " + hoje;
					//
					// // String mensagem = "Base: " + nBase + " <br>";
					// String texto = "<html><head><style>body {font-size:11.0pt;font-family:"
					// + "\"Calibri\", sans-serif;}table "
					// + "{border-collapse:collapse;width:800px;}td,th{padding:4px;border:1px solid
					// "
					// + "black;text-align: center;}</style></head><body>";
					// texto += "<h3>Notifica��es</h3>";
					// texto +=
					// "<table><thead><tr><th>Base</h><th>Coluna</th><th>Regra</th><th>Notifica��o</th><th>Data</th>"
					// + "</tr></thead><tbody>";
					// for (Notificacao nfc : getNotificacaoPorData(hoje, nBase)) {
					// texto += "<tr>" + "<td>" + nfc.getNomeBase() + "</td>" + "<td>" +
					// nfc.getNomeColuna()
					// + "</td>" + "<td>" + nfc.getDescricaoRegra() + "</td>" + "<td>" +
					// nfc.getMensagem()
					// + "</td>" + "<td>" + nfc.getDataNotificacao() + "</td>" + "</tr>";
					// }
					// texto += "</tbody></table><br> Qualidade DGD, duvidas entrar em contato com"
					// + "FULANO 41 3777-0000</body></html>";
					// try {
					// em.enviarEmail(usuario, senha, remetente, destinatario, assunto, texto);
					// } catch (AddressException e1) {
					// e1.printStackTrace();
					// } catch (UnsupportedEncodingException e1) {
					// e1.printStackTrace();
					// } catch (MessagingException e1) {
					// e1.printStackTrace();
					// }
					// }
				} finally

				{
					// seja qual for o motivo da aplica��o terminar de rodar, ela vai atualziar o
					// status para "n�o rodando"
					updateQualidadeRunning(0);
				}
				System.out.println("RODOU TODAS AS BASES!!!");
				System.out.println(
						"Tempo Total para rodar TODAS AS BASES: " + (System.currentTimeMillis() - tempoInicio) / 1000);
				shutdown();
			}
		} else {
			System.out.println("QUALIDADE INATIVA! " + sdf.format(cal.getTime()));
		}

	}

	private void shutdown() {
		shutdown = true;
	}

	private boolean qualidadeEstaAtiva(String nome) {
		GerenciadorDeConexao sqlServer = null;
		boolean status;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			status = bDAO.qualidadeEstaAtiva(nome);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return status;
	}

	// pega a data da ultima base do sas rodada
	private String getUltimaDataBaseSAS() {
		GerenciadorDeConexao sqlServer = null;
		String data = "";

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			data = bDAO.getUltimaDataBaseSAS();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return data;
	}

	// pega todas as bases novas do sas que chegaram depois da data limite.
	private ArrayList<ArrayList<String>> getNovasBasesSAS(String dataLimite) {
		ConectorSAS sas;
		ArrayList<ArrayList<String>> novasBases = new ArrayList();

		sas = new ConectorSAS();

		try {
			sas.iniciar("i354217", "cebola06", "mz-fl-ap-099", 18602);
			// CWB GUIDE TEMPORARIAMENTE PARA DESENVOLVER A SOLUCAO.
			novasBases = sas.getNovasBasesSAS(dataLimite);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			sas.encerrar();
		}


		return novasBases;
	}

	public List<List<String>> getAtributosBases(String tipoBase) {
		GerenciadorDeConexao sqlServer = null;
		List<List<String>> listaBases = new ArrayList();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			listaBases = bDAO.getAtributosBases(tipoBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaBases;

	}

	public void InsereNovasBasesAutomaticas(List<Base> bases, String tipoBase) {
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			bDAO.InsereNovasBasesAutomaticas(bases, tipoBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void updateQualidadeLastRun(String novaData, String tipoBase) {
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			bDAO.updateQualidadeLastRun(novaData, tipoBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void enviaEmailBasesSemCadastro(List<Base> basesNaoCadastradas, String destinatario) {
		Email em = new Email();

		String[] login = getLoginSAS();
		String usuario = login[0];
		String senha = login[1];
		String remetente = "adrean.cebola@bradesco.com.br";
		String assunto = "Novas bases cadastrdas na Qualidade.";

		String texto = "<html><head><style>body {font-size:11.0pt;font-family: \"Calibri\", sans-serif;}table {border-collapse:collapse;width:800px;}td,th{padding:4px;border:1px solid black;text-align: center;}</style></head><body>";
		texto += "<h3>Bases Cadastradas:</h3>";
		texto += "<p>As seguintes bases foram encontradas no SAS, e foram cadastradas no sistema de qualidade.</p>";
		texto += "<table><thead><tr><th>Base</h><th>Caminho</th>" + "</tr></thead><tbody>";
		for (Base base : basesNaoCadastradas) {
			texto += "<tr><td>" + base.getNomeBase() + "</td>" + "<td>" + base.getConexao() + "</td></tr>";
		}

		texto += "</tbody></table><br> Qualidade DGD, duvidas entrar em contato com FULANO 41 3777-0000</body></html>";

		try {
			em.enviarEmail(usuario, senha, remetente, destinatario, assunto, texto);
		} catch (AddressException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (MessagingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	private String psiColuna(int idColuna) {
		String frequencias = "";

		GerenciadorDeConexao sqlServer = null;
		List<ColunaTabela> colunas;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			frequencias = regraDAO.psiColuna(idColuna);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return frequencias;
	}

	// retorna os nobs e as datas
	private List nobsBasesSAS(ConectorSAS sas, String lib, String base, String ultimaData, int contador, int tamanho) {
		String log = null;

		double[] nobs = null;
		List listaElementos = new ArrayList();
		ArrayList<ArrayList<String>> table_bases = new ArrayList<ArrayList<String>>();
		String[] datas = null;
		String dia;
		String[] datas_base = null;
		String[] modate = null;
		List<String> nomeDasBases = new ArrayList();

		System.out.println("Vai fazer o select dos nobs SAS!");
		nobs = sas.nobs_bases(lib, base, ultimaData, contador, tamanho);
		listaElementos.add(nobs);
		if (nobs[0] < 0) {
			datas = new String[1];
			datas_base = new String[1];
			modate = new String[1];

			datas[0] = "";
			dia = "";
			datas_base[0] = "";
			modate[0] = "";

			listaElementos.add(datas_base);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);
			return listaElementos;
		}

		System.out.println(nobs.toString());

		// retorna as datas da base

		if (ultimaData.equals("0")) {
			try {
				sas.ComandoSAS("PROC SQL outobs = "+tamanho+";create table WORK.BASE_OBSERVACAO" + contador + " as SELECT memname FROM WORK.BASE_OBSERVACAO" + contador + " Order by MODATE;QUIT;");
			} catch (GenericError e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		table_bases = sas.baseSAS("SELECT memname FROM WORK.BASE_OBSERVACAO" + contador);
		
		int tam_1 = table_bases.get(0).get(0).trim().length();
		if (tam_1 < 1) {
			datas = new String[table_bases.size()];
			datas_base = new String[table_bases.size()];
			modate = new String[table_bases.size()];

			datas[0] = "";
			dia = "";
			datas_base[0] = "";
			modate[0] = "";

			listaElementos.add(datas_base);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);

		} else {
			for (ArrayList<String> nmBases : table_bases) {
				nomeDasBases.add("\"" + nmBases.get(0).trim() + "\"");
			}

			datas = new String[table_bases.size()];
			datas_base = new String[table_bases.size()];

			for (int base_i = 0; base_i < table_bases.size(); base_i++) {
				datas[base_i] = String.valueOf(table_bases.get(base_i).get(0)).trim();
				dia = datas[base_i].substring(datas[base_i].length() - 2, datas[base_i].length()) + "/"
						+ datas[base_i].substring(datas[base_i].length() - 4, datas[base_i].length() - 2) + "/"
						+ datas[base_i].substring(datas[base_i].length() - 8, datas[base_i].length() - 4);
				datas_base[base_i] = dia;
			}

			
			if (ultimaData.equals("0")) {
				try {
					sas.ComandoSAS("PROC SQL outobs = "+tamanho+";create table WORK.lista_Modate" + contador + " as SELECT * FROM WORK.lista_Modate" + contador + " Order by 1;QUIT;");
				} catch (GenericError e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
			table_bases = sas.baseSAS("SELECT * FROM WORK.lista_Modate" + contador);
			
			modate = new String[table_bases.size()];

			for (int i = 0; i < table_bases.size(); i++) {
				modate[i] = String.valueOf(table_bases.get(i).get(0)).trim();
			}

			listaElementos.add(modate);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);

		}

		return listaElementos;
	}

	private List nobsBasesSASNSafradaIncre(ConectorSAS sas, String lib, String base, double qtdeReg) {
		double nobs = 0;
		List listaElementos = new ArrayList();
		ArrayList<ArrayList<String>> table_bases = new ArrayList<ArrayList<String>>();
		String[] datas = null;
		String[] modate = null;
		String dia;
		String log = "";
		String[] datas_base = null;
		List<String> nomeDasBases = new ArrayList();

		System.out.println("Vai fazer o select dos nobs SAS!");
		try {
			if (lib.length() > 8) {

				log += sas.ComandoSAS("libname INTEG " + lib + ";");
				log += sas.ComandoSAS("proc contents data=INTEG." + base + " out=modate_nobs(keep= modate nobs);run;");
				log += sas.ComandoSAS(
						"data baseInfo(drop=modate);set modate_nobs;modate3 = put(timepart(modate),time.);modate2 = put(datepart(modate),ddmmyy10.);modate1 = CAT(modate2 || \" \" || modate3);if _N_ = 1;run;");
			} else {
				log += sas.ComandoSAS(
						"proc contents data=" + lib + "." + base + " out=modate_nobs(keep= modate nobs);run;");
				log += sas.ComandoSAS(
						"data baseInfo(drop=modate);set modate_nobs;modate3 = COMPRESS(put(timepart(modate),time.));modate2 = COMPRESS(put(datepart(modate),ddmmyy10.));modate1 = CAT(modate2 || \" \" || modate3);if _N_ = 1;run;");
			}
		} catch (GenericError e) {
			e.printStackTrace();
		}

		table_bases = sas.baseSAS("SELECT * FROM WORK.baseInfo");
		if (qtdeReg > 0) {
			listaElementos.add(Double.parseDouble(table_bases.get(0).get(1)) - qtdeReg);
		} else {
			listaElementos.add(Double.parseDouble(table_bases.get(0).get(1)));
		}

		if (Double.parseDouble(table_bases.get(0).get(0)) < 0) {
			datas = new String[1];
			datas_base = new String[1];
			modate = new String[1];

			datas[0] = "";
			dia = "";
			datas_base[0] = "";
			modate[0] = "";
			listaElementos.add(datas_base);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);
			return listaElementos;
		}

		datas_base = new String[1];
		modate = new String[1];
		datas_base[0] = table_bases.get(0).get(2);
		modate[0] = table_bases.get(0).get(3);
		nomeDasBases.add(base);

		listaElementos.add(datas_base);
		listaElementos.add(nomeDasBases);
		listaElementos.add(modate);

		return listaElementos;
	}

	private List nobsBasesSASNSafradaFull(ConectorSAS sas, String lib, String base) {
		double[] nobs = new double[1];
		List listaElementos = new ArrayList();
		ArrayList<ArrayList<String>> table_bases = new ArrayList<ArrayList<String>>();
		String[] datas = null;
		String[] modate = null;
		String dia;
		String log = "";
		String[] datas_base = null;
		List<String> nomeDasBases = new ArrayList();

		System.out.println("Vai fazer o select dos nobs SAS!");
		try {
			if (lib.length() > 8) {

				log += sas.ComandoSAS("libname INTEG " + lib + ";");
				log += sas.ComandoSAS("proc contents data=INTEG." + base + " out=modate_nobs(keep= modate nobs);run;");
				log += sas.ComandoSAS(
						"data baseInfo(drop=modate);set modate_nobs;modate3 = put(timepart(modate),time.);modate2 = put(datepart(modate),ddmmyy10.);modate1 = CAT(modate2 || \" \" || modate3);if _N_ = 1;run;");
			} else {
				log += sas.ComandoSAS(
						"proc contents data=" + lib + "." + base + " out=modate_nobs(keep= modate nobs);run;");
				log += sas.ComandoSAS(
						"data baseInfo(drop=modate);set modate_nobs;modate3 = put(timepart(modate),time.);modate2 = put(datepart(modate),ddmmyy10.);modate1 = CAT(modate2 || \" \" || modate3);if _N_ = 1;run;");
			}
		} catch (GenericError e) {
			e.printStackTrace();
		}

		table_bases = sas.baseSAS("SELECT * FROM WORK.baseInfo");
		nobs[0] = Double.parseDouble(table_bases.get(0).get(0));
		listaElementos.add(nobs);

		if (Double.parseDouble(table_bases.get(0).get(0)) < 0) {
			datas = new String[1];
			datas_base = new String[1];
			modate = new String[1];

			datas[0] = "";
			dia = "";
			datas_base[0] = "";
			modate[0] = "";

			listaElementos.add(datas_base);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);
			return listaElementos;
		}

		datas_base = new String[1];
		modate = new String[1];
		datas_base[0] = table_bases.get(0).get(2);
		modate[0] = table_bases.get(0).get(3);

		nomeDasBases.add(base);

		listaElementos.add(datas_base);
		listaElementos.add(nomeDasBases);
		listaElementos.add(modate);
		return listaElementos;
	}

	private List nobsBasesSASMensal(ConectorSAS sas, String lib, String base, String ultimaData, int contador) {
		String log = null;

		double[] nobs = null;
		List listaElementos = new ArrayList();
		ArrayList<ArrayList<String>> table_bases = null;
		String[] datas = null;
		String[] modate = null;
		String dia;
		String[] datas_base = null;
		List<String> nomeDasBases = new ArrayList();

		System.out.println("Vai fazer o select dos nobs SAS!");
		nobs = sas.nobs_basesMensal(lib, base, ultimaData, contador);
		listaElementos.add(nobs);

		if (nobs[0] < 0) {
			datas = new String[1];
			datas_base = new String[1];
			modate = new String[1];

			datas[0] = "";
			dia = "";
			datas_base[0] = "";
			modate[0] = "";

			listaElementos.add(datas_base);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);
			return listaElementos;
		}

		System.out.println(nobs.toString());

		// retorna as datas da base

		if (ultimaData.equals("0")) {
			try {
				sas.ComandoSAS("PROC SQL outobs = 6;create table WORK.BASE_OBSERVACAO" + contador + " as SELECT memname FROM WORK.BASE_OBSERVACAO" + contador + " Order by MODATE;QUIT;");
			} catch (GenericError e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		table_bases = sas.baseSAS("SELECT memname FROM WORK.BASE_OBSERVACAO" + contador);
		
		int tam_1 = table_bases.get(0).get(0).trim().length();
		if (tam_1 < 5) {
			datas = new String[table_bases.size()];
			datas_base = new String[table_bases.size()];
			modate = new String[table_bases.size()];

			datas[0] = "";
			dia = "";
			datas_base[0] = "";
			modate[0] = "";

			listaElementos.add(datas_base);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);
		} else {
			for (ArrayList<String> nmBases : table_bases) {
				nomeDasBases.add("\"" + nmBases.get(0).trim() + "\"");
			}

			datas = new String[table_bases.size()];
			datas_base = new String[table_bases.size()];

			for (int base_i = 0; base_i < table_bases.size(); base_i++) {
				datas[base_i] = String.valueOf(table_bases.get(base_i).get(0)).trim();
				String diaMes = diaDoMes(datas[base_i].substring(datas[base_i].length() - 2, datas[base_i].length()),
						Integer.valueOf(
								datas[base_i].substring(datas[base_i].length() - 6, datas[base_i].length() - 2)));
				dia = diaMes + "/" + datas[base_i].substring(datas[base_i].length() - 2, datas[base_i].length()) + "/"
						+ datas[base_i].substring(datas[base_i].length() - 6, datas[base_i].length() - 2);
				datas_base[base_i] = dia;
			}

			if (ultimaData.equals("0")) {
				try {
					sas.ComandoSAS("PROC SQL outobs = 6;create table WORK.lista_Modate" + contador + " as SELECT * FROM WORK.lista_Modate" + contador + " Order by 1;QUIT;");
				} catch (GenericError e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			table_bases = sas.baseSAS("SELECT * FROM WORK.lista_Modate" + contador);
			
			
			modate = new String[table_bases.size()];

			for (int i = 0; i < table_bases.size(); i++) {
				modate[i] = String.valueOf(table_bases.get(i).get(0)).trim();
			}

			listaElementos.add(modate);
			listaElementos.add(nomeDasBases);
			listaElementos.add(modate);

		}
		return listaElementos;
	}

	public String diaDoMes(String mes, int ano) {

		if (mes.equals("01")) {
			return "31";
		} else if (mes.equals("02")) {
			if (isAnoBissexto(ano)) {
				return "29";
			} else {
				return "28";
			}
		} else if (mes.equals("03")) {
			return "31";
		} else if (mes.equals("04")) {
			return "30";
		} else if (mes.equals("05")) {
			return "31";
		} else if (mes.equals("06")) {
			return "30";
		} else if (mes.equals("07")) {
			return "31";
		} else if (mes.equals("08")) {
			return "31";
		} else if (mes.equals("09")) {
			return "30";
		} else if (mes.equals("10")) {
			return "31";
		} else if (mes.equals("11")) {
			return "30";
		} else if (mes.equals("12")) {
			return "31";
		} else {
			return "30";
		}
	}

	public static boolean isAnoBissexto(int ano) {
		if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
			return true;
		} else {
			return false;
		}
	}

	// retorna as bases do sas e faz o tratamento especifico necess�rio para o SAS
	private List<String> getBasesSAS(ConectorSAS sas) throws IOException {
		String log = null;
		ArrayList<ArrayList<String>> table = null;

		// conectando com a base
		try {
			log = sas.ComandoSAS(
					"PROC CONTENTS DATA= HIST.SIGB_SALDOT_201401 out=base (keep= NAME TYPE LENGTH NOBS) NOPRINT;RUN;");

		} catch (GenericError e) {
			System.out.println("Falha ao executar o comando selecionado!!");
			System.out.println(e.getMessage());
		}

		if (log.contains("Error")) {
			System.out.println(log);
		}

		System.out.println("Vai fazer o select no SAS!");

		table = sas.baseSAS("SELECT NAME, TYPE, LENGTH, NOBS FROM WORK.base");

		System.out.println("Vai imprimir os elementos da tabela");

		System.out.println(table);

		return null;

	}
	/* scopus: comentado pois nao poderia ser usado, pois nao esta chamando sas.iniciar(.....)
	public String[] datas_bases(String lib, String base) {
		String log = null;
		ConectorSAS sas = new ConectorSAS();

		ArrayList<ArrayList<String>> table_bases = null;
		String[] datas = null;
		String dia;
		String[] datas_base = null;

		table_bases = sas.baseSAS("SELECT memname FROM WORK.BASE_OBSERVACAO");
		datas = new String[table_bases.size()];
		datas_base = new String[table_bases.size()];

		for (int base_i = 0; base_i < table_bases.size(); base_i++) {
			datas[base_i] = String.valueOf(table_bases.get(base_i).get(0)).trim();
			dia = datas[base_i].substring(datas[base_i].length() - 2, datas[base_i].length()) + "/"
					+ datas[base_i].substring(datas[base_i].length() - 4, datas[base_i].length() - 2) + "/"
					+ datas[base_i].substring(datas[base_i].length() - 8, datas[base_i].length() - 4);
			datas_base[base_i] = dia;
		}

		return datas_base;
	}
	*/
	@SuppressWarnings("unchecked")
	private int calcObservacao(int idTabela, int idBT, ArrayList<Double> nobs_amostra, ArrayList<Double> range_amostra,
			ArrayList<Double> range_media, String[] datas, List<String> nomeDasBases, int data_i, int tamanho_amostra,
			String[] modate, Base base) {

		ObservacaoDiario nobs = new ObservacaoDiario();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			String nBase = "";

			double lmiteInferior = obsDAO.getLimiteInferior(idTabela);
			double lmiteSuperior = obsDAO.getLimiteSuperior(idTabela);

			nobs.setTamanho_amostra(tamanho_amostra);
			nobs.setNobs(nobs_amostra);
			nobs.setRanges(range_amostra);
			nobs.setRangesMedia(range_media);
			nobs.setIdTabela(idTabela);
			nobs.setDesvioBaixo(lmiteInferior);
			nobs.setDesvioCima(lmiteSuperior);


			ArrayList<Double> nm_nobs = nobs.getNobs();
			double sd = nobs.getDesvioPad();
			double avg = nobs.getMedias();
			double lcl_x = nobs.getLimiteInf_Vermelho();
			double ucl_menos = nobs.getLimiteInf_Amarelo();
			double ucl_mais = nobs.getLimiteSup_Amarelo();
			double ucl_x = nobs.getLimiteSup_Vermelho();
			double calc_ldp_udp = nobs.getQtdDesvioNeces();
			double lcl_dp = nobs.getDesvioBaixo();
			double ucl_dp = nobs.getDesvioCima();

			int flag = nobs.getFlags(lmiteInferior, lmiteSuperior);
			ArrayList<List> tabelaFinal;
			List linhaTabela;
			tabelaFinal = new ArrayList();

			linhaTabela = new ArrayList();
			DecimalFormat df = new DecimalFormat("0");
			DecimalFormat df_desvio = new DecimalFormat("0.###");
			String nm_obser = df.format(nm_nobs.get(nm_nobs.size() - 1));
			String desvio = df.format(sd);
			String media = df.format(avg);
			String amplit = df.format(range_amostra.get(range_amostra.size() - 1));
			String media_amp = df.format(range_media.get(range_media.size() - 1));
			String lmtInf_Ver = df.format(lcl_x);
			String lmtInf_Ama = df.format(ucl_menos);
			String lmtSup_Ama = df.format(ucl_mais);
			String lmtSup_Ver = df.format(ucl_x);
			String desvio_nec = df_desvio.format(calc_ldp_udp);

			String desvio_acima = df.format(lcl_dp);
			String desvio_abaixo = df.format(ucl_dp);

			linhaTabela.add(nm_nobs.get(nm_nobs.size() - 1)); // nm_obser
			linhaTabela.add(sd); // desvio
			linhaTabela.add(avg); // media
			linhaTabela.add(range_amostra.get(range_amostra.size() - 1)); // amplit
			linhaTabela.add(range_media.get(range_media.size() - 1)); // media_amp
			linhaTabela.add(lcl_x); // lmtInf_Ver
			linhaTabela.add(ucl_menos); // lmtInf_Ama
			linhaTabela.add(ucl_mais); // lmtSup_Ama
			linhaTabela.add(ucl_x); // lmtSup_Ver
			linhaTabela.add(calc_ldp_udp); // desvio_nec
			linhaTabela.add(lcl_dp); // desvio_acima
			linhaTabela.add(ucl_dp); // desvio_abaixo
			linhaTabela.add(flag); // flag
			linhaTabela.add(datas[data_i]); // flag
			String timeStamp = datas[data_i];
			
			nobs.setNumObs(nm_nobs.get(nm_nobs.size() - 1));
			nobs.setDesvioNecess(calc_ldp_udp);

			nBase = nomeDasBases.get(data_i).replace("\"", "");
			linhaTabela.add(nBase); // nome Base

			if (nobs_amostra.size() >= tamanho_amostra) {
				if (flag == 2) {
					inserirNotificacao(idBT, 1, nBase,
							"Essa base extrapolou o limite m�ximo de observa��es: " + new BigDecimal(String.valueOf(ucl_x))
									+ " tendo um total de: "
									+ new BigDecimal(String.valueOf(nm_nobs.get(nm_nobs.size() - 1))) + " observa��es.");
					if (existeJustificativaObservacao(idTabela, nBase, datas[data_i])) {
						inserirNotificacaoObservacao(idTabela, nBase, nobs, datas[data_i]);
					}
					
					System.out.println("EXTRAPOLOU LIM SUP");
					statusObservacao = 1;
				} else if (flag == -2) {
					inserirNotificacao(idBT, 1, nBase,
							"Essa base extrapolou o limite m�nimo de observa��es: " + new BigDecimal(String.valueOf(lcl_x))
									+ " tendo um total de: " + nm_nobs.get(nm_nobs.size() - 1) + " observa��es.");
					
					if (existeJustificativaObservacao(idTabela, nBase, datas[data_i])) {
						inserirNotificacaoObservacao(idTabela, nBase, nobs, datas[data_i]);
					}
					
					System.out.println("EXTRAPOLOU LIM INF");
					statusObservacao = 1;
				} else if (flag == -1 || flag == 1) {
					
					if (existeJustificativaObservacao(idTabela, nBase, datas[data_i])) {
						inserirNotificacaoObservacao(idTabela, nBase, nobs, datas[data_i]);
					}
					
					statusObservacao = -4;
				} else {
					statusObservacao = 0;
				}
			} else {
				
				if (existeJustificativaObservacao(idTabela, nBase, datas[data_i])) {
					inserirNotificacaoObservacao(idTabela, nBase, nobs, datas[data_i]);
				}
				
				if (flag == -2 || flag == 2) {
					statusObservacao = -2;
				}
			}

			tabelaFinal.add(linhaTabela);

			System.out.println(nm_obser + "	" + desvio + "	" + media + "	" + amplit + "	" + media_amp + "	"
					+ lmtInf_Ver + "	" + lmtInf_Ama + "	" + lmtSup_Ama + "	" + lmtSup_Ver + "	" + desvio_nec + "	"
					+ desvio_acima + "	" + desvio_abaixo + "	" + flag + " " + timeStamp);

			if (!jaExisteAmostragem(idTabela, nBase, datas[data_i])) {
				obsDAO.inserirTabelaAmostragem(idTabela, tabelaFinal);
			}			
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar();
			}
		}

		return statusObservacao;
	}

	@SuppressWarnings("unchecked")
	private List<StatusBases> calcObservacaoHist(int idTabela, int idBT, ArrayList<Double> nobsAmostra, String[] datas,
			List<String> nomeDasBases, int tamanho_amostra, String[] modate, Base base) {

		Observacao nobs = new Observacao();
		GerenciadorDeConexao sqlServer = null;
		List<StatusBases> status = new ArrayList<StatusBases>();
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			String nBase = "";

			double lmiteInferior = obsDAO.getLimiteInferior(idTabela);
			double lmiteSuperior = obsDAO.getLimiteSuperior(idTabela);

			nobs.setNobs(nobsAmostra);
			nobs.setDesvioBaixo(lmiteInferior);
			nobs.setDesvioCima(lmiteSuperior);
			nobs.setTamanho_amostra(tamanho_amostra);
			ArrayList<Double> nm_nobs = nobs.getNobs();
			double[] sd = nobs.getDesvioPad();
			double[] avg = nobs.getMedias();
			double[] range = nobs.getRange();
			double[] r_media = nobs.getMedia_Range();
			double[] lcl_x = nobs.getLimiteInf_Vermelho();
			double[] ucl_menos = nobs.getLimiteInf_Amarelo();
			double[] ucl_mais = nobs.getLimiteSup_Amarelo();
			double[] ucl_x = nobs.getLimiteSup_Vermelho();
			double[] calc_ldp_udp = nobs.getQtdDesvioNeces();
			double[] lcl_dp = nobs.getNmDesvioAbaixo(lmiteInferior);
			double[] ucl_dp = nobs.getNmDesvioAcima(lmiteSuperior);

			int[] flags = nobs.getFlags(lmiteInferior, lmiteSuperior);
			ArrayList<List> tabelaFinal;
			List linhaTabela;
			tabelaFinal = new ArrayList();

			for (int i = 0; i < nm_nobs.size(); i++) {
				linhaTabela = new ArrayList();
				DecimalFormat df = new DecimalFormat("0");
				DecimalFormat df_desvio = new DecimalFormat("0.###");
				String nm_obser = df.format(nm_nobs.get(i));
				String desvio = df.format(sd[i]);
				String media = df.format(avg[i]);
				String amplit = df.format(range[i]);
				String media_amp = df.format(r_media[i]);
				String lmtInf_Ver = df.format(lcl_x[i]);
				String lmtInf_Ama = df.format(ucl_menos[i]);
				String lmtSup_Ama = df.format(ucl_mais[i]);
				String lmtSup_Ver = df.format(ucl_x[i]);
				String desvio_nec = df_desvio.format(calc_ldp_udp[i]);

				String desvio_acima = df.format(lcl_dp[i]);
				String desvio_abaixo = df.format(ucl_dp[i]);

				linhaTabela.add(nm_nobs.get(i)); // nm_obser
				linhaTabela.add(sd[i]); // desvio
				linhaTabela.add(avg[i]); // media
				linhaTabela.add(range[i]); // amplit
				linhaTabela.add(r_media[i]); // media_amp
				linhaTabela.add(lcl_x[i]); // lmtInf_Ver
				linhaTabela.add(ucl_menos[i]); // lmtInf_Ama
				linhaTabela.add(ucl_mais[i]); // lmtSup_Ama
				linhaTabela.add(ucl_x[i]); // lmtSup_Ver
				linhaTabela.add(calc_ldp_udp[i]); // desvio_nec
				linhaTabela.add(lcl_dp[i]); // desvio_acima
				linhaTabela.add(ucl_dp[i]); // desvio_abaixo
				linhaTabela.add(flags[i]); // flag

				nBase = nomeDasBases.get(i).replace("\"", "");

				statusObservacao = 0;
				if (flags[i] == -2 || flags[i] == 2) {
					statusObservacao = -2;
					if (existeJustificativaObservacao(idTabela, nBase, datas[i])) {
						inserirNotificacaoObservacaoHist(idTabela, nBase, nobs, datas[i]);
					}
				}

				StatusBases status_1 = new StatusBases();
				status_1.setIdTb(idTabela);
				status_1.setNomeBase(nBase);
				status_1.setDataModificacao(modate[i]);
				status_1.setStatusObservacao(statusObservacao);

				String dataDeHoje = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());

				status_1.setDataQualidade(dataDeHoje);
				status_1.setPeriodicidade(base.getPeriodicidade());
				status.add(status_1);
				String timeStamp = datas[i];

				linhaTabela.add(timeStamp); // data flag
				linhaTabela.add(nBase);

				tabelaFinal.add(linhaTabela);

				System.out.println(i + "	" + nm_obser + "	" + desvio + "	" + media + "	" + amplit + "	"
						+ media_amp + "	" + lmtInf_Ver + "	" + lmtInf_Ama + "	" + lmtSup_Ama + "	" + lmtSup_Ver + "	"
						+ desvio_nec + "	" + desvio_acima + "	" + desvio_abaixo + "	" + flags[i] + " " + timeStamp);
			}

			obsDAO.inserirTabelaAmostragem(idTabela, tabelaFinal);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar();
			}
		}		

		return status;
	}

	// prepara as bases do SAS para o modelo do que a regra de integridade necessita
	private List<Base> preparaBaseIntegridadeSAS(ConectorSAS sas, String lib, String bases) {

		int contador = 1;
		ArrayList<ArrayList<String>> table_observacao;
		List<Base> basesIntegridade = new ArrayList();
		Base baseInt;

		String log = null;

		sas.gerarBases2(lib, bases);

		table_observacao = sas.baseSAS("SELECT NAME FROM WORK.Lista_Bases_Integridade");

		for (ArrayList obj : table_observacao) {
			int estaVazia = 0;
			baseInt = new Base();
			baseInt.setNomeBase(obj.get(0).toString());
			baseInt.addListaColunas(sas.getCaracteristicasColunas(contador));
			estaVazia = sas.getColunaVazia(
					"SELECT VAZIA FROM WORK.BASE_VAZIA_FINAL WHERE NOME = '" + baseInt.getNomeBase().trim() + "' ");
			if (estaVazia == 0) {
				baseInt.setEstaVazia(true); // esta vazia
			} else {
				baseInt.setEstaVazia(false); // n�o est� vazia
			}
			// baseInt.setNomeBase();

			basesIntegridade.add(baseInt);
			contador++;

		}

		contador = 1;

		return basesIntegridade;
	}

	public Base getBasePeloId(int id) {
		Base base = new Base();
		List<ColunaTabela> colunas = new ArrayList();
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();

			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			base = baseDAO.getBasePeloID(id);
			colunas = baseDAO.getColunasPeloID(id);
			base.addListaColunas(colunas);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return base;

	}

	public ServidorSAS getServidorSASByIdTabela(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		ServidorSAS servSAS = new ServidorSAS();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			servSAS = baseDAO.getServidorSASByIdTabela(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return servSAS;
	}

	private int integridade(Base baseOrigem, Base b) {
		int contErros = 0;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			
			int numNotif = 0;
			int baseRodou = 0;
			sqlServer.iniciar();
			NotificacaoDAO notif = sqlServer.getObjetoNotificacaoDAO();
			statusIntegridade = 0;

			BaseDAO baseDAO = sqlServer.getObjetoBase();
			// baseRodou = baseDAO.checarSeJaExisteBaseRodada(obj.getNomeBase(), 1);
			// //checka se a base ja rodou com sucesso
			baseRodou = 0;

			String tipoErro = "";

			if (baseRodou == 0) {

				System.out.println("A base: " + b.getNomeBase().trim() + " ainda n�o rodou com sucesso, rodando...");
				int aux = 0;

				int cont = 0;
				String msg = "";
				String auxNomeColuna = "";
				String dtModificacao = "";
				String tipoOrigem = "";
				String tipoAtual = "";

				for (StatusBases status_1 : statusBases) {
					if (status_1.getNomeBase().equals(b.getNomeBase().trim())) {
						dtModificacao = status_1.getDataModificacao();
					}
				}
				
				int tamPrimeiroFor = baseOrigem.getColunas().size();
				int tamSegundoFor = 0;
				
				if (baseOrigem.getColunas().size() < b.getColunas().size()) {
					tamPrimeiroFor = baseOrigem.getColunas().size();
					tamSegundoFor = b.getColunas().size() - tamPrimeiroFor;
				} else if (baseOrigem.getColunas().size() > b.getColunas().size()) {
					tamPrimeiroFor = b.getColunas().size();
					tamSegundoFor = baseOrigem.getColunas().size() - tamPrimeiroFor;
				} 

				for (int j = 0; j < tamPrimeiroFor; j++) { // para cada coluna da tabela origem se busca
																			// todas as colunas da "destino" at� que
																			// ache uma correspondencia
					for (int i = 0; i < tamPrimeiroFor; i++) { // loop em todas colunas da tabela em quest�o
						if (b.getColunas().get(i).getNomeColuna().equals(baseOrigem.getColunas().get(j).getNomeColuna())) { // comparando
																										// nome
							aux++;

							if (b.getColunas().get(i).getTamanhoColuna() != baseOrigem.getColunas().get(j).getTamanhoColuna()
									&& b.getColunas().get(i).getTipoColuna() != baseOrigem.getColunas().get(j).getTipoColuna()) { // comparando
								// tamanho
								msg = "O tamanho e o tipo da coluna cadastrada(" + baseOrigem.getColunas().get(j).getNomeColuna()
										+ ") n�o s�o os mesmo que a coluna atual(" + b.getColunas().get(i).getNomeColuna()
										+ ").\r\n";
								msg += "Tamanho cadastro: " + baseOrigem.getColunas().get(j).getTamanhoColuna() + ".\r\n Tamanho atual: "
										+ b.getColunas().get(i).getTamanhoColuna() + "\r\n";

								msg += "Tipo cadastro: " + baseOrigem.getColunas().get(j).getTipoColuna() + ".\r\n Tipo atual: "
										+ b.getColunas().get(i).getTipoColuna();

								if (baseOrigem.getColunas().get(j).getTipoColuna() == 2) {
									tipoOrigem = "N";
								} else {
									tipoOrigem = "C";
								}

								if (b.getColunas().get(i).getTipoColuna() == 2) {
									tipoAtual = "N";
								} else {
									tipoAtual = "C";
								}

								numNotif++;
								statusIntegridade = 1;
								tipoErro = "Tamanho e tipo diferente";
								if (!existeNotificacaoIntegridade(baseOrigem.getColunas().get(j).getNomeColuna(), b.getNomeBase().trim(), dtModificacao)) {
									notif.inserirNotificacaoIntegridade(baseOrigem, b.getNomeBase().trim(),
											baseOrigem.getColunas().get(j).getNomeColuna(), tipoOrigem, baseOrigem.getColunas().get(j).getTamanhoColuna(), tipoAtual,
											b.getColunas().get(i).getTamanhoColuna(), tipoErro, dtModificacao);
								}
								notif.inserirNotificacao(baseOrigem.getColunas().get(j).getIdColuna(), 2, b.getNomeBase().trim(), msg); // inserindo
								// notifica��o;
								contErros++;
							} else if (b.getColunas().get(i).getTamanhoColuna() != baseOrigem.getColunas().get(j).getTamanhoColuna()
									&& b.getColunas().get(i).getTipoColuna() == baseOrigem.getColunas().get(j).getTipoColuna()) { // comparando
								// tamanho
								msg = "O tamanho da coluna cadastrada(" + baseOrigem.getColunas().get(j).getNomeColuna()
										+ ") n�o � o mesmo que a coluna atual(" + b.getColunas().get(i).getNomeColuna()
										+ ").\r\n";
								msg += "Tamanho cadastro: " + baseOrigem.getColunas().get(j).getTamanhoColuna() + ".\r\n Tamanho atual: "
										+ b.getColunas().get(i).getTamanhoColuna();

								if (baseOrigem.getColunas().get(j).getTipoColuna() == 2) {
									tipoOrigem = "N";
								} else {
									tipoOrigem = "C";
								}

								if (b.getColunas().get(i).getTipoColuna() == 2) {
									tipoAtual = "N";
								} else {
									tipoAtual = "C";
								}

								statusIntegridade = 1;

								numNotif++;
								tipoErro = "Tamanho diferente";
								if (!existeNotificacaoIntegridade(baseOrigem.getColunas().get(j).getNomeColuna(), b.getNomeBase().trim(), dtModificacao)) {
									notif.inserirNotificacaoIntegridade(baseOrigem, b.getNomeBase().trim(),
											baseOrigem.getColunas().get(j).getNomeColuna(), tipoOrigem, baseOrigem.getColunas().get(j).getTamanhoColuna(), tipoAtual,
											b.getColunas().get(i).getTamanhoColuna(), tipoErro, dtModificacao);
								}

								notif.inserirNotificacao(baseOrigem.getColunas().get(j).getIdColuna(), 2, b.getNomeBase().trim(), msg); // inserindo
								// notifica��o;
								contErros++;
							} else if (b.getColunas().get(i).getTamanhoColuna() == baseOrigem.getColunas().get(j).getTamanhoColuna()
									&& b.getColunas().get(i).getTipoColuna() != baseOrigem.getColunas().get(j).getTipoColuna()) {
								msg = "O tipo da coluna cadastrada(" + baseOrigem.getColunas().get(j).getNomeColuna()
										+ ") n�o � o mesmo que a coluna atual(" + b.getColunas().get(i).getNomeColuna()
										+ ").\r\n";
								msg += "Tipo cadastro: " + baseOrigem.getColunas().get(j).getTipoColuna() + ".\r\n Tipo atual: "
										+ b.getColunas().get(i).getTipoColuna();

								if (baseOrigem.getColunas().get(j).getTipoColuna() == 2) {
									tipoOrigem = "N";
								} else {
									tipoOrigem = "C";
								}

								if (b.getColunas().get(i).getTipoColuna() == 2) {
									tipoAtual = "N";
								} else {
									tipoAtual = "C";
								}

								statusIntegridade = 1;

								numNotif++;
								tipoErro = "Tipo diferente";
								if (!existeNotificacaoIntegridade(baseOrigem.getColunas().get(j).getNomeColuna(), b.getNomeBase().trim(), dtModificacao)) {
									notif.inserirNotificacaoIntegridade(baseOrigem, b.getNomeBase().trim(),
											baseOrigem.getColunas().get(j).getNomeColuna(), tipoOrigem, baseOrigem.getColunas().get(j).getTamanhoColuna(), tipoAtual,
											b.getColunas().get(i).getTamanhoColuna(), tipoErro, dtModificacao);
								}
								notif.inserirNotificacao(baseOrigem.getColunas().get(j).getIdColuna(), 2, b.getNomeBase().trim(), msg); // inserindo
								// notifica��o;
								contErros++;
							}

							// saindo deste sub-loop pois ja achei a coluna que procurava e fiz os testes
							// necess�rios
							cont = 0;
							break;
						}
					}
					
					if (baseOrigem.getColunas().size() > b.getColunas().size()) {
						for (int i = 0; i < tamSegundoFor; i++) {
							msg = "n�o foi encontrada coluna correspondente � coluna: " + baseOrigem.getColunas().get(i).getNomeColuna()
									+ " nesta base.";
							
							tipoErro = "N�o encontrou coluna";
							
							tipoAtual = "";
							int tamanhoAtual = 0;
							
							if (baseOrigem.getColunas().get(i).getTipoColuna() == 2) {
								tipoOrigem = "N";
							} else {
								tipoOrigem = "C";
							}

							statusIntegridade = 1;

							numNotif++;
							if (!existeNotificacaoIntegridade(baseOrigem.getColunas().get(i).getNomeColuna(), b.getNomeBase(), dtModificacao)) {
								notif.inserirNotificacaoIntegridade(baseOrigem, b.getNomeBase().trim(),
										baseOrigem.getColunas().get(i).getNomeColuna(), tipoOrigem, baseOrigem.getColunas().get(i).getTamanhoColuna(),
										tipoAtual, tamanhoAtual, tipoErro, dtModificacao);
							}
							notif.inserirNotificacao(baseOrigem.getColunas().get(j).getIdColuna(), 2, b.getNomeBase().trim(), msg);

							contErros++;
						}
					} else if(baseOrigem.getColunas().size() < b.getColunas().size()) {
						for (int i = 0; i < tamSegundoFor; i++) {
							msg = "n�o foi encontrada coluna correspondente � coluna: " + b.getColunas().get(i).getNomeColuna()
									+ " nesta base.";
							
							tipoErro = "Nova coluna";
							
							tipoOrigem = "";
							int tamanhoOrigem = 0;
							
							if (b.getColunas().get(i).getTipoColuna() == 2) {
								tipoAtual = "N";
							} else {
								tipoAtual = "C";
							}

							statusIntegridade = 1;

							numNotif++;
							if (!existeNotificacaoIntegridade(b.getColunas().get(i).getNomeColuna(), b.getNomeBase(), dtModificacao)) {
								notif.inserirNotificacaoIntegridade(baseOrigem, b.getNomeBase().trim(),
										b.getColunas().get(i).getNomeColuna(), tipoOrigem, tamanhoOrigem,
										tipoAtual, b.getColunas().get(i).getTamanhoColuna(), tipoErro, dtModificacao);
							}
							notif.inserirNotificacao(99999, 2, b.getNomeBase().trim(), msg);

							contErros++;
						}
					}

				}

				baseRodou = baseDAO.checarSeJaExisteBaseRodada(b.getNomeBase().trim(), 2); // checka se a base ja rodou com
				// sucesso
				if (baseRodou > 0) {
					if (contErros == 0) { // base ja rodou mas tinha erro, agora ser� feito udpdate para sem erros
						baseDAO.updateBaseRodada(b.getNomeBase().trim(), 1);
						System.out.println("update rodadas para sucesso");
					}
				} else {
					if (contErros > 0) { // inserir em bases rodadas mas COM erro
						baseDAO.inserirBaseRodadas(b.getNomeBase().trim(), 2);
						System.out.println("inser rodadas para erro");
						statusIntegridade = 1;
					} else { // inserir em bases rodadas SEM erro
						baseDAO.inserirBaseRodadas(b.getNomeBase().trim(), 1);
						System.out.println("insert rodadas para sucesso");
					}
				}

				for (StatusBases status_1 : statusBases) {
					if (status_1.getNomeBase().equals(b.getNomeBase().trim())) {
						status_1.setStatusIntegridade(statusIntegridade);
					}
				}

			} else {
				System.out.println("base: " + b.getNomeBase().trim() + " J� rodou com sucesso! Partindo para pr�xima base");
			}			
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		return contErros;
	}

	private ArrayList<String> PSI(double resultadoPSI, ColunaTabela d, String nmBase) {

		ArrayList<String> basesComErro = new ArrayList();
		if (resultadoPSI == -1) {
			String msg = "O campo " + d.getNomeColuna()
					+ " apresentou erro na m�trica de PSI pois existem valores fora das faixas cadastradas.";
			inserirNotificacao(d.getIdColuna(), 7, nmBase, msg);
			basesComErro.add(nmBase);
			statusPSI = -1;
		} else if (resultadoPSI == -2) {

		} else {
			String percentual = new DecimalFormat("#0.00").format(resultadoPSI * 100);
			String msg = "O campo " + d.getNomeColuna() + " apresentou PSI de " + percentual
					+ "% que � maior do que 10%(que � o indicado).";
			inserirNotificacao(d.getIdColuna(), 7, nmBase, msg);
			basesComErro.add(nmBase);
			statusPSI = -1;
		}

		for (StatusBases status_1 : statusBases) {
			if (status_1.getNomeBase().equals(nmBase.trim())) {
				statusPSI = 1;
				status_1.setStatusPSI(statusPSI);
			}
		}

		return basesComErro;
	}

	private String resposta(List<String> listaBases) {
		return "teste";
	}

	private ArrayList<String> duplicidade(ArrayList<ArrayList<String>> resultadoDuplicidade, int idColuna, Base base) {
		ArrayList<String> basesComErro = new ArrayList();
		String dtModificacao = "";

		for (ArrayList<String> aList : resultadoDuplicidade) {
			String percentual = new DecimalFormat("#0.00").format(Double.parseDouble(aList.get(2)) * 100);
			int quantidade = Integer.parseInt(aList.get(3).split("\\.")[0]);
			String msg = "O campo " + aList.get(1) + " tem " + percentual + "%(" + quantidade
					+ " registros) de duplicidade.";
			inserirNotificacao(idColuna, 6, aList.get(0), msg);

			basesComErro.add(aList.get(0));

			for (StatusBases status_1 : statusBases) {
				if (status_1.getNomeBase().equals(aList.get(0).trim())) {
					statusDuplicidade = 1;
					status_1.setStatusDuplicidade(statusDuplicidade);
					dtModificacao = status_1.getDataModificacao();
				}
			}
			if (!existeNotificacaoDuplicidade(aList.get(1), aList.get(0), dtModificacao)) {
				inserirNotificacaoDuplicidade(base, aList.get(0), aList.get(1), aList.get(2), aList.get(3),
						aList.get(4), dtModificacao);
			}

		}

		return basesComErro;
	}

	private ArrayList<String> missing(ArrayList<ArrayList<String>> resultadoMissing, int idColuna, Base base) {
		ArrayList<String> basesComErro = new ArrayList();
		String dtModificacao = "";

		for (ArrayList<String> aList : resultadoMissing) {
			String percentual = new DecimalFormat("#0.00").format(Double.parseDouble(aList.get(2)) * 100);
			String msg = "O campo " + aList.get(1) + " tem " + percentual + "% de missing, totalizando: " + aList.get(3)
					+ " linhas sem conte�do.";
			inserirNotificacao(idColuna, 4, aList.get(0), msg);
			basesComErro.add(aList.get(0));

			for (StatusBases status_1 : statusBases) {
				if (status_1.getNomeBase().equals(aList.get(0).trim())) {
					statusMissing = 1;
					status_1.setStatusMissing(statusMissing);
					dtModificacao = status_1.getDataModificacao();
				}
			}
			if (!existeNotificacaoMissing(aList.get(1), aList.get(0), dtModificacao)) {
				inserirNotificacaoMissing(base, aList.get(0), aList.get(1), aList.get(2), aList.get(3), dtModificacao);
			}

		}

		return basesComErro;
	}

	private ArrayList<String> dominio(ArrayList<ArrayList<String>> resultadoDominio, int idColuna, String dominio,
			Base base) {
		ArrayList<String> basesComErro = new ArrayList();
		String dtModificacao = "";

		for (ArrayList<String> aList : resultadoDominio) {
			String percentual = new DecimalFormat("#0.00").format(Double.parseDouble(aList.get(3)) * 100);
			int quantidade = Integer.parseInt(aList.get(4).split("\\.")[0]);

			String msg = percentual + "%(" + quantidade + ") dos registros do campo " + aList.get(0)
					+ " est�o fora do dom�nio espec�ficado: " + dominio;

			inserirNotificacao(idColuna, 5, aList.get(1), msg);
			basesComErro.add(aList.get(1));

			for (StatusBases status_1 : statusBases) {
				if (status_1.getNomeBase().equals(aList.get(1).trim())) {
					statusDominio = 1;
					status_1.setStatusDominio(statusDominio);
					dtModificacao = status_1.getDataModificacao();
				}
			}
			if (!existeNotificacaoDominio(aList.get(0), aList.get(1), dtModificacao)) {
				inserirNotificacaoDominio(base, aList.get(1), aList.get(0), aList.get(3), aList.get(4), aList.get(5),
						dtModificacao);
			}
		}
		return basesComErro;
	}

	private ArrayList<String> range(ArrayList<ArrayList<String>> resultadoRange, int idColuna, Base base) {
		ArrayList<String> basesComErro = new ArrayList();
		String dtModificacao = "";

		for (ArrayList<String> aList : resultadoRange) {
			System.out.println("Nome base: " + aList.get(0).trim() + " nome campo: " + aList.get(1));
			String msg = "Existem " + aList.get(2).split("\\.")[0] + " ocorrencias de range para a coluna : "
					+ aList.get(1) + ". Minimo: " + aList.get(4) + ". Maximo: " + aList.get(5);
			inserirNotificacao(idColuna, 3, aList.get(0).trim(), msg);
			basesComErro.add(aList.get(0).trim());
			for (StatusBases status_1 : statusBases) {
				if (status_1.getNomeBase().equals(aList.get(0).trim())) {
					status_1.setStatusRange(1);
					dtModificacao = status_1.getDataModificacao();
				}
			}
			if (!existeNotificacaoRange(aList.get(1), aList.get(0).trim(), dtModificacao)) {
				inserirNotificacaoRange(base, aList.get(0).trim(), aList.get(1), aList.get(2).split("\\.")[0], aList.get(3),
						dtModificacao);
			}

		}

		return basesComErro;
	}

	// lista todas as bases cadastradas, futuramente o metodo deve ser filtrado por
	// usu�rio
	private List<Base> listarTodos() {
		GerenciadorDeConexao sqlServer = null;
		List<Base> listaBases;
		listaBases = new ArrayList();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			listaBases = baseDAO.listarTodos();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return listaBases;

	}

	public void inserirBaseRodadas(String nomeBase, int statusBase) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			baseDAO.inserirBaseRodadas(nomeBase, statusBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	// tipo 1 checa so se ja rodou somente se teve sucesso, tipo 2 checa se rodou,
	// independentemente de sucesso ou n�o
	private int checarSeJaExisteBaseRodada(String nomeBase, int tipo) {
		GerenciadorDeConexao sqlServer = null;
		int contador;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			contador = baseDAO.checarSeJaExisteBaseRodada(nomeBase, tipo);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar();
			}
		}
		return contador;

	}

	private void updateBaseRodada(String nomeBase, int status) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			baseDAO.updateBaseRodada(nomeBase, status);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	private List<Regra> getRegrasPorColuna(int idTb, int idCol) {
		GerenciadorDeConexao sqlServer = null;
		List<Regra> idRegras;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			idRegras = regraDAO.getRegrasPorColuna(idTb, idCol);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return idRegras;
	}

	private List<ColunaTabela> getColunasPeloID(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		List<ColunaTabela> colunas;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			colunas = baseDAO.getColunasPeloID(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
		
		return colunas;
	}

	private ArrayList<ArrayList<String>> prepararDadosDominioSAS(ConectorSAS sas, String lib, String bases,
			ColunaTabela coluna, Base base, int contador, double nobs) {
		String log = "";
		String strQuery1 = "";
		String strQuery2 = "";
		String strLib = "";
		ArrayList<ArrayList<String>> tabelaDominioErros = new ArrayList<ArrayList<String>>();

		if (!bases.contains("\"")) {
			bases = "\"" + bases + "\"";
		}

		try {
			if (lib.length() > 9) {
				log = sas.ComandoSAS("libname INTEG " + lib + ";");
				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS(
							"%let limite = 5000000;ods output Members=Lista_Bases;proc datasets library=INTEG memtype=data;run;data Lista_Bases_Dominio;SET work.Lista_Bases (keep= Name WHERE = (NAME in ("
									+ bases
									+ ")));RUN;DATA _NULL_;SET WORK.Lista_Bases_Dominio;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;DATA Lista_Bases_Dominio;SET work.Lista_Bases_Dominio;count + 1;RUN;%PUT NOBS_OBS: &NOBS_OBS.;");
					log += sas.ComandoSAS("%let campo_dominio = " + coluna.getNomeColuna() + ";%let dominios = '"
							+ coluna.getRegras().get(0).getDetalheRegra()
							+ "';%MACRO GERARLISTA(CAMPO_DOMINIO, DOMINIOS);	PROC DELETE DATA=BASE_DOMINIO;	RUN;	PROC DELETE DATA=VALORES_DOMINIOS;	RUN;	%IF %SYSFUNC(EXIST(WORK.BASE_DOMINIO_FINAL"
							+ contador
							+ ")) %THEN		%DO;			DATA _NULL_;				IF 0 THEN					SET WORK.BASE_DOMINIO_FINAL"
							+ contador
							+ " NOBS=N;				CALL SYMPUTX('NOBS_BASE_FINAL',N);				STOP;			RUN;			%PUT &&NOBS_BASE_FINAL.;			%IF &NOBS_BASE_FINAL. > 0 %THEN				%DO;					DATA BASE_DOMINIO_FINAL"
							+ contador + ";						SET WORK.BASE_DOMINIO_FINAL" + contador
							+ ";						IF ID > 10000000;					RUN;%END;		%END;	%DO J=1 %TO &NOBS_OBS.;		PROC CONTENTS DATA=INTEG.&&NOME_BASE&J.(keep = &CAMPO_DOMINIO.) OUT=CONTENTS"
							+ contador
							+ " (KEEP= NAME LENGTH TYPE) NOPRINT SHORT;		RUN;		DATA _NULL_;			SET WORK.CONTENTS"
							+ contador
							+ ";			CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH);			CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE);		RUN;		%IF &TIPO1. = 1 %THEN			%DO;				DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.);					LENGTH &CAMPO_DOMINIO. &TAMANHO1.;					DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' ');						&CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', ');						OUTPUT;					END;				RUN;				PROC SORT DATA=BASE_DOMINIOS;					BY &CAMPO_DOMINIO.;				RUN;			%END;		%ELSE			%DO;				DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.);				LENGTH &CAMPO_DOMINIO. $&TAMANHO1.;					DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' ');						&CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', ');						OUTPUT;					END;				RUN;				PROC SORT DATA=BASE_DOMINIOS;					BY &CAMPO_DOMINIO.;				RUN;			%END;		%PUT &&NOME_BASE&J.;		%PUT TAMANHO : &TAMANHO1.;		DATA _NULL_;			IF 0 THEN				SET INTEG.&&NOME_BASE&J. NOBS=N;			CALL SYMPUTX('NOBS_BASE',N);			STOP;		RUN;		%PUT NOBS_BASE: &NOBS_BASE.;		%PUT LIMITE: &LIMITE.;		%IF &NOBS_BASE. > 0 %THEN			%DO;				%IF &NOBS_BASE. > &LIMITE. %THEN					%DO;						%DO I = 1 %TO &NOBS_BASE. %BY &LIMITE.;							%PUT COMECO: &I.;							%LET FINAL =  %SYSFUNC(SUM(&LIMITE. + &I. - 1));							%PUT FINAL: &FINAL.;							PROC SQL;								CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM INTEG.&&NOME_BASE&J.(FIRSTOBS=&I. OBS=&FINAL.) ORDER BY &CAMPO_DOMINIO.;							QUIT;							%IF &TIPO1. = 1 %THEN								%DO;									DATA QTDE_DOMINIOS_FORA_TOTAL;										LENGTH &CAMPO_DOMINIO. &TAMANHO1.;										MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;										BY &CAMPO_DOMINIO.;										IF NOT INA;									RUN;								%END;							%ELSE								%DO;									DATA QTDE_DOMINIOS_FORA_TOTAL;										LENGTH &CAMPO_DOMINIO. $&TAMANHO1.;										MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;										BY &CAMPO_DOMINIO.;										IF NOT INA;									RUN;								%END;							DATA _NULL_;								IF 0 THEN									SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N;								CALL SYMPUTX('QTDE_DOMINIOS_FORA',N);								STOP;							RUN;							%PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.;							PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY;								BY &CAMPO_DOMINIO.;							RUN;							DATA BASE_DOMINIO_AUX;								QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.;								CAMPO = \"&CAMPO_DOMINIO.\";								NOME = \"&&NOME_BASE&J.\";							RUN;							DATA DOMINIOS_ENCON;								SET DOMINIOS_ENCON;								ID = &J.;							RUN;							PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE;							PROC SORT DATA=VALORES_DOMINIOS THREADS NODUPKEY;								BY ID &CAMPO_DOMINIO.;							RUN;							PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE;						%END;				%END;			%ELSE				%DO;					PROC SQL;							CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM INTEG.&&NOME_BASE&J. ORDER BY &CAMPO_DOMINIO.;						QUIT;						%IF &TIPO1. = 1 %THEN							%DO;								DATA QTDE_DOMINIOS_FORA_TOTAL;									LENGTH &CAMPO_DOMINIO. &TAMANHO1.;									MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;									BY &CAMPO_DOMINIO.;									IF NOT INA;								RUN;							%END;						%ELSE							%DO;								DATA QTDE_DOMINIOS_FORA_TOTAL;									LENGTH &CAMPO_DOMINIO. $&TAMANHO1.;									MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;									BY &CAMPO_DOMINIO.;									IF NOT INA;								RUN;						%END;				DATA _NULL_;						IF 0 THEN							SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N;						CALL SYMPUTX('QTDE_DOMINIOS_FORA',N);						STOP;					RUN;				%PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.;				PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY;						BY &CAMPO_DOMINIO.;					RUN;				DATA BASE_DOMINIO_AUX;						QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.;						CAMPO = \"&CAMPO_DOMINIO.\";						NOME = \"&&NOME_BASE&J.\";					RUN;				DATA DOMINIOS_ENCON;						SET DOMINIOS_ENCON;						ID = &J.;					RUN;				PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE;				PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE;				%END;		DATA TESTE;				SET VALORES_DOMINIOS(WHERE=(ID = &J.));			RUN;		DATA _NULL_;				IF 0 THEN					SET TESTE NOBS=N;				CALL SYMPUTX('VAL_DOMINIOS',N);				STOP;			RUN;		%PUT VAL_DOMINIOS: &VAL_DOMINIOS.;		PROC SQL;				CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT CAMPO, NOME, &TIPO1. AS TIPO,SUM(QTDE_DOM_FORA)/&NOBS_BASE. AS QTDE_DOM_FORA_PORC,SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA,&VAL_DOMINIOS. AS VAL_DOM,&J. AS ID FROM BASE_DOMINIO;			QUIT;		PROC SORT DATA=BASE_DOMINIO_TOTAL NODUPKEY;				BY NOME;			RUN;		PROC DELETE DATA=BASE_DOMINIO;			RUN;		DATA BASE_DOMINIO_TOTAL;				SET WORK.BASE_DOMINIO_TOTAL;				FORMAT QTDE_DOM_FORA_PORC PERCENT8.3;			RUN;		PROC APPEND BASE=BASE_DOMINIO_FINAL"
							+ contador
							+ " DATA=BASE_DOMINIO_TOTAL FORCE;		%END;	%ELSE		%DO;		DATA BASE_DOMINIO;				QTDE_DOM_FORA = -1;				CAMPO = \"&CAMPO_DOMINIO.\";				NOME = \"&&NOME_BASE&J.\";			RUN;		%LET VAL_DOMINIOS = 0;		PROC SQL;				CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT 					CAMPO, 					NOME, 					&TIPO1. AS TIPO,					SUM(QTDE_DOM_FORA)/1 AS QTDE_DOM_FORA_PORC,					SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA,					&VAL_DOMINIOS. AS VAL_DOM,					&J. AS ID FROM BASE_DOMINIO;			QUIT;		PROC APPEND BASE=BASE_DOMINIO_FINAL"
							+ contador
							+ " DATA=BASE_DOMINIO_TOTAL FORCE;		PROC DELETE DATA=BASE_DOMINIO;			RUN;	%END;%END;PROC DELETE DATA=QTDE_DOMINIOS_FORA_TOTAL;RUN;PROC DELETE DATA=BASE_DOMINIO_TOTAL;RUN;PROC DELETE DATA=DOMINIOS_ENCON;RUN;PROC DELETE DATA=LISTA_BASES;RUN;PROC DELETE DATA=CONTENTS"
							+ contador
							+ ";RUN;PROC DELETE DATA=BASE_DOMINIOS;RUN;PROC DELETE DATA=BASE_MENOR;RUN;PROC DELETE DATA=BASE_DOMINIO_AUX;RUN;PROC DELETE DATA=TESTE;RUN; DATA BASE_DOMINIO_FINAL"
							+ contador + ";SET WORK.BASE_DOMINIO_FINAL" + contador
							+ ";IF QTDE_DOM_FORA > 0;RUN; %MEND GERARLISTA;%GERARLISTA(CAMPO_DOMINIO = &CAMPO_DOMINIO, DOMINIOS = &DOMINIOS);");
				} else {
					log += sas.ComandoSAS("%let campo_dominio = " + coluna.getNomeColuna() + "; %let NOME_BASE = "
							+ bases.substring(1, bases.length() - 1) + "; %let dominios = "
							+ coluna.getRegras().get(0).getDetalheRegra() + "; %let first_obs = " + new BigDecimal(nobs).intValueExact()
							+ "; %MACRO GERARLISTA(CAMPO_DOMINIO, DOMINIOS); PROC DELETE DATA=BASE_DOMINIO; RUN; PROC DELETE DATA=VALORES_DOMINIOS; RUN; PROC DELETE DATA=BASE_DOMINIO_FINAL"
							+ contador
							+ "; RUN; PROC CONTENTS DATA=INTEG.&NOME_BASE.(keep=&CAMPO_DOMINIO.) OUT=CONTENTS (KEEP= NAME LENGTH TYPE) NOPRINT SHORT; RUN; DATA _NULL_; SET WORK.CONTENTS; CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH); CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE); RUN; %IF &TIPO1. = 1 %THEN %DO; DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.); LENGTH &CAMPO_DOMINIO. &TAMANHO1.; DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' '); &CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', '); OUTPUT; END; RUN; PROC SORT DATA=BASE_DOMINIOS; BY &CAMPO_DOMINIO.; RUN; %END; %ELSE %DO; DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.); LENGTH &CAMPO_DOMINIO. $&TAMANHO1.; DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' '); &CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', '); OUTPUT; END; RUN; PROC SORT DATA=BASE_DOMINIOS; BY &CAMPO_DOMINIO.; RUN; %END; %PUT &NOME_BASE.; %PUT TAMANHO : &TAMANHO1.; DATA _NULL_; IF 0 THEN SET INTEG.&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &NOBS_BASE.; %PUT LIMITE: &LIMITE.; %IF &NOBS_BASE. > 0 %THEN %DO; %IF &NOBS_BASE. > &LIMITE. %THEN %DO; %DO I = &first_obs. %TO &NOBS_BASE. %BY &LIMITE.; %PUT COMECO: &I.; %LET FINAL = %SYSFUNC(SUM(&LIMITE. + &I.)); %PUT FINAL: &FINAL.; PROC SQL; CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM INTEG.&NOME_BASE.(FIRSTOBS=&I. OBS=&FINAL.) ORDER BY &CAMPO_DOMINIO.; QUIT; %IF &TIPO1. = 1 %THEN %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. &TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; %ELSE %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. $&TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; DATA _NULL_; IF 0 THEN SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N; CALL SYMPUTX('QTDE_DOMINIOS_FORA',N); STOP; RUN; %PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.; PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY; BY &CAMPO_DOMINIO.; RUN; DATA BASE_DOMINIO_AUX; QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.; CAMPO = \"&CAMPO_DOMINIO.\"; NOME = \"&NOME_BASE.\"; RUN; DATA DOMINIOS_ENCON; SET DOMINIOS_ENCON; RUN; PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE; PROC SORT DATA=VALORES_DOMINIOS THREADS NODUPKEY; BY &CAMPO_DOMINIO.; RUN; PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE; %END; %END; %ELSE %DO; PROC SQL; CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM INTEG.&NOME_BASE.(FIRSTOBS=&first_obs.) ORDER BY &CAMPO_DOMINIO.; QUIT; %IF &TIPO1. = 1 %THEN %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. &TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; %ELSE %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. $&TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; DATA _NULL_; IF 0 THEN SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N; CALL SYMPUTX('QTDE_DOMINIOS_FORA',N); STOP; RUN; %PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.; PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY; BY &CAMPO_DOMINIO.; RUN; DATA BASE_DOMINIO_AUX; QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.; CAMPO = \"&CAMPO_DOMINIO.\"; NOME = \"&NOME_BASE.\"; RUN; DATA DOMINIOS_ENCON; SET DOMINIOS_ENCON; RUN; PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE; PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE; %END; DATA _NULL_; IF 0 THEN SET VALORES_DOMINIOS NOBS=N; CALL SYMPUTX('VAL_DOMINIOS',N); STOP; RUN; %PUT VAL_DOMINIOS: &VAL_DOMINIOS.; DATA _NULL_; IF 0 THEN SET INTEG.&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE_MENOR',N); STOP; RUN; PROC SQL; CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT CAMPO, NOME, &TIPO1. AS TIPO,SUM(QTDE_DOM_FORA)/%sysfunc(sum(&NOBS_BASE. - &first_obs.)) AS QTDE_DOM_FORA_PORC,SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA,&VAL_DOMINIOS. AS VAL_DOM FROM BASE_DOMINIO; QUIT; PROC SORT DATA=BASE_DOMINIO_TOTAL NODUPKEY; BY NOME; RUN; PROC DELETE DATA=BASE_DOMINIO; RUN; DATA BASE_DOMINIO_TOTAL; SET WORK.BASE_DOMINIO_TOTAL; FORMAT QTDE_DOM_FORA_PORC PERCENT8.3; RUN; PROC APPEND BASE=BASE_DOMINIO_FINAL DATA=BASE_DOMINIO_TOTAL FORCE; %END; %ELSE %DO; DATA BASE_DOMINIO; QTDE_DOM_FORA = -1; CAMPO = \"&CAMPO_DOMINIO.\"; NOME = \"&NOME_BASE.\"; RUN; %LET VAL_DOMINIOS = 0; PROC SQL; CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT CAMPO, NOME, &TIPO1. AS TIPO, SUM(QTDE_DOM_FORA)/1 AS QTDE_DOM_FORA_PORC, SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA, &VAL_DOMINIOS. AS VAL_DOM FROM BASE_DOMINIO; QUIT; PROC APPEND BASE=BASE_DOMINIO_FINAL"
							+ contador
							+ " DATA=BASE_DOMINIO_TOTAL FORCE; PROC DELETE DATA=BASE_DOMINIO; RUN; %END; PROC DELETE DATA=QTDE_DOMINIOS_FORA_TOTAL; RUN; PROC DELETE DATA=BASE_DOMINIO_TOTAL; RUN; PROC DELETE DATA=DOMINIOS_ENCON; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=CONTENTS; RUN; PROC DELETE DATA=BASE_DOMINIOS; RUN; PROC DELETE DATA=BASE_MENOR; RUN; PROC DELETE DATA=BASE_DOMINIO_AUX; RUN; PROC DELETE DATA=TESTE; RUN; data BASE_DOMINIO_FINAL"
							+ contador + "; SET WORK.BASE_DOMINIO_FINAL" + contador
							+ "; IF QTDE_DOM_FORA > 0; RUN; %MEND GERARLISTA; %GERARLISTA(CAMPO_DOMINIO = &CAMPO_DOMINIO, DOMINIOS = &DOMINIOS);");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_DOMINIO_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_DOMINIO_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");

			} else {
				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS("%let limite = 5000000;ods output Members=Lista_Bases;proc datasets library="
							+ lib
							+ " memtype=data;run;data Lista_Bases_Dominio;SET work.Lista_Bases (keep= Name WHERE = (NAME in ("
							+ bases
							+ ")));RUN;DATA _NULL_;SET WORK.Lista_Bases_Dominio;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;DATA Lista_Bases_Dominio;SET work.Lista_Bases_Dominio;count + 1;RUN;%PUT NOBS_OBS: &NOBS_OBS.;");

					log += sas.ComandoSAS("%let campo_dominio = " + coluna.getNomeColuna() + ";%let dominios = '"
							+ coluna.getRegras().get(0).getDetalheRegra()
							+ "';%MACRO GERARLISTA(CAMPO_DOMINIO, DOMINIOS);	PROC DELETE DATA=BASE_DOMINIO;	RUN;	PROC DELETE DATA=VALORES_DOMINIOS;	RUN;	%IF %SYSFUNC(EXIST(WORK.BASE_DOMINIO_FINAL"
							+ contador
							+ ")) %THEN		%DO;			DATA _NULL_;				IF 0 THEN					SET WORK.BASE_DOMINIO_FINAL"
							+ contador
							+ " NOBS=N;				CALL SYMPUTX('NOBS_BASE_FINAL',N);				STOP;			RUN;			%PUT &&NOBS_BASE_FINAL.;			%IF &NOBS_BASE_FINAL. > 0 %THEN				%DO;					DATA BASE_DOMINIO_FINAL"
							+ contador + ";						SET WORK.BASE_DOMINIO_FINAL" + contador
							+ ";						IF ID > 10000000;					RUN;%END;		%END;	%DO J=1 %TO &NOBS_OBS.;		PROC CONTENTS DATA="
							+ lib + ".&&NOME_BASE&J.(keep=&CAMPO_DOMINIO.) OUT=CONTENTS" + contador
							+ " (KEEP= NAME LENGTH TYPE) NOPRINT SHORT;		RUN;		DATA _NULL_;			SET WORK.CONTENTS"
							+ contador
							+ ";			CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH);			CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE);		RUN;		%IF &TIPO1. = 1 %THEN			%DO;				DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.);					LENGTH &CAMPO_DOMINIO. &TAMANHO1.;					DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' ');						&CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', ');						OUTPUT;					END;				RUN;				PROC SORT DATA=BASE_DOMINIOS;					BY &CAMPO_DOMINIO.;				RUN;			%END;		%ELSE			%DO;				DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.);				LENGTH &CAMPO_DOMINIO. $&TAMANHO1.;					DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' ');						&CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', ');						OUTPUT;					END;				RUN;				PROC SORT DATA=BASE_DOMINIOS;					BY &CAMPO_DOMINIO.;				RUN;			%END;		%PUT &&NOME_BASE&J.;		%PUT TAMANHO : &TAMANHO1.;		DATA _NULL_;			IF 0 THEN				SET "
							+ lib
							+ ".&&NOME_BASE&J. NOBS=N;			CALL SYMPUTX('NOBS_BASE',N);			STOP;		RUN;		%PUT NOBS_BASE: &NOBS_BASE.;		%PUT LIMITE: &LIMITE.;		%IF &NOBS_BASE. > 0 %THEN			%DO;				%IF &NOBS_BASE. > &LIMITE. %THEN					%DO;						%DO I = 1 %TO &NOBS_BASE. %BY &LIMITE.;							%PUT COMECO: &I.;							%LET FINAL =  %SYSFUNC(SUM(&LIMITE. + &I. - 1));							%PUT FINAL: &FINAL.;							PROC SQL;								CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM "
							+ lib
							+ ".&&NOME_BASE&J.(FIRSTOBS=&I. OBS=&FINAL.) ORDER BY &CAMPO_DOMINIO.;							QUIT;							%IF &TIPO1. = 1 %THEN								%DO;									DATA QTDE_DOMINIOS_FORA_TOTAL;										LENGTH &CAMPO_DOMINIO. &TAMANHO1.;										MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;										BY &CAMPO_DOMINIO.;										IF NOT INA;									RUN;								%END;							%ELSE								%DO;									DATA QTDE_DOMINIOS_FORA_TOTAL;										LENGTH &CAMPO_DOMINIO. $&TAMANHO1.;										MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;										BY &CAMPO_DOMINIO.;										IF NOT INA;									RUN;								%END;							DATA _NULL_;								IF 0 THEN									SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N;								CALL SYMPUTX('QTDE_DOMINIOS_FORA',N);								STOP;							RUN;							%PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.;							PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY;								BY &CAMPO_DOMINIO.;							RUN;							DATA BASE_DOMINIO_AUX;								QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.;								CAMPO = \"&CAMPO_DOMINIO.\";								NOME = \"&&NOME_BASE&J.\";							RUN;							DATA DOMINIOS_ENCON;								SET DOMINIOS_ENCON;								ID = &J.;							RUN;							PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE;							PROC SORT DATA=VALORES_DOMINIOS THREADS NODUPKEY;								BY ID &CAMPO_DOMINIO.;							RUN;							PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE;						%END;				%END;			%ELSE				%DO;					PROC SQL;							CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM "
							+ lib
							+ ".&&NOME_BASE&J. ORDER BY &CAMPO_DOMINIO.;						QUIT;						%IF &TIPO1. = 1 %THEN							%DO;								DATA QTDE_DOMINIOS_FORA_TOTAL;									LENGTH &CAMPO_DOMINIO. &TAMANHO1.;									MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;									BY &CAMPO_DOMINIO.;									IF NOT INA;								RUN;							%END;						%ELSE							%DO;								DATA QTDE_DOMINIOS_FORA_TOTAL;									LENGTH &CAMPO_DOMINIO. $&TAMANHO1.;									MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR;									BY &CAMPO_DOMINIO.;									IF NOT INA;								RUN;						%END;				DATA _NULL_;						IF 0 THEN							SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N;						CALL SYMPUTX('QTDE_DOMINIOS_FORA',N);						STOP;					RUN;				%PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.;				PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY;						BY &CAMPO_DOMINIO.;					RUN;				DATA BASE_DOMINIO_AUX;						QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.;						CAMPO = \"&CAMPO_DOMINIO.\";						NOME = \"&&NOME_BASE&J.\";					RUN;				DATA DOMINIOS_ENCON;						SET DOMINIOS_ENCON;						ID = &J.;					RUN;				PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE;				PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE;				%END;		DATA TESTE;				SET VALORES_DOMINIOS(WHERE=(ID = &J.));			RUN;		DATA _NULL_;				IF 0 THEN					SET TESTE NOBS=N;				CALL SYMPUTX('VAL_DOMINIOS',N);				STOP;			RUN;		%PUT VAL_DOMINIOS: &VAL_DOMINIOS.;		PROC SQL;				CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT CAMPO, NOME, &TIPO1. AS TIPO,SUM(QTDE_DOM_FORA)/&NOBS_BASE. AS QTDE_DOM_FORA_PORC,SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA,&VAL_DOMINIOS. AS VAL_DOM,&J. AS ID FROM BASE_DOMINIO;			QUIT;		PROC SORT DATA=BASE_DOMINIO_TOTAL NODUPKEY;				BY NOME;			RUN;		PROC DELETE DATA=BASE_DOMINIO;			RUN;		DATA BASE_DOMINIO_TOTAL;				SET WORK.BASE_DOMINIO_TOTAL;				FORMAT QTDE_DOM_FORA_PORC PERCENT8.3;			RUN;		PROC APPEND BASE=BASE_DOMINIO_FINAL"
							+ contador
							+ " DATA=BASE_DOMINIO_TOTAL FORCE;		%END;	%ELSE		%DO;		DATA BASE_DOMINIO;				QTDE_DOM_FORA = -1;				CAMPO = \"&CAMPO_DOMINIO.\";				NOME = \"&&NOME_BASE&J.\";			RUN;		%LET VAL_DOMINIOS = 0;		PROC SQL;				CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT 					CAMPO, 					NOME, 					&TIPO1. AS TIPO,					SUM(QTDE_DOM_FORA)/1 AS QTDE_DOM_FORA_PORC,					SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA,					&VAL_DOMINIOS. AS VAL_DOM,					&J. AS ID FROM BASE_DOMINIO;			QUIT;		PROC APPEND BASE=BASE_DOMINIO_FINAL"
							+ contador
							+ " DATA=BASE_DOMINIO_TOTAL FORCE;		PROC DELETE DATA=BASE_DOMINIO;			RUN;	%END;%END;PROC DELETE DATA=QTDE_DOMINIOS_FORA_TOTAL;RUN;PROC DELETE DATA=BASE_DOMINIO_TOTAL;RUN;PROC DELETE DATA=DOMINIOS_ENCON;RUN;PROC DELETE DATA=LISTA_BASES;RUN;PROC DELETE DATA=CONTENTS"
							+ contador
							+ ";RUN;PROC DELETE DATA=BASE_DOMINIOS;RUN;PROC DELETE DATA=BASE_MENOR;RUN;PROC DELETE DATA=BASE_DOMINIO_AUX;RUN;PROC DELETE DATA=TESTE;RUN; DATA BASE_DOMINIO_FINAL"
							+ contador + ";SET WORK.BASE_DOMINIO_FINAL" + contador
							+ ";IF QTDE_DOM_FORA > 0;RUN; %MEND GERARLISTA;%GERARLISTA(CAMPO_DOMINIO = &CAMPO_DOMINIO, DOMINIOS = &DOMINIOS);");
				} else {
					log += sas.ComandoSAS("%let campo_dominio = " + coluna.getNomeColuna() + "; %let NOME_BASE = "
							+ bases.substring(1, bases.length() - 1) + "; %let dominios = "
							+ coluna.getRegras().get(0).getDetalheRegra() + "; %let first_obs = " + new BigDecimal(nobs).intValueExact()
							+ "; %MACRO GERARLISTA(CAMPO_DOMINIO, DOMINIOS); PROC DELETE DATA=BASE_DOMINIO; RUN; PROC DELETE DATA=VALORES_DOMINIOS; RUN; PROC DELETE DATA=BASE_DOMINIO_FINAL"
							+ contador + "; RUN; PROC CONTENTS DATA=" + lib
							+ ".&NOME_BASE.(keep=&CAMPO_DOMINIO.) OUT=CONTENTS (KEEP= NAME LENGTH TYPE) NOPRINT SHORT; RUN; DATA _NULL_; SET WORK.CONTENTS; CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH); CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE); RUN; %IF &TIPO1. = 1 %THEN %DO; DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.); LENGTH &CAMPO_DOMINIO. &TAMANHO1.; DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' '); &CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', '); OUTPUT; END; RUN; PROC SORT DATA=BASE_DOMINIOS; BY &CAMPO_DOMINIO.; RUN; %END; %ELSE %DO; DATA BASE_DOMINIOS (KEEP=&CAMPO_DOMINIO.); LENGTH &CAMPO_DOMINIO. $&TAMANHO1.; DO I=1 BY 1 WHILE(SCAN(&DOMINIOS,I,', ') ^=' '); &CAMPO_DOMINIO.=SCAN(&DOMINIOS,I,', '); OUTPUT; END; RUN; PROC SORT DATA=BASE_DOMINIOS; BY &CAMPO_DOMINIO.; RUN; %END; %PUT &NOME_BASE.; %PUT TAMANHO : &TAMANHO1.; DATA _NULL_; IF 0 THEN SET "
							+ lib
							+ ".&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &NOBS_BASE.; %PUT LIMITE: &LIMITE.; %IF &NOBS_BASE. > 0 %THEN %DO; %IF &NOBS_BASE. > &LIMITE. %THEN %DO; %DO I = &first_obs. %TO &NOBS_BASE. %BY &LIMITE.; %PUT COMECO: &I.; %LET FINAL = %SYSFUNC(SUM(&LIMITE. + &I.)); %PUT FINAL: &FINAL.; PROC SQL; CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM "
							+ lib
							+ ".&NOME_BASE.(FIRSTOBS=&I. OBS=&FINAL.) ORDER BY &CAMPO_DOMINIO.; QUIT; %IF &TIPO1. = 1 %THEN %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. &TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; %ELSE %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. $&TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; DATA _NULL_; IF 0 THEN SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N; CALL SYMPUTX('QTDE_DOMINIOS_FORA',N); STOP; RUN; %PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.; PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY; BY &CAMPO_DOMINIO.; RUN; DATA BASE_DOMINIO_AUX; QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.; CAMPO = \"&CAMPO_DOMINIO.\"; NOME = \"&NOME_BASE.\"; RUN; DATA DOMINIOS_ENCON; SET DOMINIOS_ENCON; RUN; PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE; PROC SORT DATA=VALORES_DOMINIOS THREADS NODUPKEY; BY &CAMPO_DOMINIO.; RUN; PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE; %END; %END; %ELSE %DO; PROC SQL; CREATE TABLE BASE_MENOR AS SELECT &CAMPO_DOMINIO. FROM "
							+ lib
							+ ".&NOME_BASE.(FIRSTOBS=&first_obs.) ORDER BY &CAMPO_DOMINIO.; QUIT; %IF &TIPO1. = 1 %THEN %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. &TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; %ELSE %DO; DATA QTDE_DOMINIOS_FORA_TOTAL; LENGTH &CAMPO_DOMINIO. $&TAMANHO1.; MERGE BASE_DOMINIOS (IN=INA) BASE_MENOR; BY &CAMPO_DOMINIO.; IF NOT INA; RUN; %END; DATA _NULL_; IF 0 THEN SET QTDE_DOMINIOS_FORA_TOTAL NOBS=N; CALL SYMPUTX('QTDE_DOMINIOS_FORA',N); STOP; RUN; %PUT QTDE_DOMINIOS_FORA : &QTDE_DOMINIOS_FORA.; PROC SORT DATA=QTDE_DOMINIOS_FORA_TOTAL (KEEP=&CAMPO_DOMINIO.) OUT=DOMINIOS_ENCON NODUPKEY; BY &CAMPO_DOMINIO.; RUN; DATA BASE_DOMINIO_AUX; QTDE_DOM_FORA = &QTDE_DOMINIOS_FORA.; CAMPO = \"&CAMPO_DOMINIO.\"; NOME = \"&NOME_BASE.\"; RUN; DATA DOMINIOS_ENCON; SET DOMINIOS_ENCON; RUN; PROC APPEND BASE=VALORES_DOMINIOS DATA=DOMINIOS_ENCON FORCE; PROC APPEND BASE=BASE_DOMINIO DATA=BASE_DOMINIO_AUX FORCE; %END; DATA _NULL_; IF 0 THEN SET VALORES_DOMINIOS NOBS=N; CALL SYMPUTX('VAL_DOMINIOS',N); STOP; RUN; %PUT VAL_DOMINIOS: &VAL_DOMINIOS.; DATA _NULL_; IF 0 THEN SET "
							+ lib
							+ ".&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE_MENOR',N); STOP; RUN; PROC SQL; CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT CAMPO, NOME, &TIPO1. AS TIPO,SUM(QTDE_DOM_FORA)/%sysfunc(sum(&NOBS_BASE. - &first_obs.)) AS QTDE_DOM_FORA_PORC,SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA,&VAL_DOMINIOS. AS VAL_DOM FROM BASE_DOMINIO; QUIT; PROC SORT DATA=BASE_DOMINIO_TOTAL NODUPKEY; BY NOME; RUN; PROC DELETE DATA=BASE_DOMINIO; RUN; DATA BASE_DOMINIO_TOTAL; SET WORK.BASE_DOMINIO_TOTAL; FORMAT QTDE_DOM_FORA_PORC PERCENT8.3; RUN; PROC APPEND BASE=BASE_DOMINIO_FINAL DATA=BASE_DOMINIO_TOTAL FORCE; %END; %ELSE %DO; DATA BASE_DOMINIO; QTDE_DOM_FORA = -1; CAMPO = \"&CAMPO_DOMINIO.\"; NOME = \"&NOME_BASE.\"; RUN; %LET VAL_DOMINIOS = 0; PROC SQL; CREATE TABLE BASE_DOMINIO_TOTAL AS SELECT CAMPO, NOME, &TIPO1. AS TIPO, SUM(QTDE_DOM_FORA)/1 AS QTDE_DOM_FORA_PORC, SUM(QTDE_DOM_FORA) AS QTDE_DOM_FORA, &VAL_DOMINIOS. AS VAL_DOM FROM BASE_DOMINIO; QUIT; PROC APPEND BASE=BASE_DOMINIO_FINAL"
							+ contador
							+ " DATA=BASE_DOMINIO_TOTAL FORCE; PROC DELETE DATA=BASE_DOMINIO; RUN; %END; PROC DELETE DATA=QTDE_DOMINIOS_FORA_TOTAL; RUN; PROC DELETE DATA=BASE_DOMINIO_TOTAL; RUN; PROC DELETE DATA=DOMINIOS_ENCON; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=CONTENTS; RUN; PROC DELETE DATA=BASE_DOMINIOS; RUN; PROC DELETE DATA=BASE_MENOR; RUN; PROC DELETE DATA=BASE_DOMINIO_AUX; RUN; PROC DELETE DATA=TESTE; RUN; data BASE_DOMINIO_FINAL"
							+ contador + "; SET WORK.BASE_DOMINIO_FINAL" + contador
							+ "; IF QTDE_DOM_FORA > 0; RUN; %MEND GERARLISTA; %GERARLISTA(CAMPO_DOMINIO = &CAMPO_DOMINIO, DOMINIOS = &DOMINIOS);");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_DOMINIO_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_DOMINIO_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");

			}

		} catch (GenericError e) {
			e.printStackTrace();
		}

		if (log.contains("\"DEU BOA\" || 1")) {
			System.out.println(log);
			tabelaDominioErros = sas.baseSAS("SELECT * FROM WORK.BASE_DOMINIO_FINAL" + contador);
		} else {
			System.out.println(log);
		}
		// System.out.println(tabelaDominioErros.toString());
		return tabelaDominioErros;
	}

	public ArrayList<ArrayList<String>> prepararDadosPSISAS(ConectorSAS sas, String lib, String bases,
			ColunaTabela coluna, int contador, double nobs) {

		if (!bases.contains("\"")) {
			bases = "\"" + bases + "\"";
		}

		int i_comeco = 1;
		int i_final = coluna.getRegras().get(0).getDetalheRegra().split(",").length - 1;

		String log = "";
		String strLib = "";
		String strQuery1 = "";
		String strQuery2 = "";
		ArrayList<ArrayList<String>> tabelaDominioErros = new ArrayList<ArrayList<String>>();

		try {
			if (coluna.getTipoColuna() == 1) {
				String faixa = coluna.getRegras().get(0).getDetalheRegra().split(",")[1].replace("\"", "");
				;
				for (int i = 2; i <= i_final; i++) {
					faixa += "," + coluna.getRegras().get(0).getDetalheRegra().split(",")[i].replace("\"", "");
				}

				log = "";
				if (lib.length() > 9) {
					log = sas.ComandoSAS("libname INTEG \"" + lib + "\";");
					log += sas.ComandoSAS(
							"ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY=INTEG MEMTYPE=DATA;RUN;DATA LISTA_BASES_PSI;SET WORK.LISTA_BASES (KEEP= NAME WHERE = (NAME CONTAINS "
									+ bases
									+ "));RUN;DATA _NULL_;SET WORK.LISTA_BASES_PSI END=LAST;IF LAST THEN DO;CALL SYMPUT('NOME_BASE',NAME);END;RUN;");
					log += sas.ComandoSAS("%LET MODELVAR=" + coluna.getNomeColuna()
							+ "; %LET SOURCEDATA1=&NOME_BASE.; %LET FAIXAS_LINHA = \"" + faixa
							+ "\"; DATA FAIXAS (Keep= MIN MAX); format MIN 12.2; format MAX 12.2; DO I=1 BY 2 WHILE(SCAN(&FAIXAS_LINHA,I,', ') ^=' '); MIN=SCAN(&FAIXAS_LINHA,I,', '); MAX=SCAN(&FAIXAS_LINHA,I + 1,', '); OUTPUT; END; RUN; DATA _NULL_; SET WORK.FAIXAS; CALL SYMPUT(COMPRESS('MIN' || _N_),MIN); CALL SYMPUT(COMPRESS('MAX' || _N_),MAX); CALL SYMPUT('QTDE_FAIXAS',_N_); RUN;%LET I_FINAL = %sysfunc(sum(&QTDE_FAIXAS.+1)); %LET I_COMECO = 0; %MACRO PSIPORCAMPO(MODELVAR, SOURCEDATA1); PROC DELETE DATA=FREQUENCIAS"
							+ contador + "; RUN; DATA WORK.PSISAMPLE2; SET INTEG.&SOURCEDATA1(KEEP=&MODELVAR Firstobs="
							+ new BigDecimal(nobs).intValueExact()
							+ ");format &MODELVAR 12.2; RUN; PROC SORT DATA=WORK.PSISAMPLE2 SORTSIZE=MAX THREADS; BY &MODELVAR; RUN; DATA _NULL_; IF 0 THEN SET WORK.PSISAMPLE2 NOBS=N; CALL SYMPUTX('QTDE_NOBS',N); STOP; RUN; %PUT QTDE_NOBS: &QTDE_NOBS.; DATA WORK.PSISAMPLE2; SET WORK.PSISAMPLE2; %DO I=&I_COMECO. %TO &I_FINAL.; %LET I_1 = %SYSFUNC(SUM(&I. + 1)); %IF &I. = &I_COMECO. %THEN %DO; IF (&MODELVAR. < &&MIN&I_1.) THEN FAIXA = &I_COMECO.; %END; %ELSE %IF &I. = &I_FINAL. %THEN %DO; %LET I_1 = %SYSFUNC(SUM(&I. - 1)); IF (&MODELVAR. > &&MAX&I_1.) THEN FAIXA = &I_FINAL.; %END; %ELSE %DO; %IF (&I. = %sysfunc(sum(&I_FINAL. - 1))) %THEN %DO; IF (&&MAX&I. >= &MODELVAR. >= &&MIN&I.) THEN FAIXA = &I.; %END; %ELSE %DO; IF (&&MAX&I. > &MODELVAR. >= &&MIN&I.) THEN FAIXA = &I.; %END; %END; %END; RUN; PROC SQL;CREATE TABLE FREQUENCIAS"
							+ contador
							+ " AS SELECT (COUNT(FAIXA)/&QTDE_NOBS.) AS PERCENT, \"&SOURCEDATA1.\" as BASE FROM PSISAMPLE2 GROUP BY FAIXA;QUIT;DATA MAX_MIN (KEEP=MAXA MINA);SET PSISAMPLE2  END=DONE;RETAIN MAXA 0;RETAIN MINA 0;MAXA = MAX(&MODELVAR.,MAXA);MINA = MIN(&MODELVAR.,MINA);IF DONE THEN OUTPUT;RUN;DATA _NULL_;IF 0 THEN SET WORK.FREQUENCIAS"
							+ contador
							+ " NOBS=N;CALL SYMPUTX('QTDE_FREQS',N);STOP;RUN;%IF &QTDE_FREQS. < &QTDE_FAIXAS. %THEN %DO;%DO i = &QTDE_FREQS. %TO %SYSFUNC(SUM(&QTDE_FAIXAS. - 1));DATA FREQUENCIAS_SOMA;PERCENT = 0;BASE = \"&SOURCEDATA1.\";RUN;PROC APPEND BASE=FREQUENCIAS"
							+ contador + " DATA="
							+ "FREQUENCIAS_SOMA FORCE;%END;%END; %MEND PSIPORCAMPO; %PSIPORCAMPO(MODELVAR = &MODELVAR., SOURCEDATA1 = &SOURCEDATA1.);proc delete data=FREQUENCIAS_SOMA;run;");
					log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
				} else {
					log += sas.ComandoSAS("ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY=" + lib
							+ " MEMTYPE=DATA;RUN;DATA LISTA_BASES_PSI;SET WORK.LISTA_BASES (KEEP= NAME WHERE = (NAME CONTAINS "
							+ bases
							+ "));RUN;DATA _NULL_;SET WORK.LISTA_BASES_PSI END=LAST;IF LAST THEN DO;CALL SYMPUT('NOME_BASE',NAME);END;RUN;");
					log += sas.ComandoSAS("%LET MODELVAR=" + coluna.getNomeColuna()
							+ "; %LET SOURCEDATA1=&NOME_BASE.; %LET FAIXAS_LINHA = \"" + faixa
							+ "\"; DATA FAIXAS (Keep= MIN MAX); format MIN 12.2; format MAX 12.2; DO I=1 BY 2 WHILE(SCAN(&FAIXAS_LINHA,I,', ') ^=' '); MIN=SCAN(&FAIXAS_LINHA,I,', '); MAX=SCAN(&FAIXAS_LINHA,I + 1,', '); OUTPUT; END; RUN; DATA _NULL_; SET WORK.FAIXAS; CALL SYMPUT(COMPRESS('MIN' || _N_),MIN); CALL SYMPUT(COMPRESS('MAX' || _N_),MAX); CALL SYMPUT('QTDE_FAIXAS',_N_); RUN;%LET I_FINAL = %sysfunc(sum(&QTDE_FAIXAS.+1)); %LET I_COMECO = 0; %MACRO PSIPORCAMPO(MODELVAR, SOURCEDATA1); PROC DELETE DATA=FREQUENCIAS"
							+ contador + "; RUN; DATA WORK.PSISAMPLE2; SET " + lib
							+ ".&SOURCEDATA1(KEEP=&MODELVAR Firstobs=" + new BigDecimal(nobs).intValueExact()
							+ ");format &MODELVAR 12.2; RUN; PROC SORT DATA=WORK.PSISAMPLE2 SORTSIZE=MAX THREADS; BY &MODELVAR; RUN; DATA _NULL_; IF 0 THEN SET WORK.PSISAMPLE2 NOBS=N; CALL SYMPUTX('QTDE_NOBS',N); STOP; RUN; %PUT QTDE_NOBS: &QTDE_NOBS.; DATA WORK.PSISAMPLE2; SET WORK.PSISAMPLE2; %DO I=&I_COMECO. %TO &I_FINAL.; %LET I_1 = %SYSFUNC(SUM(&I. + 1)); %IF &I. = &I_COMECO. %THEN %DO; IF (&MODELVAR. < &&MIN&I_1.) THEN FAIXA = &I_COMECO.; %END; %ELSE %IF &I. = &I_FINAL. %THEN %DO; %LET I_1 = %SYSFUNC(SUM(&I. - 1)); IF (&MODELVAR. > &&MAX&I_1.) THEN FAIXA = &I_FINAL.; %END; %ELSE %DO; %IF (&I. = %sysfunc(sum(&I_FINAL. - 1))) %THEN %DO; IF (&&MAX&I. >= &MODELVAR. >= &&MIN&I.) THEN FAIXA = &I.; %END; %ELSE %DO; IF (&&MAX&I. > &MODELVAR. >= &&MIN&I.) THEN FAIXA = &I.; %END; %END; %END; RUN; PROC SQL;CREATE TABLE FREQUENCIAS"
							+ contador
							+ " AS SELECT (COUNT(FAIXA)/&QTDE_NOBS.) AS PERCENT, \"&SOURCEDATA1.\" as BASE FROM PSISAMPLE2 GROUP BY FAIXA;QUIT;DATA MAX_MIN (KEEP=MAXA MINA);SET PSISAMPLE2  END=DONE;RETAIN MAXA 0;RETAIN MINA 0;MAXA = MAX(&MODELVAR.,MAXA);MINA = MIN(&MODELVAR.,MINA);IF DONE THEN OUTPUT;RUN;DATA _NULL_;IF 0 THEN SET WORK.FREQUENCIAS"
							+ contador
							+ " NOBS=N;CALL SYMPUTX('QTDE_FREQS',N);STOP;RUN;%IF &QTDE_FREQS. < &QTDE_FAIXAS. %THEN %DO;%DO i = &QTDE_FREQS. %TO %SYSFUNC(SUM(&QTDE_FAIXAS. - 1));DATA FREQUENCIAS_SOMA;PERCENT = 0;BASE = \"&SOURCEDATA1.\";RUN;PROC APPEND BASE=FREQUENCIAS"
							+ contador + " DATA="
							+ "FREQUENCIAS_SOMA FORCE;%END;%END; %MEND PSIPORCAMPO; %PSIPORCAMPO(MODELVAR = &MODELVAR., SOURCEDATA1 = &SOURCEDATA1.);proc delete data=FREQUENCIAS_SOMA;run;");
					log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");

				}

			} else {
				String faixa = coluna.getRegras().get(0).getDetalheRegra().split(",")[1].replace("\"", "");
				;
				for (int i = 2; i <= i_final; i++) {
					faixa += "," + coluna.getRegras().get(0).getDetalheRegra().split(",")[i].replace("\"", "");
				}
				log = "";
				if (lib.length() > 9) {
					log = sas.ComandoSAS("libname INTEG \"" + lib + "\";");
					log += sas.ComandoSAS(
							"ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY=INTEG MEMTYPE=DATA;RUN;DATA LISTA_BASES_PSI;SET WORK.LISTA_BASES (KEEP= NAME WHERE = (NAME CONTAINS "
									+ bases
									+ "));RUN;DATA _NULL_;SET WORK.LISTA_BASES_PSI END=LAST;IF LAST THEN DO;CALL SYMPUT('NOME_BASE',NAME);END;RUN;");
					log += sas.ComandoSAS("%LET MODELVAR=" + coluna.getNomeColuna()
							+ "; %LET SOURCEDATA1=&NOME_BASE.; %LET FAIXAS_LINHA = \"" + faixa
							+ "\"; DATA FAIXAS (Keep= VALOR);format VALOR $50.;DO I=1 BY 1 WHILE(SCAN(&FAIXAS_LINHA,I,', ') ^=' ');VALOR=SCAN(&FAIXAS_LINHA,I,', ');OUTPUT;END;RUN; DATA _NULL_; SET WORK.FAIXAS; CALL SYMPUT(COMPRESS('VALOR' || _N_),VALOR); CALL SYMPUT('QTDE_FAIXAS',_N_); RUN; %MACRO PSIPORCAMPO(MODELVAR, SOURCEDATA1); PROC DELETE DATA=FREQUENCIAS"
							+ contador + "; RUN; DATA WORK.PSISAMPLE2; SET INTEG.&SOURCEDATA1(KEEP=&MODELVAR Firstobs="
							+ new BigDecimal(nobs).intValueExact()
							+ "); RUN; PROC SORT DATA=WORK.PSISAMPLE2 SORTSIZE=MAX THREADS; BY &MODELVAR; RUN; DATA _NULL_; IF 0 THEN SET WORK.PSISAMPLE2 NOBS=N; CALL SYMPUTX('QTDE_NOBS',N); STOP; RUN; %PUT QTDE_NOBS: &QTDE_NOBS.; DATA WORK.PSISAMPLE2;SET WORK.PSISAMPLE2;%DO I=1 %TO &QTDE_FAIXAS.;IF (&MODELVAR. EQ \"&&VALOR&I.\") THEN DO;FAIXA = &I.;END;%END;RUN;PROC SQL;CREATE TABLE FREQUENCIAS"
							+ contador
							+ " AS SELECT (COUNT(FAIXA)/&QTDE_NOBS.) AS PERCENT, \"&SOURCEDATA1.\" as BASE FROM PSISAMPLE2 GROUP BY FAIXA;QUIT;DATA QTDE_VALORES_FORA_TOTAL;MERGE FAIXAS (IN=INA) PSISAMPLE2(RENAME=(&MODELVAR. = VALOR));BY VALOR;IF NOT INA;RUN;PROC SQL;CREATE TABLE VALORES_FORA AS SELECT DISTINCT VALOR FROM QTDE_VALORES_FORA_TOTAL QUIT;DATA _NULL_;IF 0 THEN SET WORK.FREQUENCIAS"
							+ contador
							+ " NOBS=N;CALL SYMPUTX('QTDE_FREQS',N);STOP;RUN;%IF &QTDE_FREQS. < &QTDE_FAIXAS. %THEN %DO;%DO i = &QTDE_FREQS. %TO %SYSFUNC(SUM(&QTDE_FAIXAS. - 1));DATA FREQUENCIAS_SOMA;PERCENT = 0;BASE = \"&SOURCEDATA1.\";RUN;PROC APPEND BASE=FREQUENCIAS"
							+ contador
							+ " DATA=FREQUENCIAS_SOMA FORCE;%END;%END;%MEND PSIPORCAMPO; %PSIPORCAMPO(MODELVAR = &MODELVAR., SOURCEDATA1 = &SOURCEDATA1.);proc delete data=FREQUENCIAS_SOMA;run;");
					log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
				} else {
					log += sas.ComandoSAS("ODS OUTPUT MEMBERS=LISTA_BASES;PROC DATASETS LIBRARY=" + lib
							+ " MEMTYPE=DATA;RUN;DATA LISTA_BASES_PSI;SET WORK.LISTA_BASES (KEEP= NAME WHERE = (NAME CONTAINS "
							+ bases
							+ "));RUN;DATA _NULL_;SET WORK.LISTA_BASES_PSI END=LAST;IF LAST THEN DO;CALL SYMPUT('NOME_BASE',NAME);END;RUN;");
					log += sas.ComandoSAS("%LET MODELVAR=" + coluna.getNomeColuna()
							+ "; %LET SOURCEDATA1=&NOME_BASE.; %LET FAIXAS_LINHA = \"" + faixa
							+ "\"; DATA FAIXAS (Keep= VALOR);format VALOR $50.;DO I=1 BY 1 WHILE(SCAN(&FAIXAS_LINHA,I,', ') ^=' ');VALOR=SCAN(&FAIXAS_LINHA,I,', ');OUTPUT;END;RUN; DATA _NULL_; SET WORK.FAIXAS; CALL SYMPUT(COMPRESS('VALOR' || _N_),VALOR); CALL SYMPUT('QTDE_FAIXAS',_N_); RUN; %MACRO PSIPORCAMPO(MODELVAR, SOURCEDATA1); PROC DELETE DATA=FREQUENCIAS"
							+ contador + "; RUN; DATA WORK.PSISAMPLE2; SET " + lib
							+ ".&SOURCEDATA1(KEEP=&MODELVAR Firstobs=" + new BigDecimal(nobs).intValueExact()
							+ "); RUN; PROC SORT DATA=WORK.PSISAMPLE2 SORTSIZE=MAX THREADS; BY &MODELVAR; RUN; DATA _NULL_; IF 0 THEN SET WORK.PSISAMPLE2 NOBS=N; CALL SYMPUTX('QTDE_NOBS',N); STOP; RUN; %PUT QTDE_NOBS: &QTDE_NOBS.; DATA WORK.PSISAMPLE2;SET WORK.PSISAMPLE2;%DO I=1 %TO &QTDE_FAIXAS.;IF (&MODELVAR. EQ \"&&VALOR&I.\") THEN DO;FAIXA = &I.;END;%END;RUN;PROC SQL;CREATE TABLE FREQUENCIAS"
							+ contador
							+ " AS SELECT (COUNT(FAIXA)/&QTDE_NOBS.) AS PERCENT, \"&SOURCEDATA1.\" as BASE FROM PSISAMPLE2 GROUP BY FAIXA;QUIT;DATA QTDE_VALORES_FORA_TOTAL;MERGE FAIXAS (IN=INA) PSISAMPLE2(RENAME=(&MODELVAR. = VALOR));BY VALOR;IF NOT INA;RUN;PROC SQL;CREATE TABLE VALORES_FORA AS SELECT DISTINCT VALOR FROM QTDE_VALORES_FORA_TOTAL QUIT;DATA _NULL_;IF 0 THEN SET WORK.FREQUENCIAS"
							+ contador
							+ " NOBS=N;CALL SYMPUTX('QTDE_FREQS',N);STOP;RUN;%IF &QTDE_FREQS. < &QTDE_FAIXAS. %THEN %DO;%DO i = &QTDE_FREQS. %TO %SYSFUNC(SUM(&QTDE_FAIXAS. - 1));DATA FREQUENCIAS_SOMA;PERCENT = 0;BASE = \"&SOURCEDATA1.\";RUN;PROC APPEND BASE=FREQUENCIAS"
							+ contador
							+ " DATA=FREQUENCIAS_SOMA FORCE;%END;%END;%MEND PSIPORCAMPO; %PSIPORCAMPO(MODELVAR = &MODELVAR., SOURCEDATA1 = &SOURCEDATA1.);proc delete data=FREQUENCIAS_SOMA;run;");
					log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.FREQUENCIAS" + contador
							+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");

				}
			}
		} catch (GenericError e) {
			e.printStackTrace();
		}

		if (log.contains("\"DEU BOA\" || 1")) {
			System.out.println(log);
			tabelaDominioErros = sas.baseSAS("SELECT * FROM WORK.FREQUENCIAS" + contador);

		}
		System.out.println(log);
		// System.out.println(tabelaDominioErros.toString());
		return tabelaDominioErros;
	}

	private ArrayList<ArrayList<String>> prepararDadosDuplicidadeSAS(ConectorSAS sas, String lib, String bases,
			String camposDuplicidade, Base base, int contador) {
		String log = "";
		String strLib = "";
		String strQuery1 = "";
		String strQuery2 = "";

		if (!bases.contains("\"")) {
			bases = "\"" + bases + "\"";
		}

		try {
			if (lib.length() > 9) {
				log = sas.ComandoSAS("libname INTEG " + lib + ";");
				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS("%LET CAMPOS=" + camposDuplicidade
							+ "; %LET CAMPO_CHAVE = %sysfunc(tranwrd(%quote(&CAMPOS),%str(, ),%str())); %PUT CAMPO_CHAVE = &CAMPO_CHAVE.; ODS OUTPUT MEMBERS=LISTA_BASES; PROC DATASETS LIBRARY=INTEG MEMTYPE=DATA; RUN; DATA LISTA_BASES_DUPLICIDADE"
							+ contador + "; SET WORK.LISTA_BASES (KEEP= NAME WHERE = (NAME IN (" + bases
							+ "))); RUN; DATA _NULL_; SET WORK.LISTA_BASES_DUPLICIDADE" + contador
							+ "; CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME); CALL SYMPUT('NOBS_OBS',_N_); RUN; DATA LISTA_BASES_DUPLICIDADE"
							+ contador + "; SET WORK.LISTA_BASES_DUPLICIDADE" + contador
							+ "; COUNT + 1; RUN; %PUT NOBS_OBS: &NOBS_OBS.;");
					log += sas.ComandoSAS(
							"%MACRO GERARLISTA(); PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_FINAL"
									+ contador
									+ "; RUN; %DO J=1 %TO &NOBS_OBS.; %PUT &&NOME_BASE&J.; DATA _NULL_; IF 0 THEN SET INTEG.&&NOME_BASE&J. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &NOBS_BASE.; PROC SORT DATA=INTEG.&&NOME_BASE&J. (KEEP= &CAMPO_CHAVE.) OUT=DUPLICIDADE SORTSIZE=MAX NOUNIKEYS THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP',N); STOP; RUN; %PUT NOBS_DUP: &NOBS_DUP.; %IF &NOBS_DUP. NE 0 %THEN %DO; PROC SORT DATA=DUPLICIDADE SORTSIZE=MAX NODUPKEY THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP_2',N); STOP; RUN; %PUT NOBS_DUP_2: &NOBS_DUP_2.; %END; %ELSE %DO; %LET NOBS_DUP_2 = 0; %END; DATA BASE_DUPLICIDADE_AUX; QTDE_DUP = &NOBS_DUP.; QTDE_INF_DUP = &NOBS_DUP_2.; NOME = \"&&NOME_BASE&J.\" ; CAMPO = \"&CAMPO_CHAVE.\" ; RUN; PROC APPEND BASE=BASE_DUPLICIDADE DATA=BASE_DUPLICIDADE_AUX FORCE; PROC SQL; CREATE TABLE BASE_DUPLICIDADE_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_DUP)/&NOBS_BASE. AS QTDE_DUP_PORC, SUM(QTDE_DUP) AS QTDE_DUP_FORA, SUM(QTDE_INF_DUP) AS QTDE_INF_DUP_FORA, &J. AS ID FROM BASE_DUPLICIDADE; QUIT; DATA BASE_DUPLICIDADE_TOTAL; SET WORK.BASE_DUPLICIDADE_TOTAL; FORMAT QTDE_DUP_PORC PERCENT8.3; RUN; PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC APPEND BASE=BASE_DUPLICIDADE_FINAL"
									+ contador + " DATA=BASE_DUPLICIDADE_TOTAL FORCE; %END; DATA BASE_DUPLICIDADE_FINAL"
									+ contador + "; SET WORK.BASE_DUPLICIDADE_FINAL" + contador
									+ "; IF QTDE_DUP_FORA > 0; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_AUX; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_TOTAL; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=DUPLICIDADE; RUN; %MEND GERARLISTA; %GERARLISTA;");
				} else {
					log += sas.ComandoSAS("%LET CAMPOS=" + camposDuplicidade
							+ ";%LET CAMPO_CHAVE = %sysfunc(tranwrd(%quote(&CAMPOS),%str(, ),%str())); %PUT CAMPO_CHAVE = &CAMPO_CHAVE.;%let NOME_BASE ="
							+ bases.substring(1, bases.length() - 1)
							+ ";%MACRO GERARLISTA(); PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_FINAL"
							+ contador
							+ "; RUN; %PUT &NOME_BASE.; DATA _NULL_; IF 0 THEN SET INTEG.&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &NOBS_BASE.; PROC SORT DATA=INTEG.&NOME_BASE. (KEEP= &CAMPO_CHAVE.) OUT=DUPLICIDADE SORTSIZE=MAX NOUNIKEYS THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP',N); STOP; RUN; %PUT NOBS_DUP: &NOBS_DUP.; %IF &NOBS_DUP. NE 0 %THEN %DO; PROC SORT DATA=DUPLICIDADE SORTSIZE=MAX NODUPKEY THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP_2',N); STOP; RUN; %PUT NOBS_DUP_2: &NOBS_DUP_2.; %END; %ELSE %DO; %LET NOBS_DUP_2 = 0; %END; DATA BASE_DUPLICIDADE_AUX; QTDE_DUP = &NOBS_DUP.; QTDE_INF_DUP = &NOBS_DUP_2.; NOME = &NOME_BASE. ; CAMPO = \"&CAMPO_CHAVE.\" ; RUN; PROC APPEND BASE=BASE_DUPLICIDADE DATA=BASE_DUPLICIDADE_AUX FORCE; PROC SQL; CREATE TABLE BASE_DUPLICIDADE_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_DUP)/&NOBS_BASE. AS QTDE_DUP_PORC, SUM(QTDE_DUP) AS QTDE_DUP_FORA, SUM(QTDE_INF_DUP) AS QTDE_INF_DUP_FORA FROM BASE_DUPLICIDADE; QUIT; DATA BASE_DUPLICIDADE_TOTAL; SET WORK.BASE_DUPLICIDADE_TOTAL; FORMAT QTDE_DUP_PORC PERCENT8.3; RUN; PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC APPEND BASE=BASE_DUPLICIDADE_FINAL"
							+ contador + " DATA=BASE_DUPLICIDADE_TOTAL FORCE; DATA BASE_DUPLICIDADE_FINAL" + contador
							+ "; SET WORK.BASE_DUPLICIDADE_FINAL" + contador
							+ "; IF QTDE_DUP_FORA > 0; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_AUX; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_TOTAL; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=DUPLICIDADE; RUN; %MEND GERARLISTA; %GERARLISTA;");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_DUPLICIDADE_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_DUPLICIDADE_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
			} else {
				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS("%LET CAMPOS=" + camposDuplicidade
							+ "; %LET CAMPO_CHAVE = %sysfunc(tranwrd(%quote(&CAMPOS),%str(, ),%str())); %PUT CAMPO_CHAVE = &CAMPO_CHAVE.; ODS OUTPUT MEMBERS=LISTA_BASES; PROC DATASETS LIBRARY="
							+ lib
							+ " MEMTYPE=DATA; RUN; DATA LISTA_BASES_DUPLICIDADE; SET WORK.LISTA_BASES (KEEP= NAME WHERE = (NAME IN ("
							+ bases
							+ "))); RUN; DATA _NULL_; SET WORK.LISTA_BASES_DUPLICIDADE; CALL SYMPUT(COMPRESS('NOME_BASE' || _N_),NAME); CALL SYMPUT('NOBS_OBS',_N_); RUN; DATA LISTA_BASES_DUPLICIDADE; SET WORK.LISTA_BASES_DUPLICIDADE; COUNT + 1; RUN; %PUT NOBS_OBS: &NOBS_OBS.;");
					log += sas.ComandoSAS(
							"%MACRO GERARLISTA(); PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_FINAL"
									+ contador
									+ "; RUN; %DO J=1 %TO &NOBS_OBS.; %PUT &&NOME_BASE&J.; DATA _NULL_; IF 0 THEN SET "
									+ lib
									+ ".&&NOME_BASE&J. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &&NOME_BASE&J.; PROC SORT DATA="
									+ lib
									+ ".&&NOME_BASE&J. (KEEP= &CAMPO_CHAVE.) OUT=DUPLICIDADE SORTSIZE=MAX NOUNIKEYS THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP',N); STOP; RUN; %PUT NOBS_DUP: &NOBS_DUP.; %IF &NOBS_DUP. NE 0 %THEN %DO; PROC SORT DATA=DUPLICIDADE SORTSIZE=MAX NODUPKEY THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP_2',N); STOP; RUN; %PUT NOBS_DUP_2: &NOBS_DUP_2.; %END; %ELSE %DO; %LET NOBS_DUP_2 = 0; %END; DATA BASE_DUPLICIDADE_AUX; QTDE_DUP = &NOBS_DUP.; QTDE_INF_DUP = &NOBS_DUP_2.; NOME = \"&&NOME_BASE&J. \" ; CAMPO = \"&CAMPO_CHAVE.\" ; RUN; PROC APPEND BASE=BASE_DUPLICIDADE DATA=BASE_DUPLICIDADE_AUX FORCE; PROC SQL; CREATE TABLE BASE_DUPLICIDADE_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_DUP)/&NOBS_BASE. AS QTDE_DUP_PORC, SUM(QTDE_DUP) AS QTDE_DUP_FORA, SUM(QTDE_INF_DUP) AS QTDE_INF_DUP_FORA, &J. AS ID FROM BASE_DUPLICIDADE; QUIT; DATA BASE_DUPLICIDADE_TOTAL; SET WORK.BASE_DUPLICIDADE_TOTAL; FORMAT QTDE_DUP_PORC PERCENT8.3; RUN; PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC APPEND BASE=BASE_DUPLICIDADE_FINAL"
									+ contador + " DATA=BASE_DUPLICIDADE_TOTAL FORCE; DATA BASE_DUPLICIDADE_FINAL"
									+ contador + "; SET WORK.BASE_DUPLICIDADE_FINAL" + contador
									+ "; IF QTDE_DUP_FORA > 0; RUN;%END; PROC DELETE DATA=BASE_DUPLICIDADE_AUX; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_TOTAL; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=DUPLICIDADE; RUN; %MEND GERARLISTA; %GERARLISTA;");
				} else {
					log += sas.ComandoSAS("%LET CAMPOS=" + camposDuplicidade
							+ ";%LET CAMPO_CHAVE = %sysfunc(tranwrd(%quote(&CAMPOS),%str(, ),%str())); %PUT CAMPO_CHAVE = &CAMPO_CHAVE.;%let NOME_BASE ="
							+ bases.substring(1, bases.length() - 1)
							+ ";%MACRO GERARLISTA(); PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_FINAL"
							+ contador + "; RUN; %PUT &NOME_BASE.; DATA _NULL_; IF 0 THEN SET " + lib
							+ ".&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &NOBS_BASE.; PROC SORT DATA="
							+ lib
							+ ".&NOME_BASE. (KEEP= &CAMPO_CHAVE.) OUT=DUPLICIDADE SORTSIZE=MAX NOUNIKEYS THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP',N); STOP; RUN; %PUT NOBS_DUP: &NOBS_DUP.; %IF &NOBS_DUP. NE 0 %THEN %DO; PROC SORT DATA=DUPLICIDADE SORTSIZE=MAX NODUPKEY THREADS NOEQUALS; BY &CAMPO_CHAVE.; RUN; DATA _NULL_; IF 0 THEN SET WORK.DUPLICIDADE NOBS=N; CALL SYMPUTX('NOBS_DUP_2',N); STOP; RUN; %PUT NOBS_DUP_2: &NOBS_DUP_2.; %END; %ELSE %DO; %LET NOBS_DUP_2 = 0; %END; DATA BASE_DUPLICIDADE_AUX; QTDE_DUP = &NOBS_DUP.; QTDE_INF_DUP = &NOBS_DUP_2.; NOME = &NOME_BASE. ; CAMPO = \"&CAMPO_CHAVE.\" ; RUN; PROC APPEND BASE=BASE_DUPLICIDADE DATA=BASE_DUPLICIDADE_AUX FORCE; PROC SQL; CREATE TABLE BASE_DUPLICIDADE_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_DUP)/&NOBS_BASE. AS QTDE_DUP_PORC, SUM(QTDE_DUP) AS QTDE_DUP_FORA, SUM(QTDE_INF_DUP) AS QTDE_INF_DUP_FORA FROM BASE_DUPLICIDADE; QUIT; DATA BASE_DUPLICIDADE_TOTAL; SET WORK.BASE_DUPLICIDADE_TOTAL; FORMAT QTDE_DUP_PORC PERCENT8.3; RUN; PROC DELETE DATA=BASE_DUPLICIDADE; RUN; PROC APPEND BASE=BASE_DUPLICIDADE_FINAL"
							+ contador + " DATA=BASE_DUPLICIDADE_TOTAL FORCE; DATA BASE_DUPLICIDADE_FINAL" + contador
							+ "; SET WORK.BASE_DUPLICIDADE_FINAL" + contador
							+ "; IF QTDE_DUP_FORA > 0; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_AUX; RUN; PROC DELETE DATA=BASE_DUPLICIDADE_TOTAL; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=DUPLICIDADE; RUN; %MEND GERARLISTA; %GERARLISTA;");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_DUPLICIDADE_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_DUPLICIDADE_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");

			}

			System.out.println(log);

			if (log.contains("\"DEU BOA\"")) {
				System.out.println(log);
			}

		} catch (GenericError e) {
			e.printStackTrace();
		}

		System.out.println(log);

		ArrayList<ArrayList<String>> tabelaDuplicidadeErros = new ArrayList<ArrayList<String>>();
		if (log.contains("\"DEU BOA\" || 1")) {
			tabelaDuplicidadeErros = sas.baseSAS("SELECT * FROM WORK.BASE_DUPLICIDADE_FINAL" + contador);
		}
		System.out.println(log);
		return tabelaDuplicidadeErros;
	}

	private ArrayList<ArrayList<String>> prepararDadosMissingSAS(ConectorSAS sas, String lib, String bases,
			String nomeCampo, Base base, int contador, double nobs) {
		String log = "";
		String strLib = "";
		String strQuery1 = "";
		String strQuery2 = "";
		ArrayList<ArrayList<String>> tabelaMissingErros = new ArrayList<ArrayList<String>>();

		if (!bases.contains("\"")) {
			bases = "\"" + bases + "\"";
		}

		try {
			if (lib.length() > 9) {
				log = sas.ComandoSAS("libname INTEG " + lib + ";");
				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS(
							"%let limite = 5000000;ods output Members=Lista_Bases;proc datasets library=INTEG memtype=data;run;data Lista_Bases_Missing;SET work.Lista_Bases (keep= Name WHERE = (NAME in ("
									+ bases
									+ ")));RUN;DATA _NULL_;SET WORK.Lista_Bases_Missing;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;DATA Lista_Bases_Missing;SET work.Lista_Bases_Missing;count + 1;RUN;%PUT NOBS_OBS: &NOBS_OBS.;");
					log += sas.ComandoSAS("%let campo_missing = " + nomeCampo
							+ ";%MACRO GERARLISTA(CAMPO_MISSING);PROC DELETE DATA=BASE_MISSING;RUN;%IF %SYSFUNC(EXIST(WORK.BASE_MISSING_FINAL"
							+ contador + ")) %THEN	%DO;DATA _NULL_;IF 0 THEN SET WORK.BASE_MISSING_FINAL" + contador
							+ " NOBS=N;	CALL SYMPUTX('NOBS_BASE_FINAL',N);	STOP;	RUN;%PUT &&NOBS_BASE_FINAL.;	%IF &NOBS_BASE_FINAL. > 0 %THEN	%DO;DATA BASE_MISSING_FINAL"
							+ contador + ";	SET WORK.BASE_MISSING_FINAL" + contador
							+ ";IF ID > 1000000;RUN;%END;	%END; %DO J=1 %TO &NOBS_OBS.;	%PUT &&NOME_BASE&J.;PROC CONTENTS DATA= INTEG.&&NOME_BASE&J.(keep= &CAMPO_MISSING) OUT= NAME_TYPE (KEEP= NAME TYPE) SHORT NOPRINT;	RUN;DATA _NULL_;SET WORK.NAME_TYPE;	CALL SYMPUT(COMPRESS('TIPO_CAMPO' || _N_),TYPE);	RUN;%PUT TIPO_CAMPO: &TIPO_CAMPO1.;DATA _NULL_;		IF 0 THEN	SET INTEG.&&NOME_BASE&J. NOBS=N;CALL SYMPUTX('NOBS_BASE',N);STOP;	RUN;%PUT NOBS_BASE: &NOBS_BASE.;	%PUT LIMITE: &LIMITE.;%IF &NOBS_BASE. > 0 %THEN	%DO;%IF &NOBS_BASE. > &LIMITE. %THEN %DO;%DO I = 1 %TO &NOBS_BASE. %BY &LIMITE.;%PUT COMECO: &I.;%LET FINAL =  %SYSFUNC(SUM(&LIMITE. + &I. - 1));%PUT FINAL: &FINAL.;%IF &TIPO_CAMPO1. = 1 %THEN %DO;DATA BASE_MENOR;SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.);IF &CAMPO_MISSING= .;		RUN;%END;	%ELSE	%DO;DATA BASE_MENOR;SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.);IF &CAMPO_MISSING= \"\";RUN;%END;DATA _NULL_;IF 0 THEN SET WORK.BASE_MENOR NOBS=N;	CALL SYMPUTX('NOBS_MIS',N);	STOP;RUN;%PUT NOBS_MIS: &NOBS_MIS.;	DATA BASE_MISSING_AUX;CAMPO = \"&CAMPO_MISSING.\";NOME = \"&&NOME_BASE&J.\";QTDE_MIS = &NOBS_MIS.;RUN;PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE;%END;%END;%ELSE %DO;%IF &TIPO_CAMPO1. = 1 %THEN	%DO;DATA BASE_MENOR;SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_MISSING);	IF &CAMPO_MISSING= .;RUN;%END;%ELSE %DO;DATA BASE_MENOR;SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_MISSING);	IF &CAMPO_MISSING= \"\";RUN;%END;DATA _NULL_;IF 0 THEN	SET WORK.BASE_MENOR NOBS=N;	CALL SYMPUTX('NOBS_MIS',N);	STOP;RUN;%PUT NOBS_MIS: &NOBS_MIS.;DATA BASE_MISSING_AUX;CAMPO = \"&CAMPO_MISSING.\";NOME = \"&&NOME_BASE&J.\";	QTDE_MIS = &NOBS_MIS.;	RUN;PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE;	%END;PROC SQL;CREATE TABLE BASE_MISSING_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_MIS)/&NOBS_BASE. AS QTDE_MIS_PORC, SUM(QTDE_MIS) AS QTDE_MIS, &J. AS ID FROM BASE_MISSING;	QUIT;PROC SORT DATA=BASE_MISSING_TOTAL NODUPKEY;BY NOME;RUN;DATA BASE_MISSING_TOTAL;SET WORK.BASE_MISSING_TOTAL;FORMAT QTDE_MIS_PORC PERCENT8.3;RUN;PROC DELETE DATA=BASE_MISSING;RUN;PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE;	%END;	%ELSE %DO;DATA BASE_MISSING;	QTDE_MIS = -1;CAMPO = \"&CAMPO_MISSING.\";NOME = \"&&NOME_BASE&J.\";RUN;%END;PROC SQL;CREATE TABLE BASE_MISSING_TOTAL AS SELECT NOME, CAMPO, 	SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC, SUM(QTDE_MIS) AS QTDE_MIS, &J. AS ID FROM BASE_MISSING;	QUIT;PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE;		PROC DELETE DATA=BASE_MISSING;	RUN;	%END;PROC DELETE DATA=BASE_MISSING_AUX;RUN;PROC DELETE DATA=BASE_MISSING_TOTAL;RUN;PROC DELETE DATA=LISTA_BASES;RUN;PROC DELETE DATA=NAME_TYPE;RUN;PROC DELETE DATA=BASE_MENOR; RUN; DATA BASE_MISSING_FINAL"
							+ contador + "; SET WORK.BASE_MISSING_FINAL" + contador
							+ ";IF QTDE_MIS > 0;RUN;PROC SORT DATA=BASE_MISSING_FINAL" + contador
							+ " OUT=BASE_MISSING_FINAL" + contador
							+ " NODUPKEY; BY NOME;RUN; %MEND GERARLISTA;%GERARLISTA(CAMPO_MISSING = &CAMPO_MISSING);");
				} else {
					log += sas.ComandoSAS("%let campo_missing = " + nomeCampo
							+ "; %let limite = 5000000; %let first_obs = " + new BigDecimal(nobs + 1).intValueExact() + "; %let NOME_BASE = "
							+ bases.substring(1, bases.length() - 1)
							+ "; %MACRO GERARLISTA(CAMPO_MISSING); PROC DELETE DATA=BASE_MISSING_FINAL" + contador
							+ "; RUN; PROC CONTENTS DATA= INTEG.&NOME_BASE.(keep=&CAMPO_MISSING) OUT= NAME_TYPE (KEEP= NAME TYPE) SHORT NOPRINT; RUN; DATA _NULL_; SET WORK.NAME_TYPE; CALL SYMPUT(COMPRESS('TIPO_CAMPO' || _N_),TYPE); RUN; %PUT TIPO_CAMPO: &TIPO_CAMPO1.; DATA _NULL_; IF 0 THEN SET INTEG.&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &NOBS_BASE.; %PUT LIMITE: &LIMITE.; %IF &NOBS_BASE. > 0 %THEN %DO; %IF &first_obs. > &LIMITE. %THEN %DO; %DO I = &first_obs. %TO &NOBS_BASE. %BY &LIMITE.; %PUT COMECO: &I.; %LET FINAL = %SYSFUNC(SUM(&LIMITE. + &I.)); %PUT FINAL: &FINAL.; %IF &TIPO_CAMPO1. = 1 %THEN %DO; DATA BASE_MENOR; SET INTEG.&NOME_BASE.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.); IF &CAMPO_MISSING= .; RUN; %END; %ELSE %DO; DATA BASE_MENOR; SET INTEG.&NOME_BASE.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.); IF &CAMPO_MISSING= \"\"; RUN; %END; DATA _NULL_; IF 0 THEN SET WORK.BASE_MENOR NOBS=N; CALL SYMPUTX('NOBS_MIS',N); STOP; RUN; %PUT NOBS_MIS: &NOBS_MIS.; DATA BASE_MISSING_AUX; CAMPO = \"&CAMPO_MISSING.\"; NOME = \"&NOME_BASE.\"; QTDE_MIS = &NOBS_MIS.; RUN; PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE; %END; %END; %ELSE %DO; %IF &TIPO_CAMPO1. = 1 %THEN %DO; DATA BASE_MENOR; SET INTEG.&NOME_BASE.(KEEP= &CAMPO_MISSING firstobs=&first_obs.); IF &CAMPO_MISSING= .; RUN; %END; %ELSE %DO; DATA BASE_MENOR; SET INTEG.&NOME_BASE.(KEEP= &CAMPO_MISSING firstobs=&first_obs.); IF &CAMPO_MISSING= \"\"; RUN; %END; DATA _NULL_; IF 0 THEN SET WORK.BASE_MENOR NOBS=N; CALL SYMPUTX('NOBS_MIS',N); STOP; RUN; %PUT NOBS_MIS: &NOBS_MIS.; DATA BASE_MISSING_AUX; CAMPO = \"&CAMPO_MISSING.\"; NOME = \"&NOME_BASE.\"; QTDE_MIS = &NOBS_MIS.; RUN; PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE; %END; PROC SQL; CREATE TABLE BASE_MISSING_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_MIS)/&NOBS_BASE. AS QTDE_MIS_PORC, SUM(QTDE_MIS) AS QTDE_MIS FROM BASE_MISSING; QUIT; DATA BASE_MISSING_TOTAL; SET WORK.BASE_MISSING_TOTAL; FORMAT QTDE_MIS_PORC PERCENT8.3; RUN; PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE; %END; %ELSE %DO; DATA BASE_MISSING; QTDE_MIS = -1; CAMPO = \"&CAMPO_MISSING.\"; NOME = \"&NOME_BASE.\"; RUN; %END; PROC SQL; CREATE TABLE BASE_MISSING_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC, SUM(QTDE_MIS) AS QTDE_MIS FROM BASE_MISSING; QUIT; PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE; PROC DELETE DATA=BASE_MISSING; RUN; PROC DELETE DATA=BASE_MISSING_AUX; RUN; PROC DELETE DATA=BASE_MISSING_TOTAL; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=NAME_TYPE; RUN; PROC DELETE DATA=BASE_MENOR; RUN; data BASE_MISSING_FINAL"
							+ contador + "; SET WORK.BASE_MISSING_FINAL" + contador
							+ "(drop=ID); IF QTDE_MIS > 0; RUN;PROC SORT DATA=BASE_MISSING_FINAL" + contador
							+ " OUT=BASE_MISSING_FINAL" + contador
							+ " NODUPKEY; BY NOME;RUN; %MEND GERARLISTA; %GERARLISTA(CAMPO_MISSING = &CAMPO_MISSING);");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_MISSING_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_MISSING_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
			} else {
				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS("%let limite = 5000000;ods output Members=Lista_Bases;proc datasets library="
							+ lib
							+ " memtype=data;run;data Lista_Bases_Missing;SET work.Lista_Bases (keep= Name WHERE = (NAME in ("
							+ bases
							+ ")));RUN;DATA _NULL_;SET WORK.Lista_Bases_Missing;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;DATA Lista_Bases_Missing;SET work.Lista_Bases_Missing;count + 1;RUN;%PUT NOBS_OBS: &NOBS_OBS.;");

					log += sas.ComandoSAS("%let campo_missing = " + nomeCampo
							+ ";%MACRO GERARLISTA(CAMPO_MISSING);PROC DELETE DATA=BASE_MISSING;RUN;%IF %SYSFUNC(EXIST(WORK.BASE_MISSING_FINAL"
							+ contador + ")) %THEN	%DO;DATA _NULL_;IF 0 THEN SET WORK.BASE_MISSING_FINAL" + contador
							+ " NOBS=N;	CALL SYMPUTX('NOBS_BASE_FINAL',N);			STOP;		RUN;	%PUT &&NOBS_BASE_FINAL.;	%IF &NOBS_BASE_FINAL. > 0 %THEN			%DO;			DATA BASE_MISSING_FINAL"
							+ contador + ";	SET WORK.BASE_MISSING_FINAL" + contador
							+ ";IF ID > 1000000;RUN;%END;	%END; %DO J=1 %TO &NOBS_OBS.;	%PUT &&NOME_BASE&J.;PROC CONTENTS DATA= "
							+ lib
							+ ".&&NOME_BASE&J.(keep=&CAMPO_MISSING) OUT= NAME_TYPE (KEEP= NAME TYPE) SHORT NOPRINT;	RUN;DATA _NULL_;		SET WORK.NAME_TYPE;		CALL SYMPUT(COMPRESS('TIPO_CAMPO' || _N_),TYPE);	RUN;%PUT TIPO_CAMPO: &TIPO_CAMPO1.;DATA _NULL_;		IF 0 THEN			SET "
							+ lib
							+ ".&&NOME_BASE&J. NOBS=N;		CALL SYMPUTX('NOBS_BASE',N);		STOP;	RUN;%PUT NOBS_BASE: &NOBS_BASE.;	%PUT LIMITE: &LIMITE.;%IF &NOBS_BASE. > 0 %THEN		%DO;			%IF &NOBS_BASE. > &LIMITE. %THEN				%DO;					%DO I = 1 %TO &NOBS_BASE. %BY &LIMITE.;						%PUT COMECO: &I.;						%LET FINAL =  %SYSFUNC(SUM(&LIMITE. + &I. - 1));						%PUT FINAL: &FINAL.;					%IF &TIPO_CAMPO1. = 1 %THEN							%DO;							DATA BASE_MENOR;									SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.);								IF &CAMPO_MISSING= .;								RUN;						%END;						%ELSE							%DO;							DATA BASE_MENOR;									SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.);								IF &CAMPO_MISSING= \"\";								RUN;						%END;					DATA _NULL_;							IF 0 THEN								SET WORK.BASE_MENOR NOBS=N;							CALL SYMPUTX('NOBS_MIS',N);							STOP;						RUN;						%PUT NOBS_MIS: &NOBS_MIS.;					DATA BASE_MISSING_AUX;							CAMPO = \"&CAMPO_MISSING.\";							NOME = \"&&NOME_BASE&J.\";							QTDE_MIS = &NOBS_MIS.;						RUN;					PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE;					%END;				%END;			%ELSE				%DO;					%IF &TIPO_CAMPO1. = 1 %THEN						%DO;					DATA BASE_MENOR;							SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_MISSING);						IF &CAMPO_MISSING= .;						RUN;					%END;					%ELSE						%DO;						DATA BASE_MENOR;								SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_MISSING);							IF &CAMPO_MISSING= \"\";							RUN;					%END;				DATA _NULL_;						IF 0 THEN							SET WORK.BASE_MENOR NOBS=N;						CALL SYMPUTX('NOBS_MIS',N);						STOP;						RUN;					%PUT NOBS_MIS: &NOBS_MIS.;				DATA BASE_MISSING_AUX;						CAMPO = \"&CAMPO_MISSING.\";						NOME = \"&&NOME_BASE&J.\";QTDE_MIS = &NOBS_MIS.;	RUN;PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE;	%END;PROC SQL;	CREATE TABLE BASE_MISSING_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_MIS)/&NOBS_BASE. AS QTDE_MIS_PORC, SUM(QTDE_MIS) AS QTDE_MIS, &J. AS ID FROM BASE_MISSING;QUIT;PROC SORT DATA=BASE_MISSING_TOTAL NODUPKEY;BY NOME;RUN;DATA BASE_MISSING_TOTAL;SET WORK.BASE_MISSING_TOTAL;FORMAT QTDE_MIS_PORC PERCENT8.3;RUN;PROC DELETE DATA=BASE_MISSING;	RUN;PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE;		%END;	%ELSE		%DO;		DATA BASE_MISSING;				QTDE_MIS = -1;				CAMPO = \"&CAMPO_MISSING.\";				NOME = \"&&NOME_BASE&J.\";			RUN; %END;		PROC SQL;				CREATE TABLE BASE_MISSING_TOTAL AS SELECT 					NOME, 					CAMPO, 					SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC, 					SUM(QTDE_MIS) AS QTDE_MIS, 					&J. AS ID FROM BASE_MISSING;			QUIT;		PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE;		PROC DELETE DATA=BASE_MISSING;			RUN;	%END;PROC DELETE DATA=BASE_MISSING_AUX;RUN;PROC DELETE DATA=BASE_MISSING_TOTAL;RUN;PROC DELETE DATA=LISTA_BASES;RUN;PROC DELETE DATA=NAME_TYPE;RUN;PROC DELETE DATA=BASE_MENOR; RUN; DATA BASE_MISSING_FINAL"
							+ contador + "; SET WORK.BASE_MISSING_FINAL" + contador
							+ ";IF QTDE_MIS > 0;RUN;PROC SORT DATA=BASE_MISSING_FINAL" + contador
							+ " OUT=BASE_MISSING_FINAL" + contador
							+ " NODUPKEY; BY NOME;RUN; %MEND GERARLISTA;%GERARLISTA(CAMPO_MISSING = &CAMPO_MISSING);");
				} else {
					log += sas.ComandoSAS("%let campo_missing = " + nomeCampo
							+ "; %let limite = 5000000; %let first_obs = " + new BigDecimal(nobs + 1).intValueExact() + "; %let NOME_BASE = "
							+ bases.substring(1, bases.length() - 1)
							+ "; %MACRO GERARLISTA(CAMPO_MISSING); PROC DELETE DATA=BASE_MISSING_FINAL" + contador
							+ "; RUN; PROC CONTENTS DATA= " + lib
							+ ".&NOME_BASE.(keep=&CAMPO_MISSING) OUT= NAME_TYPE (KEEP= NAME TYPE) SHORT NOPRINT; RUN; DATA _NULL_; SET WORK.NAME_TYPE; CALL SYMPUT(COMPRESS('TIPO_CAMPO' || _N_),TYPE); RUN; %PUT TIPO_CAMPO: &TIPO_CAMPO1.; DATA _NULL_; IF 0 THEN SET "
							+ lib
							+ ".&NOME_BASE. NOBS=N; CALL SYMPUTX('NOBS_BASE',N); STOP; RUN; %PUT NOBS_BASE: &NOBS_BASE.; %PUT LIMITE: &LIMITE.; %IF &NOBS_BASE. > 0 %THEN %DO; %IF &NOBS_BASE. > &LIMITE. %THEN %DO; %DO I = &first_obs. %TO &NOBS_BASE. %BY &LIMITE.; %PUT COMECO: &I.; %LET FINAL = %SYSFUNC(SUM(&LIMITE. + &I.)); %PUT FINAL: &FINAL.; %IF &TIPO_CAMPO1. = 1 %THEN %DO; DATA BASE_MENOR; SET "
							+ lib
							+ ".&NOME_BASE.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.); IF &CAMPO_MISSING= .; RUN; %END; %ELSE %DO; DATA BASE_MENOR; SET "
							+ lib
							+ ".&NOME_BASE.(KEEP= &CAMPO_MISSING FIRSTOBS=&I. OBS=&FINAL.); IF &CAMPO_MISSING= \"\"; RUN; %END; DATA _NULL_; IF 0 THEN SET WORK.BASE_MENOR NOBS=N; CALL SYMPUTX('NOBS_MIS',N); STOP; RUN; %PUT NOBS_MIS: &NOBS_MIS.; DATA BASE_MISSING_AUX; CAMPO = \"&CAMPO_MISSING.\"; NOME = \"&NOME_BASE.\"; QTDE_MIS = &NOBS_MIS.; RUN; PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE; %END; %END; %ELSE %DO; %IF &TIPO_CAMPO1. = 1 %THEN %DO; DATA BASE_MENOR; SET "
							+ lib
							+ ".&NOME_BASE.(KEEP= &CAMPO_MISSING firstobs=&first_obs.); IF &CAMPO_MISSING= .; RUN; %END; %ELSE %DO; DATA BASE_MENOR; SET "
							+ lib
							+ ".&NOME_BASE.(KEEP= &CAMPO_MISSING firstobs=&first_obs.); IF &CAMPO_MISSING= \"\"; RUN; %END; DATA _NULL_; IF 0 THEN SET WORK.BASE_MENOR NOBS=N; CALL SYMPUTX('NOBS_MIS',N); STOP; RUN; %PUT NOBS_MIS: &NOBS_MIS.; DATA BASE_MISSING_AUX; CAMPO = \"&CAMPO_MISSING.\"; NOME = \"&NOME_BASE.\"; QTDE_MIS = &NOBS_MIS.; RUN; PROC APPEND BASE=BASE_MISSING DATA=BASE_MISSING_AUX FORCE; %END; PROC SQL; CREATE TABLE BASE_MISSING_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_MIS)/&NOBS_BASE. AS QTDE_MIS_PORC, SUM(QTDE_MIS) AS QTDE_MIS FROM BASE_MISSING; QUIT; DATA BASE_MISSING_TOTAL; SET WORK.BASE_MISSING_TOTAL; FORMAT QTDE_MIS_PORC PERCENT8.3; RUN; PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE; %END; %ELSE %DO; DATA BASE_MISSING; QTDE_MIS = -1; CAMPO = \"&CAMPO_MISSING.\"; NOME = \"&NOME_BASE.\"; RUN; %END; PROC SQL; CREATE TABLE BASE_MISSING_TOTAL AS SELECT NOME, CAMPO, SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC, SUM(QTDE_MIS) AS QTDE_MIS FROM BASE_MISSING; QUIT; PROC APPEND BASE=BASE_MISSING_FINAL"
							+ contador
							+ " DATA=BASE_MISSING_TOTAL FORCE; PROC DELETE DATA=BASE_MISSING; RUN; PROC DELETE DATA=BASE_MISSING_AUX; RUN; PROC DELETE DATA=BASE_MISSING_TOTAL; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=NAME_TYPE; RUN; PROC DELETE DATA=BASE_MENOR; RUN; data BASE_MISSING_FINAL"
							+ contador + "; SET WORK.BASE_MISSING_FINAL" + contador
							+ "(drop=ID); IF QTDE_MIS > 0; RUN;PROC SORT DATA=BASE_MISSING_FINAL" + contador
							+ " OUT=BASE_MISSING_FINAL" + contador
							+ " NODUPKEY; BY NOME;RUN; %MEND GERARLISTA; %GERARLISTA(CAMPO_MISSING = &CAMPO_MISSING);");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_MISSING_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_MISSING_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");
			}
		} catch (GenericError e) {
			e.printStackTrace();
		}

		System.out.println(log);

		if (log.contains("\"DEU BOA\" || 1")) {
			tabelaMissingErros = sas.baseSAS("SELECT * FROM WORK.BASE_MISSING_FINAL" + contador);

		}
		return tabelaMissingErros;
	}

	private ArrayList<ArrayList<String>> preparaDadosRangeSAS(ConectorSAS sas, String lib, String bases,
			ColunaTabela coluna, Base base, int contador, double nobs) {
		String log = "";

		if (!bases.contains("\"")) {
			bases = "\"" + bases + "\"";
		}

		try {
			if (lib.length() > 9) {
				log = sas.ComandoSAS("libname INTEG " + lib + ";");
				log += sas.ComandoSAS(
						"%let limite = 5000000;ods output Members=Lista_Bases;proc datasets library=INTEG memtype=data;run;data Lista_Bases_RANGE;SET work.Lista_Bases (keep= Name WHERE = (NAME in ("
								+ bases
								+ ")));RUN;DATA _NULL_;SET WORK.Lista_Bases_Range;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;DATA Lista_Bases_RANGE;SET work.Lista_Bases_RANGE;count + 1;RUN;");
				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS("%let campo_range = " + coluna.getNomeColuna() + ";%let max = "
							+ coluna.getRangeMax() + ";%let min = " + coluna.getRangeMin()
							+ ";%MACRO GERARLISTA(CAMPO_RANGE, MAX, MIN);  PROC DELETE DATA=BASE_RANGE;RUN;%IF %SYSFUNC(EXIST(WORK.BASE_RANGE_FINAL"
							+ contador + ")) %THEN %DO;DATA _NULL_; IF 0 THEN SET WORK.BASE_RANGE_FINAL" + contador
							+ " NOBS=N;CALL SYMPUTX('NOBS_BASE_FINAL',N);STOP;RUN;%PUT &&NOBS_BASE_FINAL.; %IF &NOBS_BASE_FINAL. > 0 %THEN %DO;                               DATA BASE_RANGE_FINAL"
							+ contador + "; SET WORK.BASE_RANGE_FINAL" + contador
							+ "; IF ID > 10000000; RUN;%END;%END;%DO J=1 %TO &NOBS_OBS.;PROC CONTENTS DATA=INTEG.&&NOME_BASE&J.(keep=&campo_range.) OUT=CONTENTS (KEEP= NOBS NAME TYPE LENGTH) NOPRINT SHORT;         RUN;DATA _NULL_; SET WORK.CONTENTS; CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE);CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH);                CALL SYMPUT(COMPRESS('NOBS_BASE' || _N_),NOBS);         RUN;          %PUT &&NOME_BASE&J.;        %PUT &NOBS_BASE1.;          %PUT TIPO1: &TIPO1.;        %IF &NOBS_BASE1. > 0 %THEN%DO;%IF &NOBS_BASE1. > &LIMITE. %THEN %DO; %DO I = 1 %TO &NOBS_BASE1. %BY &LIMITE.; %PUT COMECO: &I.; %LET FINAL =  %SYSFUNC(SUM(&LIMITE. + &I. - 1));%PUT FINAL: &FINAL.;%IF &TIPO1. = 2 %THEN             %DO;                DATA BASE_MENOR (KEEP= NEW_CAMPO);                     SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_RANGE. FIRSTOBS=&I. OBS=&FINAL.);                          NEW_CAMPO = INPUT(&CAMPO_RANGE., &TAMANHO1..);                       IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;                    RUN;         %END; %ELSE        %DO;                DATA BASE_MENOR (KEEP= NEW_CAMPO);                     SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_RANGE. FIRSTOBS=&I. OBS=&FINAL.);                          NEW_CAMPO = &CAMPO_RANGE.;                      IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;                    RUN;         %END; DATA _NULL_;        IF 0 THEN                  SET BASE_MENOR NOBS=N;            CALL SYMPUTX('QTDE_RANGE_FORA',N);       STOP; RUN;  %PUT QTDE_RANGE_FORA:&QTDE_RANGE_FORA.;  %IF &QTDE_RANGE_FORA. > 0 %THEN          %DO;                DATA MAX_MIN (KEEP=MAXA MINA);                         SET BASE_MENOR  END=DONE;                RETAIN MAXA 0;                           RETAIN MINA 0;                           MAXA = MAX(NEW_CAMPO,MAXA);                     MINA = MIN(NEW_CAMPO,MINA);                     IF DONE THEN                             OUTPUT;RUN;DATA _NULL_;SET WORK.MAX_MIN;CALL SYMPUTX('MAX1',MAXA);                           CALL SYMPUTX('MIN1',MINA);                    RUN;         %END; %ELSE        %DO;                %LET MIN1 = 0;              %LET MAX1 = 0;%END; %PUT MIN: &MIN1.;   %PUT MAX: &MAX1.;   %PUT QTDE_RANGE_FORA: &QTDE_RANGE_FORA.; DATA BASE_RANGE_AUX;       QTDE_RAN_FORA = &QTDE_RANGE_FORA.;       MIN_VALUE = &MIN1.;        MAX_VALUE = &MAX1.;        CAMPO = \"&CAMPO_RANGE.\";        NOME = \"&&NOME_BASE&J.\"; RUN;  PROC APPEND BASE=BASE_RANGE DATA=BASE_RANGE_AUX FORCE;                                     %END;                              %END;                       %ELSE                              %DO;                                      %IF &TIPO1. = 2 %THEN      %DO;  DATA BASE_MENOR (KEEP= NEW_CAMPO);       SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_RANGE.);         NEW_CAMPO = INPUT(&CAMPO_RANGE., &TAMANHO1..);         IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;      RUN;  %END;                                     %ELSE %DO;         DATA BASE_MENOR (KEEP= NEW_CAMPO);              SET INTEG.&&NOME_BASE&J.(KEEP= &CAMPO_RANGE.);                NEW_CAMPO = &CAMPO_RANGE.;               IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;             RUN;  %END;                                     DATA _NULL_; IF 0 THEN           SET BASE_MENOR NOBS=N;     CALL SYMPUTX('QTDE_RANGE_FORA',N);STOP;                                     RUN;                                      %PUT QTDE_RANGE_FORA:&QTDE_RANGE_FORA.;                                      %IF &QTDE_RANGE_FORA. > 0 %THEN   %DO;         DATA MAX_MIN (KEEP=MAXA MINA);                  SET BASE_MENOR  END=DONE;                RETAIN MAXA 0;                    RETAIN MINA 0;                    MAXA = MAX(NEW_CAMPO,MAXA);              MINA = MIN(NEW_CAMPO,MINA);              IF DONE THEN                      OUTPUT;             RUN;         DATA _NULL_;               SET WORK.MAX_MIN;                 CALL SYMPUTX('MAX1',MAXA);                    CALL SYMPUTX('MIN1',MINA);             RUN;  %END;                                     %ELSE %DO;         %LET MIN1 = 0;       %LET MAX1 = 0;%END;                                     %PUT QTDE_RANGE_FORA: &QTDE_RANGE_FORA.;                                     DATA BASE_RANGE_AUX;QTDE_RAN_FORA = &QTDE_RANGE_FORA.;MIN_VALUE = &MIN1.; MAX_VALUE = &MAX1.; CAMPO = \"&CAMPO_RANGE.\"; NOME = \"&&NOME_BASE&J.\";                                     RUN;                                      PROC APPEND BASE=BASE_RANGE DATA=BASE_RANGE_AUX FORCE;                              %END;                       PROC SQL;                                 CREATE TABLE BASE_RANGE_TOTAL AS SELECT                                      NOME,                                     CAMPO,SUM(QTDE_RAN_FORA) AS QTDE_FORA,SUM(QTDE_RAN_FORA)/&NOBS_BASE1. AS QTDE_FORA_PORC,MIN(MIN_VALUE) AS MIN, MAX(MAX_VALUE) AS MAX,&J. AS ID FROM BASE_RANGE;QUIT; PROC DELETE DATA=BASE_RANGE; RUN; PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE;%END;%ELSE %DO;= DATA BASE_RANGE; QTDE_RAN_FORA = -1;  MIN_VALUE = -1; MAX_VALUE = -1; CAMPO = \"&CAMPO_RANGE.\";  NOME = \"&&NOME_BASE&J.\";RUN; PROC SQL; CREATE TABLE BASE_RANGE_TOTAL AS SELECT NOME, CAMPO,SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC,SUM(QTDE_MIS) AS QTDE_MIS,&J. AS ID FROM BASE_RANGE; QUIT; PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE;                      PROC DELETE DATA=BASE_RANGE;                            RUN;                 %END;  %END;  PROC DELETE DATA=BASE_RANGE_TOTAL; RUN;   PROC DELETE DATA=BASE_RANGE_AUX;   RUN;   PROC DELETE DATA=LISTA_BASES;      RUN;   PROC DELETE DATA=CONTENTS;  RUN;   PROC DELETE DATA=BASE_MENOR;       RUN;   PROC DELETE DATA=MAX_MIN;   RUN; DATA BASE_RANGE_FINAL"
							+ contador + ";SET WORK.BASE_RANGE_FINAL" + contador
							+ ";IF QTDE_FORA > 0;RUN; %MEND GERARLISTA;%GERARLISTA(CAMPO_RANGE = &CAMPO_RANGE, MAX = &MAX, MIN = &MIN);");
				} else {
					log += sas.ComandoSAS("%let campo_range = " + coluna.getNomeColuna() + "; %let max = "
							+ coluna.getRangeMax() + "; %let min = " + coluna.getRangeMin() + "; %let first_obs = "
							+ new BigDecimal(nobs + 1).intValueExact() + "; %let NOME_BASE = " + bases.substring(1, bases.length() - 1)
							+ "; %MACRO GERARLISTA(CAMPO_RANGE, MAX, MIN); PROC DELETE DATA=BASE_RANGE; RUN; PROC DELETE DATA=BASE_RANGE_FINAL"
							+ contador
							+ "; RUN; DATA FIRSTOBS_BASE; SET INTEG.&NOME_BASE.(Firstobs=&first_obs. keep= &campo_range.); RUN; PROC CONTENTS DATA=FIRSTOBS_BASE OUT=CONTENTS (KEEP= NOBS NAME TYPE LENGTH) NOPRINT SHORT; RUN; DATA _NULL_; SET WORK.CONTENTS; CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE); CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH); CALL SYMPUT(COMPRESS('NOBS_BASE' || _N_),NOBS); RUN; %PUT &NOME_BASE.; %PUT &NOBS_BASE1.; %PUT TIPO1: &TIPO1.; %IF &NOBS_BASE1. > 0 %THEN %DO; %IF &TIPO1. = 2 %THEN %DO; DATA BASE_MENOR (KEEP= NEW_CAMPO); SET FIRSTOBS_BASE; NEW_CAMPO = INPUT(&CAMPO_RANGE., &TAMANHO1..); IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.; RUN; %END; %ELSE %DO; DATA BASE_MENOR (KEEP= NEW_CAMPO); SET FIRSTOBS_BASE; NEW_CAMPO = &CAMPO_RANGE.; IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.; RUN; %END; DATA _NULL_; IF 0 THEN SET BASE_MENOR NOBS=N; CALL SYMPUTX('QTDE_RANGE_FORA',N); STOP; RUN; %PUT QTDE_RANGE_FORA:&QTDE_RANGE_FORA.; %IF &QTDE_RANGE_FORA. > 0 %THEN %DO; DATA MAX_MIN (KEEP=MAXA MINA); SET BASE_MENOR END=DONE; RETAIN MAXA 0; RETAIN MINA 0; MAXA = MAX(NEW_CAMPO,MAXA); MINA = MIN(NEW_CAMPO,MINA); IF DONE THEN OUTPUT; RUN; DATA _NULL_; SET WORK.MAX_MIN; CALL SYMPUTX('MAX1',MAXA); CALL SYMPUTX('MIN1',MINA); RUN; %END; %ELSE %DO; %LET MIN1 = 0; %LET MAX1 = 0; %END; %PUT QTDE_RANGE_FORA: &QTDE_RANGE_FORA.; DATA BASE_RANGE_AUX; QTDE_RAN_FORA = &QTDE_RANGE_FORA.; MIN_VALUE = &MIN1.; MAX_VALUE = &MAX1.; CAMPO = \"&CAMPO_RANGE.\"; NOME = \"&NOME_BASE.\"; RUN; PROC APPEND BASE=BASE_RANGE DATA=BASE_RANGE_AUX FORCE; PROC SQL; CREATE TABLE BASE_RANGE_TOTAL AS SELECT NOME, CAMPO,SUM(QTDE_RAN_FORA) AS QTDE_FORA,SUM(QTDE_RAN_FORA)/&NOBS_BASE1. AS QTDE_FORA_PORC,MIN(MIN_VALUE) AS MIN, MAX(MAX_VALUE) AS MAX FROM BASE_RANGE; QUIT; PROC DELETE DATA=BASE_RANGE; RUN; PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE; %END; %ELSE %DO; DATA BASE_RANGE; QTDE_RAN_FORA = -1; MIN_VALUE = -1; MAX_VALUE = -1; CAMPO = \"&CAMPO_RANGE.\"; NOME = \"&NOME_BASE.\"; RUN; PROC SQL; CREATE TABLE BASE_RANGE_TOTAL AS SELECT NOME, CAMPO,SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC,SUM(QTDE_MIS) AS QTDE_MIS FROM BASE_RANGE; QUIT; PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE; PROC DELETE DATA=BASE_RANGE; RUN; %END; PROC DELETE DATA=BASE_RANGE_TOTAL; RUN; PROC DELETE DATA=BASE_RANGE_AUX; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=CONTENTS; RUN; PROC DELETE DATA=BASE_MENOR; RUN; PROC DELETE DATA=MAX_MIN; RUN; data BASE_RANGE_FINAL"
							+ contador + "; SET WORK.BASE_RANGE_FINAL" + contador
							+ "; IF QTDE_FORA > 0; RUN; %MEND GERARLISTA; %GERARLISTA(CAMPO_RANGE = &CAMPO_RANGE, MAX = &MAX, MIN = &MIN);");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_RANGE_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_RANGE_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");

			} else {
				log += sas.ComandoSAS("%let limite = 5000000;ods output Members=Lista_Bases;proc datasets library="
						+ lib
						+ " memtype=data;run;data Lista_Bases_RANGE;SET work.Lista_Bases (keep= Name WHERE = (NAME in ("
						+ bases
						+ ")));RUN;DATA _NULL_;SET WORK.Lista_Bases_Range;CALL SYMPUT(COMPRESS('nome_base' || _N_),NAME);CALL SYMPUT('NOBS_OBS',_N_);RUN;DATA Lista_Bases_RANGE;SET work.Lista_Bases_RANGE;count + 1;RUN;");

				if (base.getSafrada() == 0 && !base.getIncrem_full().equals("INCREMENTAL")) {
					log += sas.ComandoSAS("%let campo_range = " + coluna.getNomeColuna() + ";%let max = "
							+ coluna.getRangeMax() + ";%let min = " + coluna.getRangeMin()
							+ ";%MACRO GERARLISTA(CAMPO_RANGE, MAX, MIN);  PROC DELETE DATA=BASE_RANGE;       RUN;   %IF %SYSFUNC(EXIST(WORK.BASE_RANGE_FINAL"
							+ contador
							+ ")) %THEN        %DO;                 DATA _NULL_;                       IF 0 THEN                                 SET WORK.BASE_RANGE_FINAL"
							+ contador
							+ " NOBS=N;                       CALL SYMPUTX('NOBS_BASE_FINAL',N);                      STOP;                RUN;                 %PUT &&NOBS_BASE_FINAL.;                  %IF &NOBS_BASE_FINAL. > 0 %THEN                         %DO;                               DATA BASE_RANGE_FINAL"
							+ contador + ";                                         SET WORK.BASE_RANGE_FINAL"
							+ contador
							+ ";                                     IF ID > 10000000;                                RUN;                        %END;         %END;  %DO J=1 %TO &NOBS_OBS.;            PROC CONTENTS DATA="
							+ lib
							+ ".&&NOME_BASE&J.(keep=&campo_range.) OUT=CONTENTS (KEEP= NOBS NAME TYPE LENGTH) NOPRINT SHORT;         RUN;          DATA _NULL_;                SET WORK.CONTENTS;                 CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE);                     CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH);                CALL SYMPUT(COMPRESS('NOBS_BASE' || _N_),NOBS);         RUN;          %PUT &&NOME_BASE&J.;        %PUT &NOBS_BASE1.;          %PUT TIPO1: &TIPO1.;        %IF &NOBS_BASE1. > 0 %THEN                %DO;                        %IF &NOBS_BASE1. > &LIMITE. %THEN                              %DO;                                      %DO I = 1 %TO &NOBS_BASE1. %BY &LIMITE.; %PUT COMECO: &I.;   %LET FINAL =  %SYSFUNC(SUM(&LIMITE. + &I. - 1));%PUT FINAL: &FINAL.;%IF &TIPO1. = 2 %THEN             %DO;                DATA BASE_MENOR (KEEP= NEW_CAMPO);                     SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_RANGE. FIRSTOBS=&I. OBS=&FINAL.);                          NEW_CAMPO = INPUT(&CAMPO_RANGE., &TAMANHO1..);                       IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;                    RUN;         %END; %ELSE        %DO;                DATA BASE_MENOR (KEEP= NEW_CAMPO);                     SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_RANGE. FIRSTOBS=&I. OBS=&FINAL.);                          NEW_CAMPO = &CAMPO_RANGE.;                      IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;                    RUN;         %END; DATA _NULL_;        IF 0 THEN                  SET BASE_MENOR NOBS=N;            CALL SYMPUTX('QTDE_RANGE_FORA',N);       STOP; RUN;  %PUT QTDE_RANGE_FORA:&QTDE_RANGE_FORA.;  %IF &QTDE_RANGE_FORA. > 0 %THEN          %DO;                DATA MAX_MIN (KEEP=MAXA MINA);                         SET BASE_MENOR  END=DONE;                RETAIN MAXA 0;                           RETAIN MINA 0;                           MAXA = MAX(NEW_CAMPO,MAXA);                     MINA = MIN(NEW_CAMPO,MINA);                     IF DONE THEN OUTPUT;RUN; DATA _NULL_;SET WORK.MAX_MIN;CALL SYMPUTX('MAX1',MAXA);CALL SYMPUTX('MIN1',MINA);RUN; %END;%ELSE%DO;                %LET MIN1 = 0;              %LET MAX1 = 0;%END; %PUT MIN: &MIN1.;   %PUT MAX: &MAX1.;   %PUT QTDE_RANGE_FORA: &QTDE_RANGE_FORA.; DATA BASE_RANGE_AUX;       QTDE_RAN_FORA = &QTDE_RANGE_FORA.;       MIN_VALUE = &MIN1.;        MAX_VALUE = &MAX1.;        CAMPO = \"&CAMPO_RANGE.\";        NOME = \"&&NOME_BASE&J.\"; RUN;  PROC APPEND BASE=BASE_RANGE DATA=BASE_RANGE_AUX FORCE;                                     %END;                              %END;                       %ELSE                              %DO;                                      %IF &TIPO1. = 2 %THEN      %DO;  DATA BASE_MENOR (KEEP= NEW_CAMPO);       SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_RANGE.);         NEW_CAMPO = INPUT(&CAMPO_RANGE., &TAMANHO1..);         IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;      RUN;  %END;                                     %ELSE %DO;         DATA BASE_MENOR (KEEP= NEW_CAMPO);              SET "
							+ lib
							+ ".&&NOME_BASE&J.(KEEP= &CAMPO_RANGE.);                NEW_CAMPO = &CAMPO_RANGE.;               IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.;             RUN;  %END;                                     DATA _NULL_; IF 0 THEN           SET BASE_MENOR NOBS=N;     CALL SYMPUTX('QTDE_RANGE_FORA',N);STOP;                                     RUN;                                      %PUT QTDE_RANGE_FORA:&QTDE_RANGE_FORA.;                                      %IF &QTDE_RANGE_FORA. > 0 %THEN   %DO;         DATA MAX_MIN (KEEP=MAXA MINA);                  SET BASE_MENOR  END=DONE;                RETAIN MAXA 0;                    RETAIN MINA 0;                    MAXA = MAX(NEW_CAMPO,MAXA);              MINA = MIN(NEW_CAMPO,MINA);              IF DONE THEN                      OUTPUT;             RUN;         DATA _NULL_;               SET WORK.MAX_MIN;                 CALL SYMPUTX('MAX1',MAXA);                    CALL SYMPUTX('MIN1',MINA);             RUN;  %END;                                     %ELSE %DO;         %LET MIN1 = 0;       %LET MAX1 = 0;%END;                                     %PUT QTDE_RANGE_FORA: &QTDE_RANGE_FORA.;                                     DATA BASE_RANGE_AUX;QTDE_RAN_FORA = &QTDE_RANGE_FORA.;MIN_VALUE = &MIN1.; MAX_VALUE = &MAX1.; CAMPO = \"&CAMPO_RANGE.\"; NOME = \"&&NOME_BASE&J.\";                                     RUN;                                      PROC APPEND BASE=BASE_RANGE DATA=BASE_RANGE_AUX FORCE;                              %END;                       PROC SQL;                                 CREATE TABLE BASE_RANGE_TOTAL AS SELECT                                      NOME,                                     CAMPO,                                    SUM(QTDE_RAN_FORA) AS QTDE_FORA,                                      SUM(QTDE_RAN_FORA)/&NOBS_BASE1. AS QTDE_FORA_PORC,                                         MIN(MIN_VALUE) AS MIN,MAX(MAX_VALUE) AS MAX,&J. AS ID FROM BASE_RANGE;QUIT;PROC DELETE DATA=BASE_RANGE; RUN; PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE;               %END;         %ELSE                %DO;                        DATA BASE_RANGE;                                 QTDE_RAN_FORA = -1;                              MIN_VALUE = -1;                                  MAX_VALUE = -1;                                  CAMPO = \"&CAMPO_RANGE.\";                              NOME = \"&&NOME_BASE&J.\";                       RUN;                        PROC SQL;                                 CREATE TABLE BASE_RANGE_TOTAL AS SELECT                                      NOME,                                     CAMPO,SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC,                                     SUM(QTDE_MIS) AS QTDE_MIS,                                     &J. AS ID FROM BASE_RANGE;                       QUIT;                       PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE;                      PROC DELETE DATA=BASE_RANGE;                            RUN;                 %END;  %END;  PROC DELETE DATA=BASE_RANGE_TOTAL; RUN;   PROC DELETE DATA=BASE_RANGE_AUX;   RUN;   PROC DELETE DATA=LISTA_BASES;      RUN;   PROC DELETE DATA=CONTENTS;  RUN;   PROC DELETE DATA=BASE_MENOR;       RUN;   PROC DELETE DATA=MAX_MIN;   RUN; DATA BASE_RANGE_FINAL"
							+ contador + ";SET WORK.BASE_RANGE_FINAL" + contador
							+ ";IF QTDE_FORA > 0;RUN; %MEND GERARLISTA;%GERARLISTA(CAMPO_RANGE = &CAMPO_RANGE, MAX = &MAX, MIN = &MIN);");
				} else {
					log += sas.ComandoSAS("%let campo_range = " + coluna.getNomeColuna() + "; %let max = "
							+ coluna.getRangeMax() + "; %let min = " + coluna.getRangeMin() + "; %let first_obs = "
							+ new BigDecimal(nobs + 1).intValueExact() + "; %let NOME_BASE = " + bases.substring(1, bases.length() - 1)
							+ "; %MACRO GERARLISTA(CAMPO_RANGE, MAX, MIN); PROC DELETE DATA=BASE_RANGE; RUN; PROC DELETE DATA=BASE_RANGE_FINAL"
							+ contador + "; RUN; DATA FIRSTOBS_BASE; SET " + lib
							+ ".&NOME_BASE.(Firstobs=&first_obs. keep= &campo_range.); RUN; PROC CONTENTS DATA=FIRSTOBS_BASE OUT=CONTENTS (KEEP= NOBS NAME TYPE LENGTH) NOPRINT SHORT; RUN; DATA _NULL_; SET WORK.CONTENTS; CALL SYMPUT(COMPRESS('TIPO' || _N_),TYPE); CALL SYMPUT(COMPRESS('TAMANHO' || _N_),LENGTH); CALL SYMPUT(COMPRESS('NOBS_BASE' || _N_),NOBS); RUN; %PUT &NOME_BASE.; %PUT &NOBS_BASE1.; %PUT TIPO1: &TIPO1.; %IF &NOBS_BASE1. > 0 %THEN %DO; %IF &TIPO1. = 2 %THEN %DO; DATA BASE_MENOR (KEEP= NEW_CAMPO); SET FIRSTOBS_BASE; NEW_CAMPO = INPUT(&CAMPO_RANGE., &TAMANHO1..); IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.; RUN; %END; %ELSE %DO; DATA BASE_MENOR (KEEP= NEW_CAMPO); SET FIRSTOBS_BASE; NEW_CAMPO = &CAMPO_RANGE.; IF NEW_CAMPO > &MAX. OR NEW_CAMPO < &MIN.; RUN; %END; DATA _NULL_; IF 0 THEN SET BASE_MENOR NOBS=N; CALL SYMPUTX('QTDE_RANGE_FORA',N); STOP; RUN; %PUT QTDE_RANGE_FORA:&QTDE_RANGE_FORA.; %IF &QTDE_RANGE_FORA. > 0 %THEN %DO; DATA MAX_MIN (KEEP=MAXA MINA); SET BASE_MENOR END=DONE; RETAIN MAXA 0; RETAIN MINA 0; MAXA = MAX(NEW_CAMPO,MAXA); MINA = MIN(NEW_CAMPO,MINA); IF DONE THEN OUTPUT; RUN; DATA _NULL_; SET WORK.MAX_MIN; CALL SYMPUTX('MAX1',MAXA); CALL SYMPUTX('MIN1',MINA); RUN; %END; %ELSE %DO; %LET MIN1 = 0; %LET MAX1 = 0; %END; %PUT QTDE_RANGE_FORA: &QTDE_RANGE_FORA.; DATA BASE_RANGE_AUX; QTDE_RAN_FORA = &QTDE_RANGE_FORA.; MIN_VALUE = &MIN1.; MAX_VALUE = &MAX1.; CAMPO = \"&CAMPO_RANGE.\"; NOME = \"&NOME_BASE.\"; RUN; PROC APPEND BASE=BASE_RANGE DATA=BASE_RANGE_AUX FORCE; PROC SQL; CREATE TABLE BASE_RANGE_TOTAL AS SELECT NOME, CAMPO,SUM(QTDE_RAN_FORA) AS QTDE_FORA,SUM(QTDE_RAN_FORA)/&NOBS_BASE1. AS QTDE_FORA_PORC,MIN(MIN_VALUE) AS MIN, MAX(MAX_VALUE) AS MAX FROM BASE_RANGE; QUIT; PROC DELETE DATA=BASE_RANGE; RUN; PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE; %END; %ELSE %DO; DATA BASE_RANGE; QTDE_RAN_FORA = -1; MIN_VALUE = -1; MAX_VALUE = -1; CAMPO = \"&CAMPO_RANGE.\"; NOME = \"&NOME_BASE.\"; RUN; PROC SQL; CREATE TABLE BASE_RANGE_TOTAL AS SELECT NOME, CAMPO,SUM(QTDE_MIS)/1 AS QTDE_MIS_PORC,SUM(QTDE_MIS) AS QTDE_MIS FROM BASE_RANGE; QUIT; PROC APPEND BASE=BASE_RANGE_FINAL"
							+ contador
							+ " DATA=BASE_RANGE_TOTAL FORCE; PROC DELETE DATA=BASE_RANGE; RUN; %END; PROC DELETE DATA=BASE_RANGE_TOTAL; RUN; PROC DELETE DATA=BASE_RANGE_AUX; RUN; PROC DELETE DATA=LISTA_BASES; RUN; PROC DELETE DATA=CONTENTS; RUN; PROC DELETE DATA=BASE_MENOR; RUN; PROC DELETE DATA=MAX_MIN; RUN; data BASE_RANGE_FINAL"
							+ contador + "; SET WORK.BASE_RANGE_FINAL" + contador
							+ "; IF QTDE_FORA > 0; RUN; %MEND GERARLISTA; %GERARLISTA(CAMPO_RANGE = &CAMPO_RANGE, MAX = &MAX, MIN = &MIN);");
				}
				log += sas.ComandoSAS("%macro existe;%IF %SYSFUNC(EXIST(WORK.BASE_RANGE_FINAL" + contador
						+ ")) %THEN %PUT \"DEU BOA\" || %SYSFUNC(EXIST(WORK.BASE_RANGE_FINAL" + contador
						+ "));%ELSE %PUT \"N�o criou lista nobs\";%mend;%existe;");

			}

			if (log.contains("\"DEU BOA\" || 1")) {
				System.out.println(log);
			}
		} catch (GenericError e) {
			e.printStackTrace();
		}

		System.out.println(log);

		ArrayList<ArrayList<String>> tabela_range_erros = new ArrayList<ArrayList<String>>();
		if (log.contains("\"DEU BOA\" || 1")) {
			tabela_range_erros = sas.baseSAS("SELECT * FROM WORK.BASE_RANGE_FINAL" + contador);

		}
		return tabela_range_erros;

	}

	private List<Object> listarCamposDuplicidade(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		List<Object> colunas;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			colunas = regraDAO.listarCamposDuplicidade(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return colunas;
	}

	private List<ColunaTabela> listarCamposRange(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		List<ColunaTabela> colunas;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			colunas = regraDAO.listarCamposRange(idTb);

			sqlServer.encerrar();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return colunas;
	}

	private List<ColunaTabela> listarCamposMissing(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		List<ColunaTabela> colunas;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			colunas = regraDAO.listarCamposMissing(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return colunas;
	}

	private List<ColunaTabela> listarCamposDominio(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		List<ColunaTabela> colunas;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			colunas = regraDAO.listarCamposDominio(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return colunas;
	}

	private List<ColunaTabela> listarCamposPSI(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		List<ColunaTabela> colunas;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			colunas = regraDAO.listarCamposPSI(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return colunas;
	}

	// lista de bases para rodar de acordo com o nome da base origem
	private List<String> gerarListaBasesRodarAutomatico(String nomeBase, String tipoBase) {
		GerenciadorDeConexao sqlServer = null;
		List<String> bases;
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			bases = baseDAO.gerarListaBasesRodar(nomeBase, tipoBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return bases;
	}

	// pega o nome das bases que tem notificacao por data
	private ArrayList<String> getNomeBasesNotificacao(String data) {
		GerenciadorDeConexao sqlServer = null;
		ArrayList<String> nomesBases;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			nomesBases = notifDAO.getNomeBasesNotificacao(data);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return nomesBases;

	}

	private void deletarListaRun(String nomeBase) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			baseDAO.deletarListaRun(nomeBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar();
			}
		}
	}

	private void inserirNotificacao(int idCol, int idRegra, String nomeBase, String msg) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			notifDAO.inserirNotificacao(idCol, idRegra, nomeBase, msg);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	private void inserirStatusBases(List<StatusBases> statusBases) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			notifDAO.inserirStatusBases(statusBases);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	private void inserirPSI(double psi, ColunaTabela coluna, String nmBase, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			regraDAO.inserirPSI(psi, coluna, nmBase, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	private boolean validarPSI(String nomeBase, int idTB, ColunaTabela d) {

		boolean validar = false;
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			validar = regraDAO.validarPSI(nomeBase, idTB, d);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return validar;
	}

	private void updateQualidadeRunning(int status) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			baseDAO.updateQualidadeRunning(status);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	private List<Notificacao> getNotificacaoPorData(String data, String nomeBase) {
		GerenciadorDeConexao sqlServer = null;
		List<Notificacao> notificacoes;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO notifDAO = sqlServer.getObjetoNotificacaoDAO();
			notificacoes = notifDAO.getNotificacaoPorData(data, nomeBase);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return notificacoes;

	}

	private String getNomeBasePeloID(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		String nomeBase = "";

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			nomeBase = bDAO.getNomeBasePeloID(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return nomeBase;

	}

	private ArrayList<Double> getAmostraParaCalPorID(int id, int tamanho) {

		GerenciadorDeConexao sqlServer = null;
		ArrayList<Double> nobs = new ArrayList<Double>();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO bDAO = sqlServer.getObjetoObs();
			nobs = bDAO.getAmostraParaCalPorID(id, tamanho);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return nobs;
	}

	private ArrayList<Double> getRangeParaCalPorID(int id, int tamanho) {

		GerenciadorDeConexao sqlServer = null;
		ArrayList<Double> nobs = new ArrayList<Double>();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO bDAO = sqlServer.getObjetoObs();
			nobs = bDAO.getRangeParaCalPorID(id, tamanho);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return nobs;
	}

	private ArrayList<Double> getRangeMediaParaCalPorID(int id, int tamanho) {

		GerenciadorDeConexao sqlServer = null;
		ArrayList<Double> nobs = new ArrayList<Double>();

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO bDAO = sqlServer.getObjetoObs();
			nobs = bDAO.getRangeMediaParaCalPorID(id, tamanho);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return nobs;
	}

	public int getIDTabelabyIDColIDRegra(int idCol, int idRegra) {
		GerenciadorDeConexao sqlServer = null;
		int idTB;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			RegraDAO regraDAO = sqlServer.getObjetoRegraDAO();
			idTB = regraDAO.getIDTabelabyIDColIDRegra(idCol, idRegra);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return idTB;
	}

	public String getUltimaInsercaoRegbyId(int id) {
		GerenciadorDeConexao sqlServer = null;
		String max;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			max = obsDAO.getUltimaInsercaoRegbyId(id);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return max;
	}

	public int getidBaseToda(int idTb) {
		GerenciadorDeConexao sqlServer = null;
		int idBaseToda;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			idBaseToda = baseDAO.getidBaseToda(idTb);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return idBaseToda;
	}

	public int analisaHistorico(Base base, int tamanho) {
		double limInferior = base.getLimiteInferior();
		double limSuperior = base.getLimiteSuperior();
		int contInf = 0;
		int contSup = 0;

		ArrayList<Double> qtdeDesvHist = getQtdeDesvHist(base.getIdTabela(), tamanho);

		for (int i = 0; i < qtdeDesvHist.size(); i++) {
			if (qtdeDesvHist.get(i) < limInferior) {
				contInf++;
			} else if (qtdeDesvHist.get(i) > limSuperior) {
				contSup++;
			}
		}
		if (tamanho > 4 && tamanho <= 6) {
			if (contInf > 3 || contSup > 3) {
				tamanho = 4;
			}
			if (contSup > 3) {
				tamanho = 4;
			}
		} else if (tamanho == 10) {
			if (contInf > 3 && contInf <= 5) {
				tamanho = 6;
			} else if (contInf > 5 && contInf <= 10) {
				tamanho = 4;
			}
			if (contSup > 3 && contSup <= 5) {
				tamanho = 6;
			} else if (contSup > 5 && contSup <= 10) {
				tamanho = 4;
			}
		} else if (tamanho == 15) {
			if (contInf > 5 && contInf <= 10) {
				tamanho = 10;
			} else if (contInf > 10 && contInf <= 15) {
				tamanho = 6;
			}
			if (contSup > 5 && contSup <= 10) {
				tamanho = 10;
			} else if (contSup > 10 && contSup <= 15) {
				tamanho = 6;
			}
		} else if (tamanho == 20) {
			if (contInf > 5 && contInf <= 10) {
				tamanho = 15;
			} else if (contInf > 10 && contInf <= 15) {
				tamanho = 10;
			} else if (contInf > 15 && contInf <= 20) {
				tamanho = 6;
			}
			if (contSup > 5 && contSup <= 10) {
				tamanho = 15;
			} else if (contSup > 10 && contSup <= 15) {
				tamanho = 10;
			} else if (contSup > 15 && contSup <= 20) {
				tamanho = 6;
			}
		} else if (tamanho == 25) {
			if (contInf > 5 && contInf <= 10) {
				tamanho = 20;
			} else if (contInf > 10 && contInf <= 15) {
				tamanho = 15;
			} else if (contInf > 15 && contInf <= 20) {
				tamanho = 10;
			} else if (contInf > 20 && contInf <= 25) {
				tamanho = 6;
			}
			if (contSup > 5 && contSup <= 10) {
				tamanho = 20;
			} else if (contSup > 10 && contSup <= 15) {
				tamanho = 15;
			} else if (contSup > 15 && contSup <= 20) {
				tamanho = 10;
			} else if (contSup > 20 && contSup <= 25) {
				tamanho = 6;
			}
		} else {
			if (contInf > 5 && contInf <= 10) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.8)).intValueExact();
			} else if (contInf > 10 && contInf <= 15) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.65)).intValueExact();
			} else if (contInf > 15 && contInf <= 20) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.5)).intValueExact();
			} else if (contInf > 20 && contInf <= 25) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.35)).intValueExact();
			} else if (contInf > 25 && contInf <= 30) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.2)).intValueExact();
			}
			if (contSup > 5 && contSup <= 10) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.8)).intValueExact();
			} else if (contSup > 10 && contSup <= 15) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.65)).intValueExact();
			} else if (contSup > 15 && contSup <= 20) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.5)).intValueExact();
			} else if (contSup > 20 && contSup <= 25) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.35)).intValueExact();
			} else if (contSup > 25 && contSup <= 30) {
				tamanho = new BigDecimal(Math.ceil(tamanho * 0.2)).intValueExact();
			}
		}
		return tamanho;
	}

	public ArrayList<Double> getQtdeDesvHist(int id, int tamanho) {
		GerenciadorDeConexao sqlServer = null;
		ArrayList<Double> max;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			max = obsDAO.getQtdeDesvHist(id, tamanho);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return max;
	}

	public static boolean isNumeric(String str) {
		for (char c : str.toCharArray()) {
			if (!Character.isDigit(c))
				return false;
		}
		return true;
	}

	public void updateTamanhoAmostraBasePeloID(int idTB, int tamanho) {
		GerenciadorDeConexao sqlServer = null;
		int status = 0;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO obsDAO = sqlServer.getObjetoBase();
			obsDAO.updateTamanhoAmostraBasePeloID(idTB, tamanho);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public double getQtdeRegBaseNSafrada(int idTB) {
		GerenciadorDeConexao sqlServer = null;
		double qtde = 0;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			qtde = obsDAO.getQtdeRegBaseNSafrada(idTB);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return qtde;
	}

	private String[] getLoginSAS() {
		GerenciadorDeConexao sqlServer = null;
		String[] login = new String[2];

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO bDAO = sqlServer.getObjetoBase();
			login = bDAO.getLoginSAS();
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return login;
	}

	public Resposta inserirColunas(List<ColunaTabela> colunas, int idTabela, String matricula) {

		Resposta resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resposta = baseDAO.inserirColunas(colunas, idTabela, matricula);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return resposta;

	}

	private int inserirTabela(Base obj, String matricula) {
		int resposta;

		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resposta = baseDAO.inserirTabela(obj, matricula); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return resposta;
	}

	public int checarSeBaseExiste(String nomeBase) {
		int resposta;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			BaseDAO baseDAO = sqlServer.getObjetoBase();
			resposta = baseDAO.checarSeBaseExiste(nomeBase); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar();
			}
		}		

		return resposta;
	}

	public boolean jaExecutouQualidade(int idTB) {

		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer =  null;
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.jaExecutouQualidade(idTB); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return isreprocessamento;
	}

	public boolean isReprocessamento(Base base, String nomeBase, String dataModificacao, double nobs) {

		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.isReprocessamento(base, nomeBase, dataModificacao, nobs); // resposta sobre a inser��o
			sqlServer.encerrar(); // fechando a conex�o com o banco
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return isreprocessamento;
	}
	
	public int isReprocessamentoDelete(Base base, String nomeBase, String dataModificacao, double nobs) {
		int isreprocessamento = 0;
		GerenciadorDeConexao sqlServer = null;
		
		try {
			
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.isReprocessamentoDelete(base, nomeBase, dataModificacao, nobs); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return isreprocessamento;
	}

	public boolean existeNotificacaoIntegridade(String campo, String nomeBase, String dataModificacao) {
		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.existeNotificacaoIntegridade(campo, nomeBase, dataModificacao); // resposta sobre a
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}		

		return isreprocessamento;
	}

	public boolean existeNotificacaoDuplicidade(String campo, String nomeBase, String dataModificacao) {
		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.existeNotificacaoDuplicidade(campo, nomeBase, dataModificacao); // resposta sobre a
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}		
		return isreprocessamento;
	}

	public boolean existeNotificacaoDominio(String campo, String nomeBase, String dataModificacao) {
		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.existeNotificacaoDominio(campo, nomeBase, dataModificacao); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar();
			}
		}		

		return isreprocessamento;
	}

	public boolean existeNotificacaoMissing(String campo, String nomeBase, String dataModificacao) {
		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.existeNotificacaoMissing(campo, nomeBase, dataModificacao); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}		

		return isreprocessamento;
	}

	public boolean existeNotificacaoRange(String campo, String nomeBase, String dataModificacao) {
		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.existeNotificacaoRange(campo, nomeBase, dataModificacao); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}		

		return isreprocessamento;
	}

	public void inserirNotificacaoRange(Base base, String nomeBase, String nomeCampo, String qtdeRangePorc,
			String qtdeRange, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoRange(base, nomeBase, nomeCampo, qtdeRangePorc, qtdeRange, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void inserirNotificacaoIntegridade(Base base, String nomeBase, String nomeCampo, String tipoCadastro,
			int tamanhoCadastro, String tipoAtual, int tamanhoAtual, String tipoErro, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoIntegridade(base, nomeBase, nomeCampo, tipoCadastro, tamanhoCadastro, tipoAtual,
					tamanhoAtual, tipoErro, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void inserirNotificacaoDuplicidade(Base base, String nomeBase, String nomeCampo, String qtdeDupPorc,
			String qtdeDup, String qtdeInfoDup, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoDuplicidade(base, nomeBase, nomeCampo, qtdeDupPorc, qtdeDup, qtdeInfoDup,
					dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void inserirNotificacaoDominio(Base base, String nomeBase, String nomeCampo, String qtdeDomPorc,
		String qtdeDom, String valoresDominio, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoDominio(base, nomeBase, nomeCampo, qtdeDomPorc, qtdeDom, valoresDominio,
					dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public void inserirNotificacaoMissing(Base base, String nomeBase, String nomeCampo, String qtdeMisPorc,
			String qtdeMis, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoMissing(base, nomeBase, nomeCampo, qtdeMisPorc, qtdeMis, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void inserirNotificacaoPSI(int idTB, String nomeBase, String campo, double psi, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoPSI(idTB, nomeBase, campo, psi, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}

	public boolean jaExisteAmostragem(int idTB, String nomeBase, String dataModificacao) {
		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			ObservacaoDAO notiDAO = sqlServer.getObjetoObs();
			isreprocessamento = notiDAO.jaExisteAmostragem(idTB, nomeBase, dataModificacao); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}

		return isreprocessamento;
	}
	
	public void inserirNotificacaoObservacao(int idTB, String nomeBase, ObservacaoDiario nobs, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoObservacao(idTB, nomeBase, nobs, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public void inserirNotificacaoObservacaoHist(int idTB, String nomeBase, Observacao nobs, String dtModificacao) {
		GerenciadorDeConexao sqlServer = null;

		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			NotificacaoDAO obsDAO = sqlServer.getObjetoNotificacaoDAO();
			obsDAO.inserirNotificacaoObservacaoHist(idTB, nomeBase, nobs, dtModificacao);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
	public boolean existeJustificativaObservacao(int idTB, String nomeBase, String dataModificacao) {
		
		boolean isreprocessamento = false;
		GerenciadorDeConexao sqlServer = null;
		try {
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar(); // abrindo a conex�o
			NotificacaoDAO notiDAO = sqlServer.getObjetoNotificacaoDAO();
			isreprocessamento = notiDAO.existeJustificativaObservacao(idTB, nomeBase, dataModificacao); // resposta sobre a inser��o
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar();
			}
		}		

		return isreprocessamento;
	}
}
