package backgroundProcesses;

import java.sql.*;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.microsoft.sqlserver.jdbc.*;

@WebListener
public class ScheduleBases implements ServletContextListener {

		@Override
		public void contextInitialized(ServletContextEvent arg0) {
			System.out.println("entrei no schedule valendo!");
			Calendar today = Calendar.getInstance();
			today.set(Calendar.HOUR_OF_DAY,20);
			today.set(Calendar.MINUTE, 00);
			today.set(Calendar.SECOND, 0);
			/*
			// creating timer task, timer
			Timer timer = new Timer();
			tarefaDiaria td  = new tarefaDiaria();
			
			// scheduling the task at fixed rate delay
			timer.scheduleAtFixedRate(td,today.getTime(), TimeUnit.MILLISECONDS.convert(1, TimeUnit.DAYS));
			*/
		}
	
	
	
		@Override
		public void contextDestroyed(ServletContextEvent arg0) {
			
				
		}        

}

