package DAO;

import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.SQLException; 
import java.util.logging.Level; 
import java.util.logging.Logger;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource; 


public class GerenciadorDeConexao_old implements IGerenciadorDeConexao {

	private Connection conexao;
	private tabelaXDAO tbX;
	private BaseDAO base;
	private ObservacaoDAO obs;
	private RegraDAO regra;
	private NotificacaoDAO notificacao;
	
	//private JdbcClienteDao clienteDAO
	
	public GerenciadorDeConexao_old() {
		//tbX = new tabelaXDAO(conexao);
		//base = new BaseDAO(conexao);
	}
	public void iniciar() throws DAOException
	{
		try 
		{
			SQLServerDataSource ds = new SQLServerDataSource();
			ds.setIntegratedSecurity(true);
			ds.setServerName("10.243.153.153");
			ds.setPortNumber(1434); 
			ds.setDatabaseName("DGDD000");
			conexao = ds.getConnection();
			conexao.setAutoCommit(false);
			
			tbX = new tabelaXDAO(conexao);
			base = new BaseDAO(conexao);
			obs = new ObservacaoDAO(conexao);
			regra = new RegraDAO(conexao);
			notificacao = new NotificacaoDAO(conexao);
			
			System.out.println("conectado com sucesso!1234");
		}
		catch(Exception ex)
		{
			throw new DAOException("Ocorreu um erro ao conectar ao banco de dados: " + ex.getMessage()); 
		}
		
	}
	
	public tabelaXDAO getObjetoX() {
		return tbX;
	}
	
	public BaseDAO getObjetoBase() {
		return base;
	}
	
	public ObservacaoDAO getObjetoObs() {
		return obs;
	}
	
	public RegraDAO getObjetoRegraDAO() {
		return regra;
	}
	
	public NotificacaoDAO getObjetoNotificacaoDAO() {
		return notificacao;
	}
	
	public Connection getConnection() {
		return conexao;
	}
	 @Override
	    public void encerrar() 
	    {
	        try {
	            if(!conexao.isClosed())
	                conexao.close();
	        } catch (SQLException ex) {
	            
	        }
	    }

	    @Override
	    public void confirmarTransacao() {
	        try{
	            conexao.commit();
	        }catch (SQLException ex){
	            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
	        }
	    }

	    @Override
	    public void abortarTransacao() {
	        try{
	            conexao.rollback();
	        }catch(SQLException ex){
	        
	            throw new DAOException("Ocorreu um erro ao abortar a opera��o."); //To change body of generated methods, choose Tools | Templates.
	       
	        }
	    }
	    
}
