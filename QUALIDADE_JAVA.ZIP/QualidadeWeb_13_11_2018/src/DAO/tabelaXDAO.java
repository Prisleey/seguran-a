package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.ModeloX;

//Exemplo de conex�o em uma tabela X

public class tabelaXDAO {
	
	private Connection conexao;
	
	public tabelaXDAO(Connection conexao){
        this.conexao = conexao;
    }
	
	public String inserir(ModeloX obj) {
		int id;
		id = getProximoId();
		if(id == 0) {
			return "Incapaz de retornar o proximo ID da tabela";
		}
		String sql;
		sql = "Insert into teste"
				+ "(colunaId, colunaDesc, colunaVal)"
				+ "values (?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			ps.setString(2, obj.getDesc());
			ps.setFloat(3, obj.getVal());
			ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	            //throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
	        	conexao.rollback();
	        	return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }
			return "Registro inserido com sucesso!";
			
		}catch(Exception ex) {
			//throw new DAOException("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
			return "Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage();
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
			
		
	}
	
	
	public String deletar(int id) {
		String sql;
		sql = "delete from teste "
				+ "where colunaId = ? ";
		PreparedStatement ps = null;
		try {
				ps = conexao.prepareStatement(sql); 
				ps.setInt(1, id);
				ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	            //throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
	        	conexao.rollback();
	        	return "Ocorreu um erro ao deletar o registro" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }
			return "Registro deletado com sucesso!";
			
		}catch(Exception ex) {
			//throw new DAOException("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
			return "Ocorreu um erro ao deletar o registro na tabela Teste: " + ex.getMessage();
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
			
		
	}
	
	public String atualizar(ModeloX obj) {
		String sql;
		sql = "update teste "
				+ "set colunaDesc = ?, "
				+ "colunaVal = ? "
				+ "where colunaId = ? ";
		PreparedStatement ps = null;
		try {
				ps = conexao.prepareStatement(sql); 
				ps.setString(1, obj.getDesc());
				ps.setFloat(2, obj.getVal());
				ps.setInt(3, obj.getId());
				ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	            //throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
	        	conexao.rollback();
	        	return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }
			return "Registro atualizado com sucesso!";
			
		}catch(Exception ex) {
			//throw new DAOException("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
			return "Ocorreu um erro ao atualizar o registro na tabela Teste: " + ex.getMessage();
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
			
		
	}
	
	public int getProximoId() {
		String sql;
		sql="Select "
				+ "max(colunaId)+1 as id "
				+ "from teste ";
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				int id;
				id = rs.getInt("id");
				return id;
			}
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro no select do objeto");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
		return 0;
	}
	public ModeloX objetoPorId(int id) {
		String sql;
		sql="Select "
				+ "colunaId, "
				+ "colunaDesc, "
				+ "colunaVal "
				+ "from teste "
				+ "where colunaId= ? ";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1,id);
			//Statement stmt = conexao.createStatement();
			rs = ps.executeQuery();
			if(rs.next()) {
				ModeloX mx;
				mx = new ModeloX();
				mx.setId(rs.getInt("colunaId"));
				mx.setDesc(rs.getString("colunaDesc"));
				mx.setVal(rs.getFloat("colunaVal"));
				return mx;
			}
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro no select do objeto: " + ex.getMessage());
			//System.out.println("Ocorreu um erro no select do objeto" + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
		return null;
	}
	
	public List<ModeloX> listarTodos(){
		List<ModeloX> listaObjetos = new ArrayList();
		String sql;
		ModeloX mx;
		
		sql="Select "
				+ "colunaId, "
				+ "colunaDesc, "
				+ "colunaVal "
				+ "from teste ";
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

				while(rs.next()) {
					mx = new ModeloX();
					mx.setId(rs.getInt("colunaId"));
					mx.setDesc(rs.getString("colunaDesc"));
					mx.setVal(rs.getFloat("colunaVal"));
					listaObjetos.add(mx);
				}
				return listaObjetos;

			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar os registros: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
		

	}


}
