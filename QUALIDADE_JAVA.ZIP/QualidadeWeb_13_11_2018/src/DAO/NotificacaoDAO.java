package DAO;

import java.io.FileWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import model.Base;
import model.Notificacao;
import model.Observacao;
import model.ObservacaoDiario;
import model.StatusBases;

public class NotificacaoDAO {

	private Connection conexao;

	public NotificacaoDAO(Connection conexao) {
		this.conexao = conexao;
	}

	// m�todo que insere uma notificac
	public void inserirNotificacao(int idCol, int idRegra, String nomeBase, String msg) {
		String sql;

		String dataDeHoje = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
		String hojeDB = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

		sql = "Insert into NOTIFICACOES" + "(ID_COLUNA, ID_REGRA, NOME_BASE, MENSAGEM, DATA_NOTIFICACAO, DATE_NOTIF) "
				+ "values (?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idCol);
			ps.setInt(2, idRegra);
			ps.setString(3, nomeBase);
			ps.setString(4, msg);
			ps.setString(5, dataDeHoje);
			ps.setString(6, hojeDB);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirStatusBases(List<StatusBases> statusBases) {
		String sql;

		sql = "insert into status_bases(ID_TB, NOME_BASE, STATUS_OBSERVACAO, STATUS_INTEGRIDADE, STATUS_DUPLICIDADE,\r\n"
				+ "STATUS_DOMINIO, STATUS_MISSING, STATUS_RANGE, STATUS_PSI, DATA_MODIFICACAO, STATUS_REPROCESSAMENTO, DATA_QUALIDADE, PERIODICIDADE, STATUS_EMAIL)\r\n"
				+ "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement ps = null;
		for (StatusBases bases : statusBases) {

			try {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, bases.getIdTb());
				ps.setString(2, bases.getNomeBase());
				ps.setInt(3, bases.getStatusObservacao());
				ps.setInt(4, bases.getStatusIntegridade());
				ps.setInt(5, bases.getStatusDuplicidade());
				ps.setInt(6, bases.getStatusDominio());
				ps.setInt(7, bases.getStatusMissing());
				ps.setInt(8, bases.getStatusRange());
				ps.setInt(9, bases.getStatusPSI());
				ps.setString(10, bases.getDataModificacao());
				ps.setInt(11, bases.getStatusReprocessamento());
				ps.setString(12, bases.getDataQualidade());
				ps.setString(13, bases.getPeriodicidade());
				ps.setInt(14, 0);
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																						// methods, choose Tools |
																						// Templates.

					// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
					// change body of generated methods, choose Tools | Templates.
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir os Status das bases: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	}

	// pega as notifica��es baseado em uma data "x" e nome "y" para enviar os emails
	// no final do processo
	public List<Notificacao> getNotificacaoPorData(String data, String nomeBase) {
		String sql;
		List<Notificacao> notificacoes = new ArrayList();
		Notificacao notif;
		sql = "select " + "NOME_BASE, t2.NOME_COLUNA, t3.DESCRICAO_REGRA, MENSAGEM, DATA_NOTIFICACAO "
				+ "from NOTIFICACOES t1 " + "INNER JOIN coluna_tabela t2 " + "ON t1.ID_COLUNA = t2.ID_COLUNA "
				+ "INNER JOIN REGRAS_QUALIDADE t3 " + "ON t1.ID_REGRA = t3.ID_REGRA " + "WHERE "
				+ "t1.NOME_BASE = ? AND " + "t1.DATA_NOTIFICACAO = ? " + "GROUP BY " + "t1.NOME_BASE, "
				+ "t2.NOME_COLUNA, " + "t3.DESCRICAO_REGRA, " + "t1.DATA_NOTIFICACAO, " + "t1.MENSAGEM " + "ORDER by "
				+ "NOME_BASE, " + "DATA_NOTIFICACAO, " + "NOME_COLUNA, " + "DESCRICAO_REGRA";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, data);
			rs = ps.executeQuery();
			while (rs.next()) {
				notif = new Notificacao();
				notif.setNomeBase(rs.getString("NOME_BASE"));
				notif.setNomeColuna(rs.getString("NOME_COLUNA"));
				notif.setDescricaoRegra(rs.getString("DESCRICAO_REGRA"));
				notif.setMensagem(rs.getString("MENSAGEM"));
				notif.setDataNotificacao(rs.getString("DATA_NOTIFICACAO"));
				notificacoes.add(notif);
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao checar se a tabela j� existe. " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return notificacoes;
	}

	// pega o nome das bases que tem notificacao por data
	public ArrayList<String> getNomeBasesNotificacao(String data) {
		String sql;
		ArrayList<String> nomesBases = new ArrayList();
		sql = "select DISTINCT NOME_BASE FROM NOTIFICACOES WHERE DATA_NOTIFICACAO = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, data);
			rs = ps.executeQuery();
			while (rs.next()) {
				nomesBases.add(rs.getString("NOME_BASE"));
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao checar se a tabela j� existe. " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return nomesBases;
	}

	public int getIDPeloNomeBase(String nomeBase) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int id = 0;

		sql = "Select ID_TB from TABELA_QUALIDADE2 WHERE NOME_BASE = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			rs = ps.executeQuery();

			if (rs.next()) {
				id = rs.getInt("ID_TB");
			}

			return id;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<List> getQtdeNotificacaoPorIDRegra(int idRegra, String nomeBase, String dtIni, String dtFim) {
		List<Object> metricas = new ArrayList<Object>();
		ArrayList<List> listaNotifPorRegra = new ArrayList<List>();
		String sql;

		int idTB = 0;
		idTB = getIDPeloNomeBase(nomeBase);

		if ((idRegra > 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtFim != "")) {
			sql = "select distinct noti.ID_REGRA, Count(noti.ID_REGRA) as QTDE_NOTIF_REGRA  \r\n"
					+ "	from (select distinct c.ID_REGRA, tab.ID_TB, c.ID_COLUNA, tab.NOME_BASE\r\n"
					+ "		from (select distinct t1.ID_TB, t1.ID_COLUNA, t2.ID_REGRA from coluna_tabela t1\r\n"
					+ "					INNER JOIN notificacoes t2\r\n"
					+ "					ON(t1.ID_COLUNA = t2.ID_COLUNA) where t1.ID_TB = ?)c \r\n"
					+ "		inner join TABELA_QUALIDADE2 tab\r\n" + "		ON(c.ID_TB = tab.ID_TB)\r\n"
					+ "		)aux INNER JOIN notificacoes noti \r\n"
					+ "		ON(aux.ID_REGRA = noti.ID_REGRA and aux.ID_COLUNA = noti.ID_COLUNA)\r\n"
					+ "		where noti.DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103) AND noti.ID_REGRA = ?\r\n"
					+ "GROUP BY noti.ID_REGRA";
		} else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtFim != "")) {
			sql = "select distinct noti.ID_REGRA, Count(noti.ID_REGRA) as QTDE_NOTIF_REGRA  \r\n"
					+ "	from (select distinct c.ID_REGRA, tab.ID_TB, c.ID_COLUNA, tab.NOME_BASE\r\n"
					+ "		from (select distinct t1.ID_TB, t1.ID_COLUNA, t2.ID_REGRA from coluna_tabela t1\r\n"
					+ "					INNER JOIN notificacoes t2\r\n"
					+ "					ON(t1.ID_COLUNA = t2.ID_COLUNA) where t1.ID_TB = ?)c \r\n"
					+ "		inner join TABELA_QUALIDADE2 tab\r\n" + "		ON(c.ID_TB = tab.ID_TB)\r\n"
					+ "		)aux INNER JOIN notificacoes noti \r\n"
					+ "		ON(aux.ID_REGRA = noti.ID_REGRA  and aux.ID_COLUNA = noti.ID_COLUNA)\r\n"
					+ "		where noti.DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103)\r\n"
					+ "GROUP BY noti.ID_REGRA";
		} else if ((idRegra < 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtFim != "")) {
			sql = "select distinct noti.ID_REGRA, Count(noti.ID_REGRA) as QTDE_NOTIF_REGRA  \r\n"
					+ "	from (select distinct c.ID_REGRA, tab.ID_TB, c.ID_COLUNA, tab.NOME_BASE\r\n"
					+ "		from (select distinct t1.ID_TB, t1.ID_COLUNA, t2.ID_REGRA from coluna_tabela t1\r\n"
					+ "					INNER JOIN notificacoes t2\r\n"
					+ "					ON(t1.ID_COLUNA = t2.ID_COLUNA))c \r\n"
					+ "		inner join TABELA_QUALIDADE2 tab\r\n" + "		ON(c.ID_TB = tab.ID_TB)\r\n"
					+ "		)aux INNER JOIN notificacoes noti \r\n"
					+ "		ON(aux.ID_REGRA = noti.ID_REGRA  and aux.ID_COLUNA = noti.ID_COLUNA)\r\n"
					+ "		where noti.DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103)\r\n"
					+ "GROUP BY noti.ID_REGRA";
		} else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtFim == "")) {
			sql = "select distinct noti.ID_REGRA, Count(noti.ID_REGRA) as QTDE_NOTIF_REGRA \r\n"
					+ "from (select distinct c.ID_REGRA, tab.ID_TB, c.ID_COLUNA, tab.NOME_BASE\r\n"
					+ "		from (select t1.ID_TB, t1.ID_COLUNA, t2.ID_REGRA \r\n"
					+ "			from coluna_tabela t1\r\n" + " INNER JOIN notificacoes t2\r\n"
					+ "			ON(t1.ID_COLUNA = t2.ID_COLUNA)  where t1.ID_TB = ?)c\r\n"
					+ "		LEFT join TABELA_QUALIDADE2 tab\r\n" + "		ON(c.ID_TB = tab.ID_TB))aux \r\n"
					+ "	LEFT JOIN notificacoes noti\r\n"
					+ " ON(noti.ID_REGRA = aux.ID_REGRA and aux.ID_COLUNA = noti.ID_COLUNA)\r\n"
					+ "GROUP BY noti.ID_REGRA";
		} else if ((idRegra > 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtFim != "")) {
			sql = "select distinct ID_REGRA, Count(ID_REGRA) as QTDE_NOTIF_REGRA from notificacoes "
					+ "where ID_REGRA = ? and DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103) GROUP BY ID_REGRA";
		} else if ((idRegra > 0) && (nomeBase == null || nomeBase == "") && (dtIni == null || dtFim == "")) {
			sql = "select distinct ID_REGRA, Count(ID_REGRA) as QTDE_NOTIF_REGRA from notificacoes where ID_REGRA = ? GROUP BY ID_REGRA";
		} else if ((idRegra > 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtFim == "")) {
			sql = "select distinct noti.ID_REGRA, Count(noti.ID_REGRA) as QTDE_NOTIF_REGRA  \r\n"
					+ "	from (select distinct c.ID_REGRA, tab.ID_TB, c.ID_COLUNA, tab.NOME_BASE\r\n"
					+ "		from (select distinct t1.ID_TB, t1.ID_COLUNA, t2.ID_REGRA from coluna_tabela t1\r\n"
					+ "					INNER JOIN notificacoes t2\r\n"
					+ "					ON(t1.ID_COLUNA = t2.ID_COLUNA)  where t1.ID_TB = ?)c \r\n"
					+ "		inner join TABELA_QUALIDADE2 tab\r\n" + "		ON(c.ID_TB = tab.ID_TB)\r\n"
					+ "		)aux INNER JOIN notificacoes noti \r\n"
					+ "		ON(aux.ID_REGRA = noti.ID_REGRA and aux.ID_COLUNA = noti.ID_COLUNA)\r\n"
					+ "		where noti.ID_REGRA = ?\r\n" + "GROUP BY noti.ID_REGRA";
		} else if ((idRegra < 0) && (nomeBase == null || nomeBase == "") && (dtIni == null || dtFim == "")) {
			sql = "Select ID_REGRA, Count(ID_REGRA) as QTDE_NOTIF_REGRA FROM NOTIFICACOES" + " GROUP BY ID_REGRA";
		} else {
			sql = "Select ID_REGRA, Count(ID_REGRA) as QTDE_NOTIF_REGRA FROM NOTIFICACOES GROUP BY ID_REGRA";
		}

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {

			if ((idRegra > 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtFim != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idTB);
				ps.setString(2, dtIni);
				ps.setString(3, dtFim);
				ps.setInt(4, idRegra);
				rs = ps.executeQuery();
			} else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtFim != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idTB);
				ps.setString(2, dtIni);
				ps.setString(3, dtFim);
				rs = ps.executeQuery();
			} else if ((idRegra < 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtFim != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, dtIni);
				ps.setString(2, dtFim);
				rs = ps.executeQuery();
			} else if ((idRegra > 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtFim != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idRegra);
				ps.setString(2, dtIni);
				ps.setString(3, dtFim);
				rs = ps.executeQuery();
			} else if ((idRegra > 0) && (nomeBase == null || nomeBase == "") && (dtIni == null || dtFim == "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idRegra);
				rs = ps.executeQuery();
			} else if ((idRegra > 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtFim == "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idTB);
				ps.setInt(2, idRegra);
				rs = ps.executeQuery();
			} else if ((idRegra < 0) && (nomeBase == null || nomeBase == "") && (dtIni == null || dtFim == "")) {
				Statement stmt = conexao.createStatement();
				rs = stmt.executeQuery(sql);
			} else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtFim == "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idTB);
				rs = ps.executeQuery();
			} else {
				Statement stmt = conexao.createStatement();
				rs = stmt.executeQuery(sql);
			}

			while (rs.next()) {
				metricas = new ArrayList<Object>();
				metricas.add(rs.getInt("ID_REGRA"));
				metricas.add(rs.getInt("QTDE_NOTIF_REGRA"));
				listaNotifPorRegra.add(metricas);
			}

			return listaNotifPorRegra;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<List> getNomesMetricas() {
		List<Object> metricas = new ArrayList<Object>();
		ArrayList<List> listaNotifPorRegra = new ArrayList<List>();
		String sql;
		sql = "select distinct t1.ID_REGRA, DESCRICAO_REGRA from REGRAS_QUALIDADE t1 " + "INNER JOIN NOTIFICACOES t2 "
				+ "ON (t1.ID_REGRA = t2.ID_REGRA)";

		Statement stmt = null;
		ResultSet rs = null;
		try {

			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				metricas = new ArrayList<Object>();
				metricas.add(rs.getInt("ID_REGRA"));
				metricas.add(rs.getString("DESCRICAO_REGRA"));
				listaNotifPorRegra.add(metricas);
			}

			return listaNotifPorRegra;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public ArrayList<ArrayList<Object>> getQtdeBasesNotif(int idRegra, String nomeBase, String dtIni, String dtFim) {
		ArrayList<ArrayList<Object>> listaBasesNotif = new ArrayList<ArrayList<Object>>();
		ArrayList<Integer> bases = new ArrayList<Integer>();
		String sql_1;
		String sql_2;

		if (nomeBase == null || nomeBase == "") {

			if ((idRegra > 0) && (dtIni != null && dtIni != "")) {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + " from"
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes"
						+ "		 where ID_REGRA = ? AND DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))a"
						+ "		INNER JOIN " + "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) where tb_qua.ID_TB > 1"
						+ " ORDER BY 3 DESC";
			} else if ((idRegra < 0) && (dtIni != null && dtIni != "")) {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + "	 from"
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes"
						+ "		 where DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))a"
						+ "		INNER JOIN" + "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) where tb_qua.ID_TB > 1"
						+ " ORDER BY 3 DESC";
			} else if ((idRegra > 0) && (dtIni == null || dtIni == "")) {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + "	 from "
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes" + "		 where ID_REGRA = ?)a"
						+ "		INNER JOIN" + "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) where tb_qua.ID_TB > 1"
						+ " ORDER BY 3 DESC";
			} else {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + "	 from"
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes)a" + "		INNER JOIN"
						+ "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) where tb_qua.ID_TB > 1"
						+ " ORDER BY 3 DESC";
			}
			PreparedStatement ps = null;
			ResultSet rs = null;
		
			try {
				if ((idRegra > 0) && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql_2);
					ps.setInt(1, idRegra);
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
					rs = ps.executeQuery();
				} else if ((idRegra < 0) && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql_2);
					ps.setString(1, dtIni);
					ps.setString(2, dtFim);
					rs = ps.executeQuery();
				} else if ((idRegra > 0) && (dtIni == null || dtIni == "")) {
					ps = conexao.prepareStatement(sql_2);
					ps.setInt(1, idRegra);
					rs = ps.executeQuery();
				} else {
					Statement stmt = conexao.createStatement();
					rs = stmt.executeQuery(sql_2);
				}
				ArrayList<Object> row = new ArrayList<Object>();
				while (rs.next()) {
					if (rs.getInt("QTDE_BASES") > 0) {
						row = new ArrayList<Object>();
						row.add(rs.getString("NOME_BASE"));
						row.add(rs.getInt("QTDE_BASES"));
						row.add(rs.getInt("ID_TB"));
						listaBasesNotif.add(row);
					}
				}
				return listaBasesNotif;

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			int idTB = 0;
			idTB = getIDPeloNomeBase(nomeBase);

			if ((idRegra > 0) && (dtIni != null && dtIni != "")) {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + "	 from"
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes"
						+ "		 where ID_REGRA = ? AND DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))a"
						+ "		INNER JOIN" + "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) " + "where tb.ID_TB = ?";
			} else if ((idRegra < 0) && (dtIni != null && dtIni != "")) {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + "	 from"
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes"
						+ "		 where DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))a"
						+ "		INNER JOIN" + "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) " + "where tb.ID_TB = ?";
			} else if ((idRegra > 0) && (dtIni == null || dtIni == "")) {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + "	 from"
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes" + "		 where ID_REGRA = ?)a"
						+ "		INNER JOIN" + "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) " + "where tb.ID_TB = ?";
			} else {
				sql_2 = "select top 10 tb.ID_TB, NOME_BASE, tb.QTDE_BASES from (select distinct ID_TB, COUNT(ID_TB) as QTDE_BASES from"
						+ "	(select a.NOME_BASE, c.ID_TB" + "	 from"
						+ "		(select NOME_BASE, ID_COLUNA from notificacoes)a" + "		INNER JOIN"
						+ "		(select distinct t1.ID_TB, t1.ID_COLUNA from coluna_tabela t1"
						+ "		INNER JOIN notificacoes t2" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))c"
						+ "	ON(a.ID_COLUNA = c.ID_COLUNA))nome_ID" + "	GROUP BY ID_TB)tb "
						+ "Inner Join TABELA_QUALIDADE2 tb_qua " + "ON(tb.ID_TB = tb_qua.ID_TB) " + "where tb.ID_TB = ?";
			}
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				if ((idRegra > 0) && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql_2);
					ps.setInt(1, idRegra);
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
					ps.setInt(4, idTB);
					rs = ps.executeQuery();
				} else if ((idRegra < 0) && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql_2);
					ps.setString(1, dtIni);
					ps.setString(2, dtFim);
					ps.setInt(3, idTB);
					rs = ps.executeQuery();
				} else if ((idRegra > 0) && (dtIni == null || dtIni == "")) {
					ps = conexao.prepareStatement(sql_2);
					ps.setInt(1, idRegra);
					ps.setInt(2, idTB);
					rs = ps.executeQuery();
				} else {
					ps = conexao.prepareStatement(sql_2);
					ps.setInt(1, idTB);
					rs = ps.executeQuery();
				}
				ArrayList<Object> row = new ArrayList<Object>();
				while (rs.next()) {
					if (rs.getInt("QTDE_BASES") > 0) {
						row = new ArrayList<Object>();
						row.add(rs.getString("NOME_BASE"));
						row.add(rs.getInt("QTDE_BASES"));
						row.add(rs.getInt("ID_TB"));
						listaBasesNotif.add(row);
					}
				}
			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
			return listaBasesNotif;
		}
	}

	public ArrayList<List> getBasesNotificacao() {
		ArrayList<List> bases = new ArrayList<List>();
		String sql;

		sql = "select distinct t4.ID_TB as ID_TB, t4.NOME_BASE as NOME_BASE \r\n"
				+ "	from (select distinct t2.ID_TB \r\n" + "		from (select ID_COLUNA from notificacoes)t1\r\n"
				+ "		INNER JOIN coluna_tabela t2 \r\n" + "		ON(t1.ID_COLUNA = t2.ID_COLUNA))t3 \r\n"
				+ "	INNER JOIN TABELA_QUALIDADE2	T4\r\n" + "	ON(t3.ID_TB = t4.ID_TB)\r\n" + "	ORDER BY 2";

		Statement stmt = null;
		ResultSet rs = null;
		try {

			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				List row = new ArrayList<List>();
				row.add(rs.getInt("ID_TB"));
				row.add(rs.getString("NOME_BASE"));
				bases.add(row);
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public ArrayList<String[]> getMetricasNotificacao() {
		ArrayList<String[]> metricas = new ArrayList<String[]>();
		String sql;

		sql = "select distinct t2.ID_REGRA,t2.DESCRICAO_REGRA from notificacoes t1 "
				+ "INNER JOIN regras_qualidade t2 ON(t1.ID_REGRA = t2.ID_REGRA)";

		Statement stmt = null;
		ResultSet rs = null;
		try {

			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				String[] metricas_1 = new String[2];
				metricas_1[0] = String.valueOf(rs.getString("ID_REGRA"));
				metricas_1[1] = rs.getString("DESCRICAO_REGRA");
				metricas.add(metricas_1);
			}

			return metricas;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public ArrayList<ArrayList<Object>> getNotificacaopelaBase(String nomeBase) {
		ArrayList<ArrayList<Object>> bases = new ArrayList<ArrayList<Object>>();
		ArrayList<Object> row = new ArrayList<Object>();
		String sql;

		if (nomeBase.equals("0") || nomeBase == null || nomeBase.equals("")) {
			sql = "Select Count(ID_REGRA) as QTDE_NOTIF, ID_REGRA FROM NOTIFICACOES" + " GROUP BY ID_REGRA";
		} else {
			sql = "Select Count(ID_REGRA) as QTDE_NOTIF, ID_REGRA FROM NOTIFICACOES"
					+ " WHERE NOME_BASE LIKE ? GROUP BY ID_REGRA";
		}

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			if (nomeBase.equals("0") || nomeBase == null || nomeBase.equals("")) {
				Statement stmt = conexao.createStatement();
				rs = stmt.executeQuery(sql);
			} else {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, "%" + nomeBase + "%");
				rs = ps.executeQuery();
			}

			while (rs.next()) {
				row = new ArrayList<Object>();
				row.add(rs.getInt("ID_REGRA"));
				row.add(rs.getInt("QTDE_NOTIF"));
				bases.add(row);
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<String> getDataMinMaxNotificacoes() {
		ArrayList<String> bases = new ArrayList<String>();
		String sql;

		sql = "Select convert(varchar(255),MIN(convert(DATETIME, DATA_NOTIFICACAO, 103)),103) + ' ' + convert(varchar(255),MIN(convert(DATETIME, DATA_NOTIFICACAO, 103)),108) as Min, \r\n"
				+ "convert(varchar(255),MAX(convert(DATETIME, DATA_NOTIFICACAO, 103)),103) + ' ' + convert(varchar(255),MAX(convert(DATETIME, DATA_NOTIFICACAO, 103)),108) as Max \r\n"
				+ "FROM NOTIFICACOES\r\n" + "WHERE DATA_NOTIFICACAO <> '0'";

		PreparedStatement ps;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				bases.add(rs.getString("Min"));
				bases.add(rs.getString("Max"));
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public ArrayList<String> getDataMinMaxJustificativas() {
		ArrayList<String> bases = new ArrayList<String>();
		String sql;

		sql = "Select convert(varchar(255),MIN(convert(DATETIME, DATA_QUALIDADE, 103)),103) + ' ' + convert(varchar(255),MIN(convert(DATETIME, DATA_QUALIDADE, 103)),108) as Min,\r\n"
				+ "convert(varchar(255),MAX(convert(DATETIME, DATA_QUALIDADE, 103)),103) + ' ' + convert(varchar(255),MAX(convert(DATETIME, DATA_QUALIDADE, 103)),108) as Max\r\n"
				+ "FROM STATUS_BASES";

		PreparedStatement ps;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				bases.add(rs.getString("Min"));
				bases.add(rs.getString("Max"));
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public ArrayList<Notificacao> getBasesNotificacaoporData(String nmBase, String coluna, int idRegra, String dtIni,
			String dtFim) {
		ArrayList<Notificacao> bases = new ArrayList<Notificacao>();
		String sql = "";
		Notificacao notif;

		if (nmBase != "0" && !nmBase.equals("") && nmBase != null) {
			String[] bases_split = nmBase.split("_");
			nmBase = "";
			for (int i = 0; i < bases_split.length - 1; i++) {
				nmBase += bases_split[i] + "_";
			}
		}

		if (idRegra < 0) {
			if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna == "" || coluna == null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null) && (coluna == "" || coluna == null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where NOME_BASE like ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null) && (coluna != "" && coluna != null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where NOME_BASE like ? AND t3.NOME_COLUNA LIKE ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna != "" && coluna != null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where t3.NOME_COLUNA LIKE ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			}
		} else {
			if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna == "" || coluna == null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where t1.ID_REGRA = ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null) && (coluna == "" || coluna == null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where t1.ID_REGRA = ? AND  NOME_BASE like ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null) && (coluna != "" && coluna != null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where t1.ID_REGRA = ? AND  NOME_BASE like ? AND t3.NOME_COLUNA LIKE ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna != "" && coluna != null)) {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where t1.ID_REGRA = ? AND t3.NOME_COLUNA LIKE ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			} else {
				sql = "select t1.NOME_BASE, t2.DESCRICAO_REGRA, t3.NOME_COLUNA, t1.MENSAGEM, t1.DATA_NOTIFICACAO from notificacoes t1 INNER JOIN regras_qualidade t2 on (t1.ID_REGRA = t2.ID_REGRA) INNER JOIN coluna_tabela t3 on(t1.ID_COLUNA = t3.ID_COLUNA)"
						+ " Where t1.ID_REGRA = ? AND DATE_NOTIF BETWEEN ? AND ? Order by DATE_NOTIF DESC";
			}

		}
		System.out.println(sql);
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			if (idRegra < 0) {
				if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna == "" || coluna == null)) {
					ps.setString(1, dtIni);
					ps.setString(2, dtFim);
				} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null)
						&& (coluna == "" || coluna == null)) {
					ps.setString(1, "%" + nmBase + "%");
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
				} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null)
						&& (coluna != "" && coluna != null)) {
					ps.setString(1, "%" + nmBase + "%");
					ps.setString(2, "%" + coluna + "%");
					ps.setString(3, dtIni);
					ps.setString(4, dtFim);
				} else if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna != "" && coluna != null)) {
					ps.setString(1, "%" + coluna + "%");
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
				} else {
					ps.setString(1, dtIni);
					ps.setString(2, dtFim);
				}
			} else {
				if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna == "" || coluna == null)) {
					ps.setInt(1, idRegra);
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
				} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null)
						&& (coluna == "" || coluna == null)) {
					ps.setInt(1, idRegra);
					ps.setString(2, "%" + nmBase + "%");
					ps.setString(3, dtIni);
					ps.setString(4, dtFim);
				} else if ((nmBase != "0" && !nmBase.equals("") && nmBase != null)
						&& (coluna != "" && coluna != null)) {
					ps.setInt(1, idRegra);
					ps.setString(2, "%" + nmBase + "%");
					ps.setString(3, "%" + coluna + "%");
					ps.setString(4, dtIni);
					ps.setString(5, dtFim);
				} else if ((nmBase == "0" || nmBase.equals("") || nmBase == null) && (coluna != "" && coluna != null)) {
					ps.setInt(1, idRegra);
					ps.setString(2, "%" + coluna + "%");
					ps.setString(3, dtIni);
					ps.setString(4, dtFim);
				} else {
					ps.setInt(1, idRegra);
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
				}
			}
			rs = ps.executeQuery();

			while (rs.next()) {
				notif = new Notificacao();
				notif.setNomeBase(rs.getString("NOME_BASE"));
				notif.setNomeColuna(rs.getString("NOME_COLUNA"));
				notif.setDescricaoRegra(rs.getString("DESCRICAO_REGRA"));
				notif.setMensagem(rs.getString("MENSAGEM"));
				notif.setDataNotificacao(rs.getString("DATA_NOTIFICACAO"));
				bases.add(notif);
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public List<StatusBases> getBasesJustificativasporData(String dtIni, String dtFim) {
		List<StatusBases> bases = new ArrayList<StatusBases>();
		String sql = "";
		StatusBases status;

		if (dtIni == "" || dtIni == null) {
			sql = " select * from status_bases";
		} else {
			sql = " select * from status_bases \r\n"
					+ " where CONVERT(datetime, DATA_QUALIDADE, 103) > CONVERT(datetime, ?, 103) and\r\n"
					+ " CONVERT(datetime, DATA_QUALIDADE, 103) < CONVERT(datetime, ?, 103) Order by DATA_QUALIDADE DESC";
		}

		Statement stmt = null;
		ResultSet rs = null;

		System.out.println(sql);
		PreparedStatement ps;
		try {
			if (dtIni == "" || dtIni == null) {
				stmt = conexao.createStatement();
				rs = stmt.executeQuery(sql);
			} else {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, dtIni);
				ps.setString(2, dtFim);
				rs = ps.executeQuery();
			}

			while (rs.next()) {
				status = new StatusBases();
				status.setIdTb(rs.getInt("ID_TB"));
				status.setNomeBase(rs.getString("NOME_BASE"));
				status.setStatusObservacao(rs.getInt("STATUS_OBSERVACAO"));
				status.setStatusIntegridade(rs.getInt("STATUS_INTEGRIDADE"));
				status.setStatusDuplicidade(rs.getInt("STATUS_DUPLICIDADE"));
				status.setStatusDominio(rs.getInt("STATUS_DOMINIO"));
				status.setStatusMissing(rs.getInt("STATUS_MISSING"));
				status.setStatusRange(rs.getInt("STATUS_RANGE"));
				status.setStatusPSI(rs.getInt("STATUS_PSI"));
				status.setPeriodicidade(rs.getString("PERIODICIDADE"));
				status.setDataModificacao(rs.getString("DATA_MODIFICACAO"));
				status.setStatusReprocessamento(rs.getInt("STATUS_REPROCESSAMENTO"));
				status.setDataQualidade(rs.getString("DATA_QUALIDADE"));
				status.setStatusEmail(rs.getInt("STATUS_EMAIL"));
				status.setIdItemSP(rs.getInt("ID_ITEM_SHAREPOINT"));
				if (status.getStatusEmail() == 0) {
					if (status.getStatusObservacao() == 1 || status.getStatusDominio() == 1
							|| status.getStatusDuplicidade() == 1 || status.getStatusIntegridade() == 1
							|| status.getStatusMissing() == 1 || status.getStatusPSI() == 1
							|| status.getStatusRange() == 1) {
						status.setStatusBase(1);
					} else {
						status.setStatusBase(0);
					}
				} else {
					status.setStatusBase(-1);
				}
				bases.add(status);
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public ArrayList<List> getNomesColunas() {
		List<Object> colunas = new ArrayList<Object>();
		ArrayList<List> listacoluna = new ArrayList<List>();
		String sql;
		sql = "select distinct t1.ID_COLUNA, NOME_COLUNA from coluna_tabela t1 " + "INNER JOIN NOTIFICACOES t2 "
				+ "ON (t1.ID_COLUNA = t2.ID_COLUNA)";

		Statement stmt = null;
		ResultSet rs = null;
		try {

			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				colunas = new ArrayList<Object>();
				colunas.add(rs.getInt("ID_COLUNA"));
				colunas.add(rs.getString("NOME_COLUNA"));
				listacoluna.add(colunas);
			}

			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public ArrayList<ArrayList<Object>> getQtdeNotifAreas(int idRegra, String nomeBase, String dtIni, String dtFim) {

		ArrayList<Object> row = new ArrayList<Object>();
		ArrayList<ArrayList<Object>> areas = new ArrayList<ArrayList<Object>>();

		String sql = "";

		if (idRegra == 0) {
			if ((nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA "
						+ "from (select t1.NOME_SETOR, b.ID_COLUNA from setores t1 "
						+ "INNER JOIN (select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA "
						+ "from TABELA_QUALIDADE2 t1 INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN notificacoes t2 "
						+ "ON(t2.ID_COLUNA = c.ID_COLUNA) where t2.DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103) "
						+ "group by NOME_SETOR";
			} else if ((nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA "
						+ "from (select t1.NOME_SETOR, b.ID_COLUNA from setores t1 "
						+ "INNER JOIN (select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA "
						+ "from TABELA_QUALIDADE2 t1 INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB))b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN notificacoes t2 "
						+ "ON(t2.ID_COLUNA = c.ID_COLUNA) where t2.DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103) group by NOME_SETOR";
			} else if ((nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA "
						+ "from (select t1.NOME_SETOR, b.ID_COLUNA from setores t1 "
						+ "INNER JOIN (select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA "
						+ "from TABELA_QUALIDADE2 t1 INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN notificacoes t2 "
						+ "ON(t2.ID_COLUNA = c.ID_COLUNA) group by NOME_SETOR";
			} else if ((nomeBase == null || nomeBase == "") && (dtIni == null || dtIni == "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA "
						+ "from (select t1.NOME_SETOR, b.ID_COLUNA from setores t1 "
						+ "INNER JOIN (select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA "
						+ "from TABELA_QUALIDADE2 t1 INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB))b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN notificacoes t2 "
						+ "ON(t2.ID_COLUNA = c.ID_COLUNA) group by NOME_SETOR";
			}
		} else {
			if ((nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA from "
						+ "(select t1.NOME_SETOR, b.ID_COLUNA from setores t1 INNER JOIN "
						+ "(select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA from TABELA_QUALIDADE2 t1 "
						+ "INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN (select t2.ID_REGRA,t2.DESCRICAO_REGRA, t1.ID_COLUNA "
						+ "from notificacoes t1 INNER JOIN regras_qualidade t2 ON(t2.ID_REGRA = t1.ID_REGRA) where DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))t3 "
						+ "ON(t3.ID_COLUNA = c.ID_COLUNA) where t3.ID_REGRA = ? " + "group by c.NOME_SETOR";
			} else if ((nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA from "
						+ "(select t1.NOME_SETOR, b.ID_COLUNA from setores t1 INNER JOIN "
						+ "(select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA from TABELA_QUALIDADE2 t1 "
						+ "INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB))b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN (select t2.ID_REGRA,t2.DESCRICAO_REGRA, t1.ID_COLUNA "
						+ "from notificacoes t1 INNER JOIN regras_qualidade t2 ON(t2.ID_REGRA = t1.ID_REGRA) where DATE_NOTIF BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))t3 "
						+ "ON(t3.ID_COLUNA = c.ID_COLUNA) where t3.ID_REGRA = ? " + "group by c.NOME_SETOR";
			} else if ((nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA from "
						+ "(select t1.NOME_SETOR, b.ID_COLUNA from setores t1 INNER JOIN "
						+ "(select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA from TABELA_QUALIDADE2 t1 "
						+ "INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN (select t2.ID_REGRA,t2.DESCRICAO_REGRA, t1.ID_COLUNA "
						+ "from notificacoes t1 INNER JOIN regras_qualidade t2 ON(t2.ID_REGRA = t1.ID_REGRA))t3 "
						+ "ON(t3.ID_COLUNA = c.ID_COLUNA) where t3.ID_REGRA = ? " + "group by c.NOME_SETOR";
			} else if ((nomeBase == null || nomeBase == "") && (dtIni == null || dtIni == "")) {
				sql = "select c.NOME_SETOR, count(c.NOME_SETOR) as QTDE_NOTIF_AREA from "
						+ "(select t1.NOME_SETOR, b.ID_COLUNA from setores t1 INNER JOIN "
						+ "(select distinct t2.ID_TB, t1.ID_SETOR, t2.ID_COLUNA from TABELA_QUALIDADE2 t1 "
						+ "INNER JOIN coluna_tabela t2 ON(t1.ID_TB = t2.ID_TB))b "
						+ "ON(t1.ID_SETOR = b.ID_SETOR))c INNER JOIN (select t2.ID_REGRA,t2.DESCRICAO_REGRA, t1.ID_COLUNA "
						+ "from notificacoes t1 INNER JOIN regras_qualidade t2 ON(t2.ID_REGRA = t1.ID_REGRA))t3 "
						+ "ON(t3.ID_COLUNA = c.ID_COLUNA) where t3.ID_REGRA = ? " + "group by c.NOME_SETOR";
			}
		}
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			if (idRegra == 0) {
				if ((nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql);
					ps.setString(1, "%" + nomeBase + "%");
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
					rs = ps.executeQuery();
				} else if ((nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql);
					ps.setString(1, dtIni);
					ps.setString(2, dtFim);
					rs = ps.executeQuery();
				} else if ((nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")) {
					ps = conexao.prepareStatement(sql);
					ps.setString(1, "%" + nomeBase + "%");
					rs = ps.executeQuery();
				} else if ((nomeBase == null || nomeBase == "") && (dtIni == null || dtIni == "")) {
					Statement stmt = conexao.createStatement();
					rs = stmt.executeQuery(sql);
				}
			} else {
				if ((nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql);
					ps.setString(1, "%" + nomeBase + "%");
					ps.setString(2, dtIni);
					ps.setString(3, dtFim);
					ps.setInt(4, idRegra);
					rs = ps.executeQuery();
				} else if ((nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")) {
					ps = conexao.prepareStatement(sql);
					ps.setString(1, dtIni);
					ps.setString(2, dtFim);
					ps.setInt(3, idRegra);
					rs = ps.executeQuery();
				} else if ((nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")) {
					ps = conexao.prepareStatement(sql);
					ps.setString(1, "%" + nomeBase + "%");
					ps.setInt(2, idRegra);
					rs = ps.executeQuery();
				} else if ((nomeBase == null || nomeBase == "") && (dtIni == null || dtIni == "")) {
					ps = conexao.prepareStatement(sql);
					ps.setInt(1, idRegra);
					rs = ps.executeQuery();
				}
			}

			while (rs.next()) {
				row = new ArrayList<Object>();
				row.add(rs.getString("NOME_SETOR"));
				row.add(rs.getInt("QTDE_NOTIF_AREA"));
				areas.add(row);
			}

			return areas;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean isReprocessamento(Base base, String nomeBase, String dataModificacao, double nobs) {
		List<Base> listaBases = new ArrayList();
		String sql = "";
		String cont = "1";
		boolean isreprocessamento = false;

		sql = "select DT_FLAG from calculos_observacao"
					+ " where NOME_BASE = ? and ID_TB = ? and convert(Datetime,DT_FLAG,103) <= convert(Datetime,?,103)";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setInt(2, base.getIdTabela());
			ps.setString(3, dataModificacao);
			rs = ps.executeQuery();

			if (rs.next()) {
				if (!rs.getString("DT_FLAG").equals("")) {
					cont = rs.getString("DT_FLAG");
				}
			}

			if (!cont.equals("1")) {
				isreprocessamento = true;
			}
			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public int isReprocessamentoDelete(Base base, String nomeBase, String dataModificacao, double nobs) {
		List<Base> listaBases = new ArrayList();
		String sql = "";
		String cont = "1";
		int isreprocessamento = 0;
		
		String[] last = getLastObservacao(base.getIdTabela());
		
		if (last[0] != null && last[1] != null && last[2] != null) {
			
			if (last[1].equals(nomeBase) && Double.parseDouble(last[0]) == nobs && dataModificacao.equals(last[2])) {
				return -2;
			}
		}
		int direita = 0;

		if ((base.getPeriodicidade().equals("Mensal") || base.getPeriodicidade().equals("Trimestral")
				|| base.getPeriodicidade().equals("Semestral"))) {
			direita = Integer.parseInt(nomeBase.substring(nomeBase.length() - 6));
			sql = "select DT_FLAG from calculos_observacao \r\n"
					+ "where convert(int, right(NOME_BASE,6)) >= ? and ID_TB = ?";

		} else if ((base.getPeriodicidade().equals("Di�ria") || base.getPeriodicidade().equals("Semanal")
				|| base.getPeriodicidade().equals("Quinzenal"))) {
			direita = Integer.parseInt(nomeBase.substring(nomeBase.length() - 8));
			sql = "select DT_FLAG from calculos_observacao \r\n"
					+ "where convert(int, right(NOME_BASE,8)) >= ? and ID_TB = ?";
		}

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, direita);
			ps.setInt(2, base.getIdTabela());
			rs = ps.executeQuery();

			if (rs.next()) {
				if (!rs.getString("DT_FLAG").equals("")) {
					cont = rs.getString("DT_FLAG");
				}
			}

			if (!cont.equals("1")) {

				if ((base.getPeriodicidade().equals("Mensal") || base.getPeriodicidade().equals("Trimestral")
						|| base.getPeriodicidade().equals("Semestral"))) {
					sql = "delete from calculos_observacao where ID_TB = ? and"
							+ " convert(int, right(NOME_BASE,6)) >= ?";

				} else if ((base.getPeriodicidade().equals("Di�ria") || base.getPeriodicidade().equals("Semanal")
						|| base.getPeriodicidade().equals("Quinzenal"))) {
					sql = "delete from calculos_observacao where ID_TB = ? and"
							+ " convert(int, right(NOME_BASE,8)) >= ?";
				}

				ps = conexao.prepareStatement(sql);
				ps.setInt(1, base.getIdTabela());
				ps.setInt(2, direita);
				ps.executeUpdate();

				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o de exclus�o");

					// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
					// change body of generated methods, choose Tools | Templates.
				}
				isreprocessamento = 1;
			}
			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	

	public void inserirNotificacaoObservacao(int idTB, String nomeBase, ObservacaoDiario nobs, String dtModificacao) {
		String sql;

		sql = "Insert into NOTIFICACOES_OBSERVACAO"
				+ "(ID_TB, NOBS, DESV_NECESSARIO, QTD_DESV_ABAIXO, QTD_DESV_ACIMA, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA, CONSIDERAR, NOME_BASE) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setDouble(2, nobs.getNumObs());
			ps.setDouble(3, nobs.getDesvioNecess());
			ps.setDouble(4, nobs.getDesvioBaixo());
			ps.setDouble(5, nobs.getDesvioCima());
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, "");
			ps.setString(8, "");
			ps.setInt(9, 0);
			ps.setString(10, nomeBase);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirNotificacaoObservacaoHist(int idTB, String nomeBase, Observacao nobs, String dtModificacao) {
		String sql;

		sql = "Insert into NOTIFICACOES_OBSERVACAO"
				+ "(ID_TB, NOBS, DESV_NECESSARIO, QTD_DESV_ABAIXO, QTD_DESV_ACIMA, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA, CONSIDERAR, NOME_BASE) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setDouble(2, nobs.getNumObs());
			ps.setDouble(3, nobs.getDesvioNecess());
			ps.setDouble(4, nobs.getDesvioBaixo());
			ps.setDouble(5, nobs.getDesvioCima());
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, "");
			ps.setString(8, "");
			ps.setInt(9, 0);
			ps.setString(10, nomeBase);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirNotificacaoDuplicidade(Base base, String nomeBase, String nomeCampo, String qtdeDupPorc,
			String qtdeDup, String qtdeInfoDup, String dtModificacao) {
		String sql;

		if (nomeCampo.contains(" ")) {
			nomeCampo = nomeCampo.replace(" ", ", ");
		}

		sql = "Insert into NOTIFICACOES_DUPLICIDADE"
				+ "(ID_TB, NOME_BASE, CAMPO, QTDE_DUPLICIDADE_PORC, QTDE_DUPLICIDADE, QTDE_INFO_DUPLICADAS, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, base.getIdTabela());
			ps.setString(2, nomeBase);
			ps.setString(3, nomeCampo);
			ps.setDouble(4, Double.valueOf(qtdeDupPorc) * 100);
			ps.setInt(5, new BigDecimal(Double.parseDouble(qtdeDup)).intValueExact());
			ps.setInt(6, new BigDecimal(Double.parseDouble(qtdeInfoDup)).intValueExact());
			ps.setString(7, dtModificacao.trim());
			ps.setString(8, "");
			ps.setString(9, "");
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirNotificacaoDominio(Base base, String nomeBase, String nomeCampo, String qtdeDomPorc,
			String qtdeDom, String valoresDominio, String dtModificacao) {
		String sql;

		sql = "Insert into NOTIFICACOES_DOMINIO(ID_TB, NOME_BASE, CAMPO, QTDE_DOMINIO_PORC, QTDE_DOMINIO, VALORES_DOMINIO, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, base.getIdTabela());
			ps.setString(2, nomeBase);
			ps.setString(3, nomeCampo);

			ps.setDouble(4, (Double.valueOf(qtdeDomPorc) * 100));

			ps.setInt(5, new BigDecimal(Double.parseDouble(qtdeDom)).intValueExact());

			ps.setString(6, valoresDominio);
			ps.setString(7, dtModificacao.trim());
			ps.setString(8, "");
			ps.setString(9, "");
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirNotificacaoMissing(Base base, String nomeBase, String nomeCampo, String qtdeMisPorc,
			String qtdeMis, String dtModificacao) {
		String sql;

		sql = "Insert into NOTIFICACOES_MISSING"
				+ "(ID_TB, NOME_BASE, CAMPO, QTDE_MISSING_PORC, QTDE_MISSING, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, base.getIdTabela());
			ps.setString(2, nomeBase);
			ps.setString(3, nomeCampo);

			ps.setDouble(4, (Double.valueOf(qtdeMisPorc) * 100));

			ps.setInt(5, new BigDecimal(Double.parseDouble(qtdeMis)).intValueExact());

			ps.setString(6, dtModificacao.trim());
			ps.setString(7, "");
			ps.setString(8, "");
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirNotificacaoRange(Base base, String nomeBase, String nomeCampo, String qtdeRangePorc,
			String qtdeRange, String dtModificacao) {
		String sql;

		sql = "Insert into NOTIFICACOES_RANGE"
				+ "(ID_TB, NOME_BASE, CAMPO, QTDE_RANGE_PORC, QTDE_RANGE, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, base.getIdTabela());
			ps.setString(2, nomeBase);
			ps.setString(3, nomeCampo);

			ps.setDouble(4, (Double.valueOf(qtdeRange) * 100));

			ps.setInt(5, new BigDecimal(Double.parseDouble(qtdeRangePorc)).intValueExact());

			ps.setString(6, dtModificacao.trim());
			ps.setString(7, "");
			ps.setString(8, "");
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o range: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirNotificacaoIntegridade(Base base, String nomeBase, String nomeCampo, String tipoCadastro,
			int tamanhoCadastro, String tipoAtual, int tamanhoAtual, String tipoErro, String dtModificacao) {
		String sql;

		sql = "Insert into NOTIFICACOES_INTEGRIDADE"
				+ "(ID_TB, NOME_BASE, CAMPO, TIPO_CADASTRO, TAMANHO_CADASTRO, TIPO_ATUAL, TAMANHO_ATUAL, DATA_MODIFICACAO, TIPO_ERRO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, base.getIdTabela());
			ps.setString(2, nomeBase.trim());
			ps.setString(3, nomeCampo.trim());
			ps.setString(4, tipoCadastro.trim());
			ps.setInt(5, tamanhoCadastro);
			ps.setString(6, tipoAtual.trim());
			ps.setInt(7, tamanhoAtual);
			ps.setString(8, dtModificacao.trim());
			ps.setString(9, tipoErro.trim());
			ps.setString(10, "");
			ps.setString(11, "");
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirNotificacaoPSI(int idTB, String nomeBase, String campo, double psi, String dtModificacao) {
		String sql;

		sql = "Insert into NOTIFICACOES_PSI"
				+ "(ID_TB, NOME_BASE, CAMPO, PORCENT, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setString(2, nomeBase);
			ps.setString(3, campo);
			ps.setDouble(4, psi);
			ps.setString(5, dtModificacao.trim());
			ps.setString(6, "");
			ps.setString(7, "");
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
																					// methods, choose Tools |
																					// Templates.

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<ArrayList<String>> getNotificacoesDuplicidade(String nomeBase, String dtModificacao) {

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		String sql;

		sql = "select * "
				+ "from NOTIFICACOES_DUPLICIDADE where NOME_BASE = ? and Convert(datetime,DATA_MODIFICACAO,103) = Convert(datetime,?,103)";
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(rs.getString("NOME_BASE"));
				row.add(rs.getString("CAMPO"));
				String percentual = new DecimalFormat("#0.00").format(rs.getDouble("QTDE_DUPLICIDADE_PORC"));
				row.add(percentual + "%");
				row.add(String.valueOf(rs.getInt("QTDE_DUPLICIDADE")));
				row.add(String.valueOf(rs.getInt("QTDE_INFO_DUPLICADAS")));
				row.add(rs.getString("JUSTIFICATIVA"));
				row.add(rs.getString("DATA_JUSTIFICATIVA"));
				listacoluna.add(row);
			}
			if (listacoluna.size() == 0) {
				row = new ArrayList<String>();
				row.add("0");
				listacoluna.add(row);
			}

			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<ArrayList<String>> getNotificacoesDominio(String nomeBase, String dtModificacao) {

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		String sql;

		sql = "select * "
				+ "from NOTIFICACOES_DOMINIO where NOME_BASE = ? and Convert(datetime,DATA_MODIFICACAO,103) = Convert(datetime,?,103)";
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(rs.getString("NOME_BASE"));
				row.add(rs.getString("CAMPO"));
				String percentual = new DecimalFormat("#0.00").format(rs.getDouble("QTDE_DOMINIO_PORC"));
				row.add(percentual + "%");
				row.add(String.valueOf(rs.getInt("QTDE_DOMINIO")));
				row.add(rs.getString("VALORES_DOMINIO"));
				row.add(rs.getString("JUSTIFICATIVA"));
				row.add(rs.getString("DATA_JUSTIFICATIVA"));
				listacoluna.add(row);
			}
			if (listacoluna.size() == 0) {
				row = new ArrayList<String>();
				row.add("0");
				listacoluna.add(row);
			}

			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<ArrayList<String>> getNotificacoesMissing(String nomeBase, String dtModificacao) {

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		String sql;

		sql = "select * "
				+ "from NOTIFICACOES_MISSING where NOME_BASE = ? and Convert(datetime,DATA_MODIFICACAO,103) = Convert(datetime,?,103)";
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(rs.getString("NOME_BASE"));
				row.add(rs.getString("CAMPO"));
				String percentual = new DecimalFormat("#0.00").format(rs.getDouble("QTDE_MISSING_PORC"));
				row.add(percentual + "%");
				row.add(String.valueOf(rs.getInt("QTDE_MISSING")));
				row.add(rs.getString("JUSTIFICATIVA"));
				row.add(rs.getString("DATA_JUSTIFICATIVA"));
				listacoluna.add(row);
			}
			if (listacoluna.size() == 0) {
				row = new ArrayList<String>();
				row.add("0");
				listacoluna.add(row);
			}

			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<ArrayList<String>> getNotificacoesRange(String nomeBase, String dtModificacao) {

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		String sql;

		sql = "select * "
				+ "from NOTIFICACOES_RANGE where NOME_BASE = ? and Convert(datetime,DATA_MODIFICACAO,103) = Convert(datetime,?,103)";
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(rs.getString("NOME_BASE"));
				row.add(rs.getString("CAMPO"));
				String percentual = new DecimalFormat("#0.00").format(rs.getDouble("QTDE_RANGE_PORC"));
				row.add(percentual + "%");
				row.add(String.valueOf(rs.getInt("QTDE_RANGE")));
				row.add(rs.getString("JUSTIFICATIVA"));
				row.add(rs.getString("DATA_JUSTIFICATIVA"));
				listacoluna.add(row);
			}
			if (listacoluna.size() == 0) {
				row = new ArrayList<String>();
				row.add("0");
				listacoluna.add(row);
			}
			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<ArrayList<String>> getNotificacoesIntegridade(String nomeBase, String dtModificacao) {

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		String sql;

		sql = "select * "
				+ "from NOTIFICACOES_INTEGRIDADE where NOME_BASE = ? and Convert(datetime,DATA_MODIFICACAO,103) = Convert(datetime,?,103)";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(rs.getString("NOME_BASE"));
				row.add(rs.getString("CAMPO"));
				row.add(rs.getString("TIPO_CADASTRO"));
				row.add(String.valueOf(rs.getInt("TAMANHO_CADASTRO")));
				row.add((rs.getString("TIPO_ATUAL")));
				row.add(String.valueOf(rs.getInt("TAMANHO_ATUAL")));
				row.add(rs.getString("TIPO_ERRO"));
				row.add(rs.getString("JUSTIFICATIVA"));
				row.add(rs.getString("DATA_JUSTIFICATIVA"));
				listacoluna.add(row);
			}
			if (listacoluna.size() == 0) {
				row = new ArrayList<String>();
				row.add("0");
				listacoluna.add(row);
			}
			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<ArrayList<String>> getNotificacoesPSI(String nomeBase, String dtModificacao) {

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		String sql;

		sql = "select * from NOTIFICACOES_PSI where NOME_BASE like ? and Convert(datetime,DATA_MODIFICACAO,103) = Convert(datetime,?,103)";

		ResultSet rs = null;
		PreparedStatement ps = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(rs.getString("NOME_BASE"));
				row.add(rs.getString("CAMPO"));
				row.add(String.valueOf(rs.getDouble("PORCENT")));
				row.add(rs.getString("DATA_MODIFICACAO"));
				row.add(rs.getString("JUSTIFICATIVA"));
				row.add(rs.getString("DATA_JUSTIFICATIVA"));
				listacoluna.add(row);
			}
			if (listacoluna.size() == 0) {
				row = new ArrayList<String>();
				row.add("0");
				listacoluna.add(row);
			}
			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ArrayList<ArrayList<String>> getNotificacoesObservacao(int id, String nomeBase, String dtModificacao) {

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		String sql;

		sql = "select * from NOTIFICACOES_OBSERVACAO where ID_TB = ? and NOME_BASE = ? and Convert(datetime,DATA_MODIFICACAO,103) = Convert(datetime,?,103)";

		ResultSet rs = null;
		PreparedStatement ps = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, nomeBase);
			ps.setString(3, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(rs.getString("NOBS").substring(0, rs.getString("NOBS").length() - 5));
				row.add(String.valueOf(rs.getDouble("DESV_NECESSARIO")));
				row.add(String.valueOf(rs.getDouble("QTD_DESV_ABAIXO")));
				row.add(String.valueOf(rs.getDouble("QTD_DESV_ACIMA")));
				row.add(rs.getString("DATA_MODIFICACAO"));
				row.add(rs.getString("JUSTIFICATIVA"));
				row.add(rs.getString("DATA_JUSTIFICATIVA"));
				row.add(String.valueOf(rs.getInt("CONSIDERAR")));
				row.add(dtModificacao);
				listacoluna.add(row);
			}
			if (listacoluna.size() == 0) {
				row = new ArrayList<String>();
				row.add("0");
				listacoluna.add(row);
			}
			return listacoluna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public int[] getTotalBasesErroeAcerto() {

		int erros = 0;
		int total = 0;
		int[] erroAcerto = new int[2];
		String sql;
		String sql_2;

		sql = "select COUNT(*) as QTDE_ERROS from STATUS_BASES where STATUS_OBSERVACAO = 1 Or STATUS_INTEGRIDADE = 1 Or STATUS_DUPLICIDADE = 1\r\n"
				+ "Or STATUS_DOMINIO = 1 Or STATUS_MISSING = 1 Or STATUS_RANGE = 1 Or STATUS_PSI = 1";

		sql_2 = "select COUNT(*) QTDE_TOTAL from STATUS_BASES";

		Statement stmt = null;
		ResultSet rs = null;
		try {

			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				erros = rs.getInt("QTDE_ERROS");
			}

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a qtd de erros: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}

		try {

			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql_2);

			while (rs.next()) {
				total = rs.getInt("QTDE_TOTAL");
			}

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a qtd total: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}

		erroAcerto[0] = erros;
		erroAcerto[1] = total - erros;

		return erroAcerto;
	}

	public void updateStatusEmail(String nomeBase, String dtModificacao, String dtQualidade) {
		String sql;
		sql = "UPDATE STATUS_BASES SET STATUS_EMAIL = 1 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ? AND DATA_QUALIDADE = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.setString(3, dtQualidade.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("ocorreu um erro ao inserir o status do email");
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public int getStatusEmail(String nomeBase, String dataModificacao, String dataQualidade) {
		String sql;
		int cont = 0;
		int status = 0;

		sql = "select STATUS_EMAIL from status_bases where NOME_BASE = ? and DATA_MODIFICACAO = ? and DATA_QUALIDADE = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dataModificacao.trim());
			ps.setString(3, dataQualidade.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				status = rs.getInt("STATUS_EMAIL");
			}

			return status;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertJustificativaIntegridade(String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";
		if (!campo.equals("") & campo != null) {
			sql = "update NOTIFICACOES_INTEGRIDADE SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, campo);
				ps.setString(5, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "update NOTIFICACOES_INTEGRIDADE SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	}

	public void insertJustificativaDuplicidade(String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";

		if (!campo.equals("") & campo != null) {
			sql = "update NOTIFICACOES_DUPLICIDADE SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ?";

			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, campo);
				ps.setString(5, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "update NOTIFICACOES_DUPLICIDADE SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND DATA_MODIFICACAO = ?";

			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	}

	public void insertJustificativaDominio(String nomeBase, String campo, String dtJustificativa, String dtModificacao,
			String justificativa) {
		String sql = "";

		if (!campo.equals("") & campo != null) {
			sql = "update NOTIFICACOES_DOMINIO SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, campo);
				ps.setString(5, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "update NOTIFICACOES_DOMINIO SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	}

	public void insertJustificativaMissing(String nomeBase, String campo, String dtJustificativa, String dtModificacao,
			String justificativa) {
		String sql = "";

		if (!campo.equals("") & campo != null) {
			sql = "update NOTIFICACOES_MISSING SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, campo);
				ps.setString(5, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "update NOTIFICACOES_MISSING SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	}

	public void insertJustificativaRange(String nomeBase, String campo, String dtJustificativa, String dtModificacao,
			String justificativa) {
		String sql = "";

		if (!campo.equals("") & campo != null) {
			sql = "update NOTIFICACOES_RANGE SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, campo);
				ps.setString(5, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "update NOTIFICACOES_RANGE SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where NOME_BASE = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setString(3, nomeBase);
				ps.setString(4, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	}

	public void insertJustificativaPSI(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";

		if (!campo.equals("") & campo != null) {
			sql = "update NOTIFICACOES_PSI SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where ID_TB = ? AND NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setInt(3, idTB);
				ps.setString(4, nomeBase);
				ps.setString(5, campo);
				ps.setString(6, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "update NOTIFICACOES_PSI SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
					+ "where ID_TB = ? AND NOME_BASE = ? AND DATA_MODIFICACAO = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, justificativa);
				ps.setString(2, dtJustificativa);
				ps.setInt(3, idTB);
				ps.setString(4, nomeBase);
				ps.setString(5, dtModificacao.trim());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
				}
			} catch (Exception ex) {
				throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	}

	public void insertJustificativaNotificacoesObservacao(int idTB, String nomeBase, String dtModificacao,
			String dtJustificativa, String justificativa) {
		String sql = "";
		sql = "update NOTIFICACOES_OBSERVACAO SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}

		sql = "update CALCULOS_OBSERVACAO SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND DT_FLAG = ?";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertNovaJustificativaIntegridade(String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {

		String sql = "";

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();
		ResultSet rs = null;
		PreparedStatement ps = null;

		if (!campo.equals("") & campo != null) {
			sql = "select * from NOTIFICACOES_INTEGRIDADE "
					+ "where NOME_BASE = ? and CAMPO = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, campo);
				ps.setString(3, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(rs.getString("TIPO_CADASTRO"));
					row.add(String.valueOf(rs.getInt("TAMANHO_CADASTRO")));
					row.add(rs.getString("TIPO_ATUAL"));
					row.add(String.valueOf(rs.getInt("TAMANHO_ATUAL")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					row.add(rs.getString("TIPO_ERRO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "select * from NOTIFICACOES_INTEGRIDADE " + "where NOME_BASE = ? and DATA_MODIFICACAO = ?";
			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(rs.getString("TIPO_CADASTRO"));
					row.add(String.valueOf(rs.getInt("TAMANHO_CADASTRO")));
					row.add(rs.getString("TIPO_ATUAL"));
					row.add(String.valueOf(rs.getInt("TAMANHO_ATUAL")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					row.add(rs.getString("TIPO_ERRO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		}

		sql = "Insert into NOTIFICACOES_INTEGRIDADE"
				+ "(ID_TB, NOME_BASE, CAMPO, TIPO_CADASTRO, TAMANHO_CADASTRO, TIPO_ATUAL, TAMANHO_ATUAL, DATA_MODIFICACAO, TIPO_ERRO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(listacoluna.get(0).get(0)));
			ps.setString(2, listacoluna.get(0).get(1));
			ps.setString(3, listacoluna.get(0).get(2));
			ps.setString(4, listacoluna.get(0).get(3));
			ps.setInt(5, Integer.parseInt(listacoluna.get(0).get(4)));
			ps.setString(6, listacoluna.get(0).get(5));
			ps.setInt(7, Integer.parseInt(listacoluna.get(0).get(6)));
			ps.setString(8, listacoluna.get(0).get(7));
			ps.setString(9, listacoluna.get(0).get(8));
			ps.setString(10, justificativa);
			ps.setString(11, dtJustificativa);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertNovaJustificativaDuplicidade(String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();
		ResultSet rs = null;
		PreparedStatement ps = null;

		if (!campo.equals("") & campo != null) {
			sql = "select * from NOTIFICACOES_DUPLICIDADE "
					+ "where NOME_BASE = ? and CAMPO = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, campo);
				ps.setString(3, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_DUPLICIDADE_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_DUPLICIDADE")));
					row.add(String.valueOf(rs.getDouble("QTDE_INFO_DUPLICADAS")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "select * from NOTIFICACOES_DUPLICIDADE " + "where NOME_BASE = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_DUPLICIDADE_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_DUPLICIDADE")));
					row.add(String.valueOf(rs.getDouble("QTDE_INFO_DUPLICADAS")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		}

		sql = "Insert into NOTIFICACOES_DUPLICIDADE"
				+ "(ID_TB, NOME_BASE, CAMPO, QTDE_DUPLICIDADE_PORC, QTDE_DUPLICIDADE, QTDE_INFO_DUPLICADAS, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(listacoluna.get(0).get(0)));
			ps.setString(2, listacoluna.get(0).get(1));
			ps.setString(3, listacoluna.get(0).get(2));
			ps.setDouble(4, Double.parseDouble(listacoluna.get(0).get(3)));
			ps.setDouble(5, Double.parseDouble(listacoluna.get(0).get(4)));
			ps.setDouble(6, Double.parseDouble(listacoluna.get(0).get(5)));
			ps.setString(7, listacoluna.get(0).get(6));
			ps.setString(8, justificativa);
			ps.setString(9, dtJustificativa);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertNovaJustificativaDominio(String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {

		String sql = "";

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();
		ResultSet rs = null;
		PreparedStatement ps = null;

		if (!campo.equals("") & campo != null) {
			sql = "select * from NOTIFICACOES_DOMINIO " + "where NOME_BASE = ? and CAMPO = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, campo);
				ps.setString(3, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_DOMINIO_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_DOMINIO")));
					row.add(rs.getString("VALORES_DOMINIO"));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "select * from NOTIFICACOES_DOMINIO " + "where NOME_BASE = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_DOMINIO_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_DOMINIO")));
					row.add(rs.getString("VALORES_DOMINIO"));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		}

		sql = "Insert into NOTIFICACOES_DOMINIO(ID_TB, NOME_BASE, CAMPO, QTDE_DOMINIO_PORC, QTDE_DOMINIO, VALORES_DOMINIO, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(listacoluna.get(0).get(0)));
			ps.setString(2, listacoluna.get(0).get(1));
			ps.setString(3, listacoluna.get(0).get(2));
			ps.setDouble(4, Double.parseDouble(listacoluna.get(0).get(3)));
			ps.setDouble(5, Double.parseDouble(listacoluna.get(0).get(4)));
			ps.setString(6, listacoluna.get(0).get(5));
			ps.setString(7, listacoluna.get(0).get(6));
			ps.setString(8, justificativa);
			ps.setString(9, dtJustificativa);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertNovaJustificativaMissing(String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();
		ResultSet rs = null;
		PreparedStatement ps = null;

		if (!campo.equals("") & campo != null) {
			sql = "select * from NOTIFICACOES_MISSING " + "where NOME_BASE = ? and CAMPO = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, campo);
				ps.setString(3, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_MISSING_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_MISSING")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "select * from NOTIFICACOES_MISSING " + "where NOME_BASE = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_MISSING_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_MISSING")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		}

		sql = "Insert into NOTIFICACOES_MISSING(ID_TB, NOME_BASE, CAMPO, QTDE_MISSING_PORC, QTDE_MISSING, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(listacoluna.get(0).get(0)));
			ps.setString(2, listacoluna.get(0).get(1));
			ps.setString(3, listacoluna.get(0).get(2));
			ps.setDouble(4, Double.parseDouble(listacoluna.get(0).get(3)));
			ps.setDouble(5, Double.parseDouble(listacoluna.get(0).get(4)));
			ps.setString(6, listacoluna.get(0).get(5));
			ps.setString(7, justificativa);
			ps.setString(8, dtJustificativa);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertNovaJustificativaRange(String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();
		ResultSet rs = null;
		PreparedStatement ps = null;

		if (!campo.equals("") & campo != null) {
			sql = "select * from NOTIFICACOES_RANGE " + "where NOME_BASE = ? and CAMPO = ? and DATA_MODIFICACAO = ?";
			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, campo);
				ps.setString(3, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_RANGE_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_RANGE")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "select * from NOTIFICACOES_RANGE " + "where NOME_BASE = ? and DATA_MODIFICACAO = ?";
			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("QTDE_RANGE_PORC")));
					row.add(String.valueOf(rs.getDouble("QTDE_RANGE")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		}

		sql = "Insert into NOTIFICACOES_RANGE(ID_TB, NOME_BASE, CAMPO, QTDE_RANGE_PORC, QTDE_RANGE, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(listacoluna.get(0).get(0)));
			ps.setString(2, listacoluna.get(0).get(1));
			ps.setString(3, listacoluna.get(0).get(2));
			ps.setDouble(4, Double.parseDouble(listacoluna.get(0).get(3)));
			ps.setDouble(5, Double.parseDouble(listacoluna.get(0).get(4)));
			ps.setString(6, listacoluna.get(0).get(5));
			ps.setString(7, justificativa);
			ps.setString(8, dtJustificativa);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertNovaJustificativaPSI(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();
		ResultSet rs = null;
		PreparedStatement ps = null;

		if (!campo.equals("") & campo != null) {
			sql = "select * from NOTIFICACOES_PSI " + "where NOME_BASE = ? and CAMPO = ? and DATA_MODIFICACAO = ?";
			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, campo);
				ps.setString(3, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("PORCENT")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		} else {
			sql = "select * from NOTIFICACOES_PSI " + "where NOME_BASE = ? and DATA_MODIFICACAO = ?";

			try {

				ps = conexao.prepareStatement(sql);
				ps.setString(1, nomeBase);
				ps.setString(2, dtModificacao.trim());
				rs = ps.executeQuery();

				while (rs.next()) {
					row = new ArrayList<String>();
					row.add(String.valueOf(rs.getInt("ID_TB")));
					row.add(rs.getString("NOME_BASE"));
					row.add(rs.getString("CAMPO"));
					row.add(String.valueOf(rs.getDouble("PORCENT")));
					row.add(rs.getString("DATA_MODIFICACAO"));
					listacoluna.add(row);
				}
				if (listacoluna.size() == 0) {
					row = new ArrayList<String>();
					row.add("0");
					listacoluna.add(row);
				}

			} catch (Exception ex) {
				throw new DAOException(
						"Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				ps = GerenciadorDeConexao.close(ps);
			}
		}

		sql = "Insert into NOTIFICACOES_PSI(ID_TB, NOME_BASE, CAMPO, PORCENT, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA) "
				+ "values (?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(listacoluna.get(0).get(0)));
			ps.setString(2, listacoluna.get(0).get(1));
			ps.setString(3, listacoluna.get(0).get(2));
			ps.setDouble(4, Double.parseDouble(listacoluna.get(0).get(3)));
			ps.setString(5, listacoluna.get(0).get(4));
			ps.setString(6, justificativa);
			ps.setString(7, dtJustificativa);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void insertNovaJustificativaNotificacoesObservacao(int idTB, String nomeBase, String dtJustificativa,
			String dtModificacao, String justificativa) {
		String sql = "";

		ArrayList<String> row = new ArrayList<String>();
		ArrayList<ArrayList<String>> listacoluna = new ArrayList<ArrayList<String>>();

		sql = "select * from NOTIFICACOES_OBSERVACAO " + "where NOME_BASE = ? and DATA_MODIFICACAO = ?";
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {

			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			rs = ps.executeQuery();

			while (rs.next()) {
				row = new ArrayList<String>();
				row.add(String.valueOf(rs.getInt("ID_TB")));
				row.add(String.valueOf(rs.getDouble("NOBS")));
				row.add(rs.getString("NOME_BASE"));
				row.add(String.valueOf(rs.getDouble("DESV_NECESSARIO")));
				row.add(String.valueOf(rs.getDouble("QTD_DESV_ABAIXO")));
				row.add(String.valueOf(rs.getDouble("QTD_DESV_ACIMA")));
				row.add(rs.getString("DATA_MODIFICACAO"));
				listacoluna.add(row);
			}

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de notifica��o por regra: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		sql = "Insert into NOTIFICACOES_OBSERVACAO(ID_TB, NOBS, DESV_NECESSARIO, QTD_DESV_ABAIXO, QTD_DESV_ACIMA, DATA_MODIFICACAO, JUSTIFICATIVA, DATA_JUSTIFICATIVA, CONSIDERAR, NOME_BASE) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(listacoluna.get(0).get(0)));
			ps.setDouble(2, Double.parseDouble(listacoluna.get(0).get(1)));
			ps.setDouble(3, Double.parseDouble(listacoluna.get(0).get(3)));
			ps.setDouble(4, Double.parseDouble(listacoluna.get(0).get(4)));
			ps.setDouble(5, Double.parseDouble(listacoluna.get(0).get(5)));
			ps.setString(6, listacoluna.get(0).get(6));
			ps.setString(7, justificativa);
			ps.setString(8, dtJustificativa);
			ps.setInt(9, 0);
			ps.setString(10, listacoluna.get(0).get(2));
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateStatusBasesIntegridade(String nomeBase, String dtModificacao) {
		String sql = "";
		sql = "UPDATE STATUS_BASES SET STATUS_INTEGRIDADE = -3 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateStatusBasesDuplicidade(String nomeBase, String dtModificacao) {
		String sql = "";
		sql = "UPDATE STATUS_BASES SET STATUS_DUPLICIDADE = -3 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateStatusBasesDominio(String nomeBase, String dtModificacao) {
		String sql = "";
		sql = "UPDATE STATUS_BASES SET STATUS_DOMINIO = -3 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateStatusBasesMissing(String nomeBase, String dtModificacao) {
		String sql = "";
		sql = "UPDATE STATUS_BASES SET STATUS_MISSING = -3 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateStatusBasesRange(String nomeBase, String dtModificacao) {
		String sql = "";
		sql = "UPDATE STATUS_BASES SET STATUS_RANGE = -3 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateStatusBasesPSI(String nomeBase, String dtModificacao) {
		String sql = "";
		sql = "UPDATE STATUS_BASES SET STATUS_PSI = -3 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateStatusBasesObservacao(String nomeBase, String dtModificacao) {
		String sql = "";
		sql = "UPDATE STATUS_BASES SET STATUS_OBSERVACAO = -3 WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setString(2, dtModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean existeNotificacaoRange(String campo, String nomeBase, String dataModificacao) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int cont = 0;
		boolean isreprocessamento = false;

		sql = "select count(*) as QTDE from NOTIFICACOES_RANGE where CAMPO = ? and NOME_BASE = ? AND DATA_MODIFICACAO = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, campo);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isreprocessamento = true;
			}

			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean existeNotificacaoDominio(String campo, String nomeBase, String dataModificacao) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int cont = 0;
		boolean isreprocessamento = false;

		sql = "select count(*) as QTDE from NOTIFICACOES_Dominio where CAMPO = ? and NOME_BASE = ? AND DATA_MODIFICACAO = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, campo);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isreprocessamento = true;
			}

			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean existeNotificacaoIntegridade(String campo, String nomeBase, String dataModificacao) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int cont = 0;
		boolean isreprocessamento = false;

		sql = "select count(*) as QTDE from NOTIFICACOES_INTEGRIDADE where CAMPO = ? and NOME_BASE = ? AND DATA_MODIFICACAO = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, campo);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isreprocessamento = true;
			}

			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean existeNotificacaoDuplicidade(String campo, String nomeBase, String dataModificacao) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int cont = 0;
		boolean isreprocessamento = false;

		sql = "select count(*) as QTDE from NOTIFICACOES_DUPLICIDADE where CAMPO = ? and NOME_BASE = ? AND DATA_MODIFICACAO = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, campo);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isreprocessamento = true;
			}

			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean existeNotificacaoMissing(String campo, String nomeBase, String dataModificacao) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int cont = 0;
		boolean isreprocessamento = false;

		sql = "select count(*) as QTDE from NOTIFICACOES_Missing where CAMPO = ? and NOME_BASE = ? AND DATA_MODIFICACAO = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, campo);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isreprocessamento = true;
			}

			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean existeJustificativaObservacao(int idTB, String nomeBase, String dataModificacao) {
		String sql;
		int cont = 0;
		boolean isjustificativa = true;

		sql = "select count(*) as QTDE from NOTIFICACOES_observacao where ID_TB = ? AND NOME_BASE = ? AND DATA_MODIFICACAO = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isjustificativa = false;
			}

			return isjustificativa;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar se existe justificativa" + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void desconsiderarFlagObservacao(int idTB, String nomeBase, String dataModificacao) {
		String sql = "";
		sql = "update calculos_observacao SET CONSIDERAR = 1 where ID_TB = ? AND DT_FLAG = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setString(2, dataModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao desconsiderar flag: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}

		sql = "update NOTIFICACOES_observacao SET CONSIDERAR = 1 where ID_TB = ? AND NOME_BASE = ? AND DATA_MODIFICACAO = ? AND JUSTIFICATIVA <> ''";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao desconsiderar flag: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void considerarFlagObservacao(int idTB, String nomeBase, String dataModificacao) {
		String sql = "";
		sql = "update calculos_observacao SET CONSIDERAR = 0, JUSTIFICATIVA = '', DATA_JUSTIFICATIVA = '' where ID_TB = ? AND DT_FLAG LIKE ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setString(2, dataModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao desconsiderar flag: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}

		sql = "update NOTIFICACOES_observacao SET CONSIDERAR = 0, JUSTIFICATIVA = '', DATA_JUSTIFICATIVA = '' where ID_TB = ? AND NOME_BASE = ? AND DATA_MODIFICACAO LIKE ?";
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao desconsiderar flag: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean jaExecutouQualidade(int idTB) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int cont = 0;
		boolean isreprocessamento = false;

		sql = "select count(*) as QTDE from status_bases where ID_TB = ? and CONVERT(date, DATA_QUALIDADE, 103) = CONVERT(date, GETDATE(), 103)";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isreprocessamento = true;
			}

			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar se j� executou a qualidade");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateIdItemSPStatusBases(String nomeBase, String dtModificacao, String dtQualidade, int id) {
		String sql;
		sql = "UPDATE STATUS_BASES SET ID_ITEM_SHAREPOINT = ? WHERE NOME_BASE = ? AND DATA_MODIFICACAO = ? AND DATA_QUALIDADE = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, nomeBase);
			ps.setString(3, dtModificacao.trim());
			ps.setString(4, dtQualidade.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("ocorreu um erro ao inserir o status do email");
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void updateJustificativaPSI(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		String sql = "";

		sql = "update NOTIFICACOES_PSI SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ? AND DATA_JUSTIFICATIVA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, campo);
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, dtJustificativaOld.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public void updateJustificativaObservacao(int idTB, String nomeBase, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		String sql = "";

		sql = "update NOTIFICACOES_Observacao SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND DATA_MODIFICACAO = ? AND DATA_JUSTIFICATIVA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, dtModificacao.trim());
			ps.setString(6, dtJustificativaOld.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public void updateJustificativaIntegridade(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		String sql = "";

		sql = "update NOTIFICACOES_Integridade SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ? AND DATA_JUSTIFICATIVA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, campo);
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, dtJustificativaOld.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public void updateJustificativaDuplicidade(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		String sql = "";

		sql = "update NOTIFICACOES_Duplicidade SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ? AND DATA_JUSTIFICATIVA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, campo);
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, dtJustificativaOld.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public void updateJustificativaDominio(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		String sql = "";

		sql = "update NOTIFICACOES_Dominio SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ? AND DATA_JUSTIFICATIVA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, campo);
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, dtJustificativaOld.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public void updateJustificativaMissing(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		String sql = "";

		sql = "update NOTIFICACOES_Missing SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ? AND DATA_JUSTIFICATIVA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, campo);
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, dtJustificativaOld.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public void updateJustificativaRange(int idTB, String nomeBase, String campo, String dtJustificativa,
			String dtModificacao, String justificativa, String dtJustificativaOld) {
		String sql = "";

		sql = "update NOTIFICACOES_Range SET JUSTIFICATIVA = ?, DATA_JUSTIFICATIVA = ? "
				+ "where ID_TB = ? AND NOME_BASE = ? AND CAMPO = ? AND DATA_MODIFICACAO = ? AND DATA_JUSTIFICATIVA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, justificativa);
			ps.setString(2, dtJustificativa);
			ps.setInt(3, idTB);
			ps.setString(4, nomeBase);
			ps.setString(5, campo);
			ps.setString(6, dtModificacao.trim());
			ps.setString(7, dtJustificativaOld.trim());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); // To change body of generated
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao inserir a notifica��o de integridade: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public String[] getLastObservacao(int idTB) {
		String[] linha = new String[3];
		String sql;

		sql = "select top 1 * from calculos_observacao where ID_TB = ? ORDER BY " + 
				"convert(DATETIME, DT_FLAG, 103) DESC";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			rs = ps.executeQuery();

			if (rs.next()) {
				linha[0] = rs.getString("NOBS");
				linha[1] = rs.getString("NOME_BASE");
				linha[2] = rs.getString("DT_FLAG");
			}


			return linha;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar se j� executou a qualidade");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

}
