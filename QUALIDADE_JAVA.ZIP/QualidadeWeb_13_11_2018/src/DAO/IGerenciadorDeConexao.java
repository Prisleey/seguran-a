package DAO;

public interface IGerenciadorDeConexao {
	
	void iniciar() throws DAOException;
    void encerrar();
    void confirmarTransacao();
    void abortarTransacao();
	
}
