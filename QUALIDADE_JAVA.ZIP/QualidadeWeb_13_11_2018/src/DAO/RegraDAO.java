package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import model.Base;
import model.ColunaTabela;
import model.Regra;
import model.Resposta;

public class RegraDAO {
	private Connection conexao;
	
	public RegraDAO(Connection conexao) {
		this.conexao = conexao;
	}
	
	//Listar regras(descri��o e n�o detalhe)
	public List<Regra> listarRegras() {
		List<Regra> listaRegras = new ArrayList();
		String sql;
		Regra regra;
		
		sql = "Select "
				+ "ID_REGRA, "
				+ "DESCRICAO_REGRA "
			+ "FROM REGRAS_QUALIDADE WHERE ID_REGRA > 2";
		
		PreparedStatement ps;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				regra = new Regra();
				regra.setIdRegra(rs.getInt("ID_REGRA"));
				regra.setNomeRegra(rs.getString("DESCRICAO_REGRA"));
				listaRegras.add(regra);
			}
			
			return listaRegras;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de bases: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	
	//Listar regras(descri��o e n�o detalhe)
		public List<Regra> listarRegrasDetalhes() {
			List<Regra> listaRegras = new ArrayList();
			Base base;
			ColunaTabela coluna;
			String sql;
			Regra regra;
			
			sql = "select  t1.ID_TB, t1.ID_COLUNA, t1.ID_REGRA, t2.NOME_BASE, t3.NOME_COLUNA, t4.DESCRICAO_REGRA, " +
					"t1.DETALHE1, t1.DETALHE2, '0,' as ids_duplicidade " +
			"from "+ 
					"REGRAS_VS_BASE t1 "+
			"inner join "+ 
					"tabela_qualidade t2 on t1.id_tb = t2.id_tb "+ 
			"inner join "+ 
					"coluna_tabela t3 on t1.ID_COLUNA = t3.ID_COLUNA "+
			"inner join " + 
					"REGRAS_QUALIDADE t4 on t1.ID_REGRA = t4.ID_REGRA WHERE t1.ID_REGRA <> 6" +	
			"UNION "+
			"( "+
				"SELECT t1.id_tb, "+ 
					"0 as id_coluna, "+ 
					"t1.id_regra," + 
					"t2.nome_base, " + 
					"'Varias Colunas' as nome_coluna, "+ 
					"t4.descricao_regra, "+ 
					"t1.detalhe1, "+ 
					"t1.detalhe2, "+
					"( "+ 
				    "select "+
						"CONVERT(varchar(10), stb1.ID_COLUNA) + ',' AS 'data()' "+
					"from regras_vs_base stb1 "+
					"where stb1.ID_TB = t1.ID_TB "+
						"and stb1.ID_REGRA = t1.ID_REGRA "+
					"For XML PATH ('') "+
					") Ids_Duplicidade "+
					"FROM   regras_vs_base t1 " + 
					"inner join tabela_qualidade t2 " + 
						"ON t1.id_tb = t2.id_tb "+ 
					"inner join coluna_tabela t3 "+ 
					    "ON t1.id_coluna = t3.id_coluna "+ 
					"inner join regras_qualidade t4 "+ 
					    "ON t1.id_regra = t4.id_regra "+ 
				"Where t1.id_regra = 6"+
				"GRoup by "+
						"t1.id_tb,t1.id_regra,t2.nome_base,t4.descricao_regra, t1.detalhe1,t1.detalhe2 "+ 
			") "+
			"ORDER BY 2 DESC" ;
			
			//System.out.println(sql);
	
			Statement stmt = null;
			ResultSet rs = null;
			try {
				stmt = conexao.createStatement();
				rs = stmt.executeQuery(sql);
				
				while(rs.next()) {
					base = new Base();
					coluna = new ColunaTabela();
					regra = new Regra();
					base.setNomeBase(rs.getString("NOME_BASE"));
					base.setIdTabela(rs.getInt("ID_TB"));
					coluna.setNomeColuna(rs.getString("NOME_COLUNA"));
					coluna.setIdColuna(rs.getInt("ID_COLUNA"));
					coluna.setTabela(base);
					regra.setColuna(coluna);
					regra.setIdRegra(rs.getInt("ID_REGRA"));
					regra.setNomeRegra(rs.getString("DESCRICAO_REGRA"));
					regra.setDetalheRegra(rs.getString("DETALHE1"));
					regra.setDetalheRegra2(rs.getString("DETALHE2"));
					String str = rs.getString("ids_duplicidade");
					str= str.substring(0, str.length() - 1);
					regra.setMultiIds(str.trim().split(","));
					listaRegras.add(regra);
				}
				
				return listaRegras;
				
			}catch(Exception ex) {
				throw new DAOException("Ocorreu um erro ao retornar a lista de bases: " + ex.getMessage());
			} finally {
				rs = GerenciadorDeConexao.close(rs);
				stmt = GerenciadorDeConexao.close(stmt);
			}
		}
	
		//a diferen�a � que essa regra pode ter v�rios campos, ou seja, varios inserts
		public Resposta inserirRegraDuplicidade(int tipo, Regra regra, String matricula) {
			
			//deletando as regras antes de inserir, em caso de update.
			deletarRegraPorTabela(regra.getIdRegra(), regra.getIdTabela());
			
			Resposta resp = new Resposta();
			
			for(String id : regra.getMultiIds()) { //loop, pois far� N inserts na base de regras.
				String sql;
				
				sql = "Insert into REGRAS_VS_BASE"
						+ "(ID_REGRA, ID_TB, ID_COLUNA, DETALHE1, USR_INI, USR_ATU)"
						+ "values (?, ?, ?, ?, ?, ?)";
				PreparedStatement ps = null;
				try {
					ps = conexao.prepareStatement(sql); 
					ps.setInt(1, regra.getIdRegra());
					ps.setInt(2, regra.getIdTabela());
					ps.setInt(3, Integer.parseInt(id));
					ps.setString(4, regra.getDetalheRegra());
					ps.setString(5, matricula);
					ps.setString(6, matricula);
					ps.executeUpdate();
					try{
			            conexao.commit();
			        }catch (SQLException ex){
			        	conexao.rollback();
			            //throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
			        	resp.setMensagem("Ocorreu um erro ao confirmar a transa��o" + ex.getMessage());
			        	resp.setTipo(2); //erro
			        	return resp;
			        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
			        }
					
				}catch(Exception ex) {
					//throw new DAOException("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
					resp.setMensagem("Ocorreu um erro ao inserir o registro na tabela: " + ex.getMessage());
		        	resp.setTipo(2); //erro
		        	return resp;
					//return ("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
					
				} finally {
					ps = GerenciadorDeConexao.close(ps);
				}
			}

			resp.setMensagem("Registro inserido com sucesso");
			resp.setTipo(1);
			return resp;
			
			
		}	
		
		
	public Resposta inserirRegraDetalhe(int tipo, Regra regra, String matricula) {
		Resposta resp = new Resposta();
		String sql;
		if (tipo == 1) {
			sql = "Insert into REGRAS_VS_BASE"
					+ "(ID_REGRA, ID_TB, ID_COLUNA, DETALHE1, USR_INI, USR_ATU)"
					+ "values (?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql); 
				ps.setInt(1, regra.getIdRegra());
				ps.setInt(2, regra.getIdTabela());
				ps.setInt(3, regra.getIdColuna());
				ps.setString(4, regra.getDetalheRegra());
				ps.setString(5, matricula);
				ps.setString(6, matricula);
				ps.executeUpdate();
				try{
		            conexao.commit();
		        }catch (SQLException ex){
		        	conexao.rollback();
		            //throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
		        	resp.setMensagem("Ocorreu um erro ao confirmar a transa��o" + ex.getMessage());
		        	resp.setTipo(2); //erro
		        	return resp;
		        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
		        }
				
			}catch(Exception ex) {
				//throw new DAOException("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
				resp.setMensagem("Ocorreu um erro ao inserir o registro na tabela: " + ex.getMessage());
	        	resp.setTipo(2); //erro
	        	return resp;
				//return ("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
				
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}else {
			sql = "Insert into REGRAS_VS_BASE"
					+ "(ID_REGRA, ID_TB, ID_COLUNA, DETALHE1, DETALHE2, USR_INI, USR_ATU)"
					+ "values (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql); 
				ps.setInt(1, regra.getIdRegra());
				ps.setInt(2, regra.getIdTabela());
				ps.setInt(3, regra.getIdColuna());
				ps.setString(4, regra.getDetalheRegra());
				ps.setString(5, regra.getDetalheRegra2());
				ps.setString(6, matricula);
				ps.setString(7, matricula);
				ps.executeUpdate();
				try{
		            conexao.commit();
		        }catch (SQLException ex){
		        	conexao.rollback();
		            //throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
		        	resp.setMensagem("Ocorreu um erro ao confirmar a transa��o" + ex.getMessage());
		        	resp.setTipo(2); //erro
		        	return resp;
		        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
		        }
				
			}catch(Exception ex) {
				//throw new DAOException("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
				resp.setMensagem("Ocorreu um erro ao inserir o registro na tabela: " + ex.getMessage());
	        	resp.setTipo(2); //erro
	        	return resp;
				//return ("Ocorreu um erro ao inserir o registro na tabela Teste: " + ex.getMessage());
				
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
		
		
	
		resp.setMensagem("Registro inserido com sucesso");
		resp.setTipo(1);
		return resp;
		
		
	}
	
	public Regra getDetalheRegraById(int idTb, int idCol, int idRegra) {
		Regra regra = new Regra();
		String sql;
		sql = "select "
				+ "DETALHE1, DETALHE2 FROM REGRAS_VS_BASE " 
				+ "WHERE ID_TB=? AND ID_COLUNA=? AND ID_REGRA=?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, idTb);
			ps.setInt(2, idCol);
			ps.setInt(3, idRegra);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				regra.setDetalheRegra(rs.getString("DETALHE1"));
				regra.setDetalheRegra2(rs.getString("DETALHE2"));
			}
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar os detalhes: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
				
		return regra;
	}
	
	public List<Regra> getRegrasPorColuna(int idTb, int idCol) {
		List<Regra> regras = new ArrayList();
		Regra regra;
		int id;
		String sql;
		sql = "select "
				+ "ID_REGRA, DETALHE1, DETALHE2 FROM REGRAS_VS_BASE  " 
				+ "WHERE ID_TB=? AND ID_COLUNA=? "
				+ "order by ID_REGRA ASC";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, idTb);
			ps.setInt(2, idCol);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				regra = new Regra();
				regra.setIdRegra(rs.getInt("ID_REGRA"));
				regra.setDetalheRegra(rs.getString("DETALHE1"));
				regra.setDetalheRegra2(rs.getString("DETALHE2"));
				regras.add(regra);

			}
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar os detalhes: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
				
		return regras;
	}
	
	public Resposta updateRegraDetalhe(int tipo, Regra regra, String matricula) {
		Resposta resp = new Resposta();
		String sql;
		if (tipo == 1) {//demais regras
			sql = "UPDATE REGRAS_VS_BASE SET "
					+ "DETALHE1 = ?, USR_ATU  = ? "
					+ "WHERE ID_TB = ? AND ID_COLUNA = ? AND ID_REGRA = ? ";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, regra.getDetalheRegra());
				ps.setString(2, matricula);
				ps.setInt(3, regra.getIdTabela());
				ps.setInt(4, regra.getIdColuna());
				ps.setInt(5, regra.getIdRegra());
				ps.executeUpdate();
				try{
		            conexao.commit();
		        }catch (SQLException ex){
		        	conexao.rollback();
		        	resp.setMensagem("Ocorreu um erro ao confirmar a transa��o" + ex.getMessage());
		        	resp.setTipo(2); //erro
		        	return resp;
		        	
		        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
		        }
			}catch(Exception ex) {
				resp.setMensagem("Ocorreu um erro ao fazer update na regra: " + ex.getMessage());
	        	resp.setTipo(2); //erro
	        	return resp;
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}else {//range
			sql = "UPDATE REGRAS_VS_BASE SET "
					+ "DETALHE1 = ?, DETALHE2 = ?, USR_ATU  = ? "
					+ "WHERE ID_TB = ? AND ID_COLUNA = ? AND ID_REGRA = ? ";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, regra.getDetalheRegra());
				ps.setString(2, regra.getDetalheRegra2());
				ps.setString(3, matricula);
				ps.setInt(4, regra.getIdTabela());
				ps.setInt(5, regra.getIdColuna());
				ps.setInt(6, regra.getIdRegra());
				ps.executeUpdate();
				try{
		            conexao.commit();
		        }catch (SQLException ex){
		        	conexao.rollback();
		        	resp.setMensagem("Ocorreu um erro ao confirmar a transa��o" + ex.getMessage());
		        	resp.setTipo(2); //erro
		        	return resp;
		        	
		        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
		        }
			}catch(Exception ex) {
				resp.setMensagem("Ocorreu um erro ao fazer update na regra: " + ex.getMessage());
	        	resp.setTipo(2); //erro
	        	return resp;
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
			
		}
			
			resp.setMensagem("Registro atualizado com sucesso");
			resp.setTipo(1);
			return resp;
	}
	
	//deleta todas as regras de uma coluna x
	public void deleteRegraByIdCol(int idColuna) {
		String sql;
		sql = "delete from REGRAS_VS_BASE  "
				+ "WHERE ID_COLUNA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idColuna);
			ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	        	conexao.rollback();
	            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); 
	        	
	        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao deletar as regra da Coluna:" + idColuna +". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	//deleta toda regra "X" de uma tabela especifica
		public void deletarRegraPorTabela(int idRegra, int idTb) {
			String sql;
			sql = "delete from REGRAS_VS_BASE  "
					+ "where ID_REGRA = ? and ID_TB = ?";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idRegra);
				ps.setInt(2, idTb);
				ps.executeUpdate();
				try{
		            conexao.commit();
		        }catch (SQLException ex){
		        	conexao.rollback();
		            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); 
		        	
		        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
		        }
			}catch(Exception ex) {
				throw new DAOException("Ocorreu um erro ao deletar a regra:"+ idRegra +" da tabela:" + idTb +". msg:" + ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
	
		
		
		
		//deletar a regra de duplicidade de uma base X a partir do id da tb, j� que a regra de duplicidade � unica por tabela
		public Resposta deletarDuplicidadePorId(int idTb) {
			Resposta resp = new Resposta();
			
			String sql;
			sql = "delete from REGRAS_VS_BASE  "
					+ "WHERE ID_REGRA = 6 AND ID_TB = ? ";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idTb);
				ps.executeUpdate();
				try{
		            conexao.commit();
		        }catch (SQLException ex){
		        	conexao.rollback();
		        	resp.setMensagem("Ocorreu um erro ao confirmar a transa��o"); 
		        	resp.setTipo(2);
		        }
			}catch(Exception ex) {
				resp.setMensagem("Ocorreu um erro ao deletar a regra de duplicidade da tabela de ID: " + idTb +". msg:" + ex.getMessage());
				resp.setTipo(2);
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
			resp.setMensagem("Regra exclu�da com sucesso!");
			resp.setTipo(1);
			return resp;
		}
		
	//deleta uma regra, apartir de seus IDs
	public Resposta deletarRegraPorId(int idRegra, int idCol, int idTb) {
		Resposta resp = new Resposta();
		String sql;
		sql = "delete from REGRAS_VS_BASE  "
				+ "WHERE ID_REGRA = ? AND ID_COLUNA = ? AND ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idRegra);
			ps.setInt(2, idCol);
			ps.setInt(3, idTb);
			ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	        	conexao.rollback();
	        	resp.setMensagem("Ocorreu um erro ao confirmar a transa��o"); 
	        	resp.setTipo(2);
	        	
	        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }
		}catch(Exception ex) {
			resp.setMensagem("Ocorreu um erro ao deletar a regra de ID: " + idRegra +". msg:" + ex.getMessage());
			resp.setTipo(2);
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
		resp.setMensagem("Regra exclu�da com sucesso!");
		resp.setTipo(1);
		return resp;
	}
	
	public List<ColunaTabela> listarCamposRange(int idTb){
		ColunaTabela coluna;
		List<ColunaTabela> colunas = new ArrayList();
		String sql;
		NumberFormat format = NumberFormat.getInstance(Locale.FRANCE);
		Number number = null;
		
		sql = "select a.NOME_COLUNA, b.DETALHE1 as RANGE_MIN, b.DETALHE2 as RANGE_MAX, a.ID_COLUNA  from coluna_tabela a " + 
				"inner join " + 
				"	REGRAS_VS_BASE b " + 
				"	ON(a.id_coluna = b.id_coluna and a.id_tb = b.id_tb) " + 
				"WHERE b.ID_REGRA = 3 " + 
				"AND a.ID_TB = ?";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, idTb);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				coluna = new ColunaTabela();
				coluna.setNomeColuna(rs.getString("NOME_COLUNA"));
				number = format.parse(rs.getString("RANGE_MIN"));
				double range_min = number.doubleValue();
				number = format.parse(rs.getString("RANGE_MAX"));
				double range_max = number.doubleValue();
				
				coluna.setRangeMin(range_min);
				coluna.setRangeMax(range_max);
				coluna.setIdColuna(rs.getInt("ID_COLUNA"));
				colunas.add(coluna);
			}
			
			return colunas;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public  List<Object> listarCamposDuplicidade(int idTb){
		String colunas ="";
		String sql;
		int idCol;
		List<Object> campos = new ArrayList();
		sql = "select (select a.NOME_COLUNA + ',' AS 'data()' from coluna_tabela a " + 
				"inner join " + 
				"	REGRAS_VS_BASE b " + 
				"	ON (a.id_coluna = b.id_coluna and a.id_tb = b.id_tb) " + 
				"WHERE b.ID_REGRA = 6 " + 
				"AND a.ID_TB = ? For XML PATH ('')) COLUNAS, (select ID_COLUNA from coluna_tabela where id_tb = ? and COLUNA_AUTOMATICA = 2) as ID_COL";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, idTb);
			ps.setInt(2, idTb);
			rs = ps.executeQuery();
			
			if(rs.next() && rs.getString("COLUNAS") != null) {
				colunas = rs.getString("COLUNAS");
				idCol = rs.getInt("ID_COL");
				
				colunas = colunas.substring(0, colunas.length()-1); //removendo a ultima virgula
				
				campos.add(colunas);
				campos.add(idCol);
			}
			
			return campos;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	public List<ColunaTabela> listarCamposMissing(int idTb){
		ColunaTabela coluna;
		List<ColunaTabela> colunas = new ArrayList();
		String sql;
		sql = "select a.NOME_COLUNA, a.ID_COLUNA from coluna_tabela a " + 
				"inner join " + 
				"	REGRAS_VS_BASE b " + 
				"	ON (a.id_coluna = b.id_coluna and a.id_tb = b.id_tb) " + 
				"WHERE b.ID_REGRA = 4 " + 
				"AND a.ID_TB = ?";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, idTb);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				coluna = new ColunaTabela();
				coluna.setIdColuna(rs.getInt("ID_COLUNA"));
				coluna.setNomeColuna(rs.getString("NOME_COLUNA"));
				colunas.add(coluna);
			}
			
			return colunas;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public List<ColunaTabela> listarCamposDominio(int idTb){
		ColunaTabela coluna;
		List<ColunaTabela> colunas = new ArrayList();
		String sql;
		sql = "select a.NOME_COLUNA, a.ID_COLUNA, b.DETALHE1 as DETALHE from coluna_tabela a " + 
				"inner join " + 
				"	REGRAS_VS_BASE b " + 
				"	ON (a.id_coluna = b.id_coluna and a.id_tb = b.id_tb) " + 
				"WHERE b.ID_REGRA = 5 " + 
				"AND a.ID_TB = ?";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, idTb);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				coluna = new ColunaTabela();
				coluna.setIdColuna(rs.getInt("ID_COLUNA"));
				coluna.setNomeColuna(rs.getString("NOME_COLUNA"));
				coluna.addRegra(new Regra(rs.getString("DETALHE")));
				colunas.add(coluna);
			}
			
			return colunas;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public List<ColunaTabela> listarCamposPSI(int idTb) {
		ColunaTabela coluna;
		List<ColunaTabela> colunas = new ArrayList();
		String sql;
		sql = "select a.NOME_COLUNA, a.ID_COLUNA, a.TIPO_COLUNA, b.DETALHE1, b.DETALHE2 from coluna_tabela a " + "inner join "
				+ "	REGRAS_VS_BASE b " + "	ON (a.id_coluna = b.id_coluna and a.id_tb = b.id_tb) "
				+ "WHERE b.ID_REGRA = 7 " + "AND a.ID_TB = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			rs = ps.executeQuery();

			while (rs.next()) {
				coluna = new ColunaTabela();
				coluna.setIdColuna(rs.getInt("ID_COLUNA"));
				coluna.setNomeColuna(rs.getString("NOME_COLUNA"));
				coluna.setTipoColuna(rs.getInt("TIPO_COLUNA"));
				coluna.addRegra(new Regra(rs.getString("DETALHE1")));
				coluna.addRegra(new Regra(rs.getString("DETALHE2")));
				colunas.add(coluna);
			}

			return colunas;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public String psiColuna(int idTb) {

		String frequencias = "";
		String sql;
		sql = "select DETALHE2 from REGRAS_VS_BASE where ID_COLUNA = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			rs = ps.executeQuery();

			while (rs.next()) {
				frequencias = rs.getString("DETALHE2");
			}

			return frequencias;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o detalhe da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public int getTipoColuna(int idCol) {

		int tipo = 0;
		String sql;
		sql = "select TIPO_COLUNA from coluna_tabela where ID_COLUNA = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idCol);
			rs = ps.executeQuery();

			while (rs.next()) {
				tipo = rs.getInt("TIPO_COLUNA");
			}

			return tipo;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o tipo da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public ArrayList<String> getDetalhesColunaPeloID(int idCol) {

		ArrayList<String> detalhes = new ArrayList<String>();
		String sql;
		sql = "select DETALHE1 from REGRAS_VS_BASE where ID_REGRA = 7 AND ID_COLUNA = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idCol);
			rs = ps.executeQuery();

			while (rs.next()) {
				detalhes.add(rs.getString("DETALHE1"));
			}

			return detalhes;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar os detalhes da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void inserirPSI(double psi, ColunaTabela coluna, String nmBase, String dtModificacao) {
		Resposta resp = new Resposta();
		String sql;
		sql = "Insert into CALCULOS_PSI(ID_REGRA, ID_TB, ID_COLUNA, PORCENT, DT_FLAG, NOME_BASE, JUSTIFICATIVA, DATA_JUSTIFICATIVA)"
				+ "values (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = null;
		
		int idCol = coluna.getIdColuna();
		int idTb = getIDTabelabyIDColIDRegra(idCol, 7);
			
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, 7);
			ps.setInt(2, idTb);
			ps.setInt(3, idCol);
			ps.setDouble(4, psi);
			ps.setString(5, dtModificacao);
			ps.setString(6, nmBase);
			ps.setString(7, "");
			ps.setString(8, "");
			ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	        	conexao.rollback();
	            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
	        	
	        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }

		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao inserir o registro na tabela: " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public boolean validarPSI(String base, int idTB, ColunaTabela coluna) {
		
		ArrayList<String> validar = new ArrayList<String>();
		String sql;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		int idCol = coluna.getIdColuna();
		String baseString = "%" + base + "%";
		
		sql = "select * from calculos_psi where ID_COLUNA = ? AND ID_TB = ? AND NOME_BASE LIKE ?";

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idCol);
			ps.setInt(2, idTB);
			ps.setString(3, baseString);
			rs = ps.executeQuery();
			while (rs.next()) {
				validar.add(String.valueOf(rs.getInt("ID_REGRA")));
				validar.add(String.valueOf(rs.getInt("ID_TB")));
				validar.add(String.valueOf(rs.getString("NOME_BASE")));
				validar.add(String.valueOf(rs.getInt("ID_COLUNA")));
				validar.add(String.valueOf(rs.getDouble("PORCENT")));
			}

			if (!validar.isEmpty()) {
				return false;
			}
			else {
				return true;
			}

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o tipo da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public int getIDTabelabyIDColIDRegra(int idCol, int idRegra) {

		int idTb = 0;
		String sql;
		sql = "select ID_TB from regras_vs_base where ID_COLUNA = ? AND ID_REGRA = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idCol);
			ps.setInt(2, idRegra);
			rs = ps.executeQuery();

			while (rs.next()) {
				idTb = rs.getInt("ID_TB");
			}

			return idTb;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o tipo da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public ArrayList<String[]> listarBasesPSI() {

		ArrayList<String[]> listaColunas = new ArrayList<String[]>();
		String sql;
		
		sql = "select t1.ID_TB, t1.NOME_BASE, b.ID_COLUNA, b.NOME_COLUNA from " + 
				"(select a.ID_TB, a.ID_COLUNA, t2.NOME_COLUNA from " + 
				"(select ID_COLUNA, ID_TB from regras_vs_base where ID_REGRA = 7)a " + 
				"INNER JOIN coluna_tabela t2 ON(t2.ID_COLUNA = a.ID_COLUNA))b INNER JOIN tabela_qualidade t1 " + 
				"ON(t1.ID_TB = b.ID_TB)";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				String[] lista = new String[4];
				lista[0] = String.valueOf(rs.getInt("ID_TB"));
				lista[1] = rs.getString("NOME_BASE");
				lista[2] = String.valueOf(rs.getInt("ID_COLUNA"));
				lista[3] = rs.getString("NOME_COLUNA");
				listaColunas.add(lista);
			}

			return listaColunas;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar os detalhes da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	public ArrayList<String[]> getAmostraPorIDCOL(int idCol) {

		ArrayList<String[]> listaColuna = new ArrayList<String[]>();
		String sql;
		sql = "select * from (select top 30 PORCENT, NOME_BASE from calculos_psi where ID_COLUNA = ? ORDER BY NOME_BASE DESC)a \r\n" + 
				"ORDER BY NOME_BASE ASC";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idCol);
			rs = ps.executeQuery();

			while (rs.next()) {
				String[] lista = new String[4];
				lista[0] = String.valueOf(rs.getDouble("PORCENT"));
				String database = rs.getString("NOME_BASE").substring(rs.getString("NOME_BASE").length() - 8, rs.getString("NOME_BASE").length());
				lista[1] = database.substring(6, 8) + "/" + database.substring(4, 6) + "/" + database.substring(0, 4);
				lista[2] = "0.1";
				lista[3] = "0.25";
				listaColuna.add(lista);
			}

			return listaColuna;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar os detalhes da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public int getQtdeBasesCadastradas() {
		
		int qtde = 0;
		String sql;
		sql = "select Count(*) as QTDE from tabela_qualidade where ID_TB > 1";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				qtde = rs.getInt("QTDE");
			}

			return qtde;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a quantidade de bases cadastradas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	public int getQtdeErrosBases() {
		
		int qtde = 0;
		String sql;
		sql = "select COUNT(distinct NOME_BASE) as QTDE from notificacoes where NOME_BASE NOT LIKE '%\"'";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				qtde = rs.getInt("QTDE");
			}

			return qtde;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a quantidade de bases cadastradas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	public int getQtdeAreasAtendidas() {
		
		int qtde = 0;
		String sql;
		sql = "select COUNT(*) as QTDE from SETORES";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				qtde = rs.getInt("QTDE");
			}

			return qtde;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a quantidade de bases cadastradas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	public int getQtdeColunasCadastradas() {
		
		int qtde = 0;
		String sql;
		sql = "select Count(*) as QTDE from coluna_tabela";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				qtde = rs.getInt("QTDE");
			}

			return qtde;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a quantidade de bases cadastradas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	public ArrayList<String[]> getQtdeNotiByDia(int idRegra, String nomeBase, String dtIni, String dtFim) {

		ArrayList<String[]> detalhes = new ArrayList<String[]>();
		String sql;
				
		if ((idRegra >= 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")) {
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from \r\n" + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA) where ID_REGRA = ? AND CAST(DATE_NOTIF as date) BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")){ 
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from " + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA) where CAST(DATE_NOTIF as date) BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else if ((idRegra < 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")){ 
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from \r\n" + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB))b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA) where CAST(DATE_NOTIF as date) BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")){ 
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from \r\n" + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA))tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else if ((idRegra >= 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")){ 
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from \r\n" + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB))b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA) where ID_REGRA = ? AND  CAST(DATE_NOTIF as date) BETWEEN Convert(Datetime,?,103) AND Convert(Datetime,?,103))tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else if ((idRegra >= 0) && (nomeBase == null || nomeBase == "") && (dtIni == null || dtIni == "")){ 
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from \r\n" + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB))b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA) where ID_REGRA = ?)tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else if ((idRegra >= 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")){ 
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from \r\n" + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA) where ID_REGRA = ?)tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")){ 
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF \r\n" + 
					"from \r\n" + 
					"	(select CAST(DATE_NOTIF as date) as DATE_NOTIF, ID_NOTIFICACAO, ID_REGRA\r\n" + 
					"	from notificacoes noti \r\n" + 
					"	INNER JOIN \r\n" + 
					"	(select distinct t1.NOME_BASE,t2.ID_COLUNA\r\n" + 
					"		from tabela_qualidade t1 INNER JOIN coluna_tabela t2 \r\n" + 
					"		ON(t1.ID_TB = t2.ID_TB) where t1.NOME_BASE LIKE ?)b \r\n" + 
					"ON(noti.ID_COLUNA = b.ID_COLUNA))tabela\r\n" + 
					"GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}else {
			sql = "select * from (select distinct top 30 CAST(DATE_NOTIF as date) as DATE_NOTIF, COUNT(ID_NOTIFICACAO) as QTDE_NOTIF from notificacoes GROUP BY CAST(DATE_NOTIF as date) ORDER BY CAST(DATE_NOTIF as date) DESC)a ORDER BY 1 ASC";
		}
		
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			rs = null;

			if ((idRegra >= 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, "%" + nomeBase + "%");
				ps.setInt(2, idRegra);
				ps.setString(3, dtIni);
				ps.setString(4, dtFim);
				rs = ps.executeQuery();
			} else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni != null && dtIni != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, "%" + nomeBase + "%");
				ps.setString(2, dtIni);
				ps.setString(3, dtFim);
				rs = ps.executeQuery();
			} else if ((idRegra < 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, dtIni);
				ps.setString(2, dtFim);
				rs = ps.executeQuery();
			} else if ((idRegra >= 0) && (nomeBase == null || nomeBase == "") && (dtIni != null && dtIni != "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idRegra);
				ps.setString(2, dtIni);
				ps.setString(3, dtFim);
				rs = ps.executeQuery();
			} else if ((idRegra >= 0) && (nomeBase == null || nomeBase == "") && (dtIni == null || dtIni == "")) {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idRegra);
				rs = ps.executeQuery();
			} else if ((idRegra >= 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")) {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, "%" + nomeBase + "%");
				ps.setInt(2, idRegra);
				rs = ps.executeQuery();
			} else if ((idRegra < 0) && (nomeBase != null && nomeBase != "") && (dtIni == null || dtIni == "")) {
				ps = conexao.prepareStatement(sql);
				ps.setString(1, "%" + nomeBase + "%");
				rs = ps.executeQuery();
			} else {
				Statement stmt = conexao.createStatement();
				rs = stmt.executeQuery(sql);
			}

			while (rs.next()) {
				String[] qtde = new String[2];
				String data = rs.getString("DATE_NOTIF");
				qtde[0] = data.substring(8,10) + "/" + data.substring(5,7) + "/" +data.substring(0,4);
				qtde[1] = rs.getString("QTDE_NOTIF");
				detalhes.add(qtde);
			}

			return detalhes;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar os detalhes da coluna: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
}
