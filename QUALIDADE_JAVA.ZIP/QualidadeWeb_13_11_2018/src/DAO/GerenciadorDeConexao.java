package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class GerenciadorDeConexao {

       private Connection conexao;
       private BaseDAO base;
       private ObservacaoDAO obs;
       private RegraDAO regra;
       private NotificacaoDAO notificacao;
       private tabelaXDAO tbX;
       
       public void iniciar() {
             
             Context envContext = null;
             DataSource dataSource = null;
             
             
             try {
                    Context ctx = new InitialContext();
                 //envContext  = (Context)ctx.lookup("java:/comp/env");
                 //dataSource = (DataSource)envContext.lookup("jdbc/qualidadeDB");
                    dataSource = (DataSource) ctx.lookup("java:comp/env/jdbc/dataquality_sqlServer");
                   	System.out.println("conectado com sucesso!JNDI");
                    conexao = dataSource.getConnection();
                    conexao.setAutoCommit(false);
                    
                    tbX = new tabelaXDAO(conexao);
                    base = new BaseDAO(conexao);
                    obs = new ObservacaoDAO(conexao);
                    regra = new RegraDAO(conexao);
                    notificacao = new NotificacaoDAO(conexao);
                    
             } catch (Exception e){
                 e.printStackTrace();
                 //return null;
             }finally {
                 if(envContext != null){
                     try{
                        envContext.close();
                     } catch (NamingException e){
                          System.out.println();
                         e.printStackTrace();
                     }
                 }
             }
       }
       
       public BaseDAO getObjetoBase() {
             return base;
       }
       
       public tabelaXDAO getObjetoX() {
             return tbX;
       }
       
       public ObservacaoDAO getObjetoObs() {
             return obs;
       }
       
       public RegraDAO getObjetoRegraDAO() {
             return regra;
       }
       
       public NotificacaoDAO getObjetoNotificacaoDAO() {
             return notificacao;
       }
       
       public Connection getConnection() {
             return conexao;
       }
       
    public void encerrar() 
    {
        try {
            if(conexao != null) {
                conexao.close();
                conexao = null;
            }
        } catch (SQLException ex) {
            
        }
        System.out.println("Conex�o encerrada com sucesso JNDI");
    }

    public void confirmarTransacao() {
        try{
            conexao.commit();
        }catch (SQLException ex){
            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
        }
    }

    public void abortarTransacao() {
        try{
            conexao.rollback();
        }catch(SQLException ex){
        
            throw new DAOException("Ocorreu um erro ao abortar a opera��o."); //To change body of generated methods, choose Tools | Templates.
       
        }
    }

    /**
     * Fechar statement.
     * @param stmt Statement.
     * @return Null.
     */
    public static <T extends Statement> T close(T stmt) {
    	if (stmt != null) {
    		try {
    			stmt.close();
    		} catch (Exception except) {    			
    		}
    	}
    	return null;
    }
    
    /**
     * Fechar resultset..
     * @param results resultset.
     * @return Null.
     */
    public static ResultSet close(ResultSet results) {
    	if (results != null) {
    		try {
    			results.close();
    		} catch (Exception except) {    			
    		}
    	}
    	return null;
    }
    
}
