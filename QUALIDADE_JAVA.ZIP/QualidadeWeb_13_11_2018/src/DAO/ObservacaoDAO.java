package DAO;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import model.Base;
import model.ColunaTabela;
import model.Observacao;

public class ObservacaoDAO {

	private Connection conexao;
	
	public ObservacaoDAO(Connection conexao) {
		this.conexao = conexao;
	}
	
	public void inserirTabelaAmostragem(int idBase, ArrayList<List> tabela) {
		
		//deleteTabelaAmostragem(idBase);
		
		String sql;
		for(List lista : tabela) {
			double numObs = (double) lista.get(0);
			double desvio = (double) lista.get(1); 
			double media = (double) lista.get(2);
			double range = (double) lista.get(3); 
			double mediaRange = (double) lista.get(4);
			double lmtInfVer = (double) lista.get(5);
			double lmtInfAma = (double) lista.get(6);
			double lmtSupAma = (double) lista.get(7);
			double lmtSupVer = (double) lista.get(8); 
			double desvioNecess = (double) lista.get(9); 
			double desvioBaixo = (double) lista.get(10);
			double desvioCima = (double) lista.get(11);
			int flag = (int) lista.get(12);
			String dataFlag = (String) lista.get(13);
			String nomeBase = (String) lista.get(14);
			
			sql = "Insert into calculos_observacao"
					+ "(ID_TB, NOBS, DESVIO, MEDIA, RANGES, R_MEDIA, LIM_INF_VER, LIM_INF_AMA, LIM_SUP_AMA,"
					+ " LIM_SUP_VER, DESV_NECESSARIO, QTD_DESV_ABAIXO,  QTD_DESV_ACIMA, FLAG, DT_FLAG, JUSTIFICATIVA, DATA_JUSTIFICATIVA, CONSIDERAR, NOME_BASE) "
					+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql); 
				ps.setInt(1, idBase);
				ps.setDouble(2, numObs);
				ps.setDouble(3, desvio);
				ps.setDouble(4, media);
				ps.setDouble(5, range);	
				ps.setDouble(6, mediaRange);
				ps.setDouble(7, lmtInfVer);
				ps.setDouble(8, lmtInfAma);
				ps.setDouble(9, lmtSupAma);
				ps.setDouble(10, lmtSupVer);
				ps.setDouble(11, desvioNecess);
				ps.setDouble(12, desvioBaixo);
				ps.setDouble(13, desvioCima);
				ps.setInt(14, flag);
				ps.setString(15, dataFlag);
				ps.setString(16, "");
				ps.setString(17, "");
				ps.setInt(18, 0);
				ps.setString(19, nomeBase);
				ps.executeUpdate();
				try{
		            conexao.commit();
		        }catch (SQLException ex){
		        	conexao.rollback();
		            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
		        	
		        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
		        }
				
			}catch(Exception ex) {
				throw new DAOException("Ocorreu um erro ao inserir o registro na tabela: " + ex.getMessage());
				
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}
		
			
		
	}
	

	
	public void deleteTabelaAmostragem(int idTabela) {
		String sql;
		sql = "delete from calculos_observacao  "
				+ "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTabela);
			ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	        	conexao.rollback();
	            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); 
	        	
	        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }
		}catch(Exception ex) {
			throw new DAOException("ocorreu um erro ao deletar as colunas da tabela de ID:" + idTabela + 
					". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	//retorno uma lista com a amostra da tabela X
	public List getAmostraPorID(int id, int tamanho) {

		List<Observacao> linhasAmostra = new ArrayList();
		
		String sql;
		Observacao obs;
		
		sql = "Select * From (Select top "+tamanho+""
				+ "* "
			+ "FROM calculos_observacao WHERE ID_TB = ? ORDER BY CONVERT(DateTime, DT_FLAG,103) DESC)a ORDER BY CONVERT(DateTime, DT_FLAG,103) ASC";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				obs = new Observacao();
				obs.setIdTabela(rs.getInt("ID_TB"));
				obs.setNumObs(rs.getDouble("NOBS"));
				obs.setDesvio(rs.getDouble("DESVIO"));
				obs.setMedia(rs.getDouble("MEDIA"));
				obs.setRangeIndividual(rs.getDouble("RANGES"));
				obs.setMediaRange(rs.getDouble("R_MEDIA"));
				obs.setLmtInfVer(rs.getDouble("LIM_INF_VER"));
				obs.setLmtInfAma(rs.getDouble("LIM_INF_AMA"));
				obs.setLmtSupAma(rs.getDouble("LIM_SUP_AMA"));
				obs.setLmtSupVer(rs.getDouble("LIM_SUP_VER"));
				obs.setDesvioNecess(rs.getDouble("DESV_NECESSARIO"));
				obs.setDesvioBaixo(getLimiteInferior(obs.getIdTabela()));
				obs.setDesvioCima(getLimiteSuperior(obs.getIdTabela()));
				obs.setFlag(rs.getInt("FLAG"));
				obs.setDataFlag(rs.getString("DT_FLAG"));
				obs.setNomeBase(rs.getString("NOME_BASE"));
				obs.setConsiderar(rs.getInt("CONSIDERAR"));
				
				linhasAmostra.add(obs);
			}
					
			return linhasAmostra;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	
	public ArrayList<Double> getAmostraParaCalPorID(int id, int tamanho) {

		ArrayList<Double> linhasAmostra = new ArrayList<Double>();
		
		String sql;
		
		sql = "Select * From (Select top "+tamanho+""
				+ "* "
			+ "FROM calculos_observacao WHERE ID_TB = ? and CONSIDERAR = 0 ORDER BY CONVERT(DateTime, DT_FLAG,103) DESC)a ORDER BY CONVERT(DateTime, DT_FLAG,103) ASC";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				linhasAmostra.add(rs.getDouble("NOBS"));
			}
					
			return linhasAmostra;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	public ArrayList<Double> getRangeParaCalPorID(int id, int tamanho) {

		ArrayList<Double> linhasAmostra = new ArrayList<Double>();
		
		String sql;
		
		sql = "Select * From (Select top "+tamanho+""
				+ "* "
			+ "FROM calculos_observacao WHERE ID_TB = ? ORDER BY CONVERT(DateTime, DT_FLAG,103) DESC)a ORDER BY CONVERT(DateTime, DT_FLAG,103) ASC";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				linhasAmostra.add(rs.getDouble("RANGES"));
			}
					
			return linhasAmostra;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	public ArrayList<Double> getRangeMediaParaCalPorID(int id, int tamanho) {

		ArrayList<Double> linhasAmostra = new ArrayList<Double>();
		
		String sql;
		
		sql = "Select * From (Select top "+tamanho+""
				+ "* "
			+ "FROM calculos_observacao WHERE ID_TB = ? and CONSIDERAR = 0 ORDER BY CONVERT(DateTime, DT_FLAG,103) DESC)a ORDER BY CONVERT(DateTime, DT_FLAG,103) ASC";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				linhasAmostra.add(rs.getDouble("R_MEDIA"));
			}
					
			return linhasAmostra;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	public ArrayList<Double> getQtdeDesvHist(int id, int tamanho) {

		ArrayList<Double> linhasAmostra = new ArrayList<Double>();
		
		String sql;
		
		sql = "Select DESV_NECESSARIO From (Select top "+tamanho+""
				+ "* "
			+ "FROM calculos_observacao WHERE ID_TB = ?  and CONSIDERAR = 0 ORDER BY CONVERT(DateTime, DT_FLAG,103) DESC)a ORDER BY CONVERT(DateTime, DT_FLAG,103) ASC";
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				linhasAmostra.add(rs.getDouble("DESV_NECESSARIO"));
			}
					
			return linhasAmostra;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());

		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	//lista todas as bases que tem calculado valores de observa��o, para montar o grafico da mesma.
	public List<Base> listarBasesObs() {
		String sql;
		List<Base> listaBases = new ArrayList();
		Base base;
		
		sql= "select distinct t1.ID_TB, t1.NOME_BASE from tabela_qualidade t1 " + 
				"INNER JOIN calculos_observacao t2 " + 
				"ON (t1.ID_TB = t2.ID_TB) where t1.ID_TB > 1 ORDER BY 1 DESC";
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				base = new Base();
				base.setIdTabela(rs.getInt("ID_TB"));
				base.setNomeBase(rs.getString("NOME_BASE"));
				listaBases.add(base);
			}
			
			return listaBases;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de bases: " + ex.getMessage());

		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	public List<Base> listarBasesPSI() {
		String sql;
		List<Base> listaBases = new ArrayList();
		Base base;
		
		sql= "select distinct t1.ID_COLUNA, NOME_BASE from coluna_tabela t1 " + 
				"INNER JOIN calculos_psi t2 " + 
				"ON (t1.ID_COLUNA = t2.ID_COLUNA)";
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				base = new Base();
				base.setIdTabela(rs.getInt("ID_COLUNA"));
				base.setNomeBase(rs.getString("NOME_BASE"));
				listaBases.add(base);
			}
			
			return listaBases;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de bases: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}
	
	public double getLimiteSuperior(int id) {
		double limite = 0;
		String sql;
		
		sql= "select LIMITE_SUPERIOR from tabela_qualidade where ID_TB = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				limite = rs.getDouble("LIMITE_SUPERIOR");
			}
			
			return limite;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o limite superior: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	public double getLimiteInferior(int id) {
		double limite = 0;
		String sql;
		
		sql= "select LIMITE_INFERIOR from tabela_qualidade where ID_TB = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				limite = rs.getDouble("LIMITE_INFERIOR");
			}
			
			return limite;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o limite inferior: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	public String getUltimaInsercaoRegbyId(int id) {
		String max = "";
		String sql;
		
		sql= "select convert(varchar(255),MAX(convert(DATETIME, DT_FLAG, 103)),103) + ' ' + convert(varchar(255),MAX(convert(DATETIME, DT_FLAG, 103)),108) as MAX \r\n" + 
				"from calculos_observacao where ID_TB = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				max = rs.getString("MAX");
			}
			
			return max;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o limite inferior: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		
	}
	
	public double getQtdeRegBaseNSafrada(int idTB) {
		double qtde = 0;
		String sql;
		
		sql= "select sum(NOBS) as SOMA_NOBS from calculos_observacao where ID_TB = ? and CONSIDERAR = 0";
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, idTB);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				qtde = rs.getDouble("SOMA_NOBS");
			}
			
			return qtde;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o limite inferior: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	public boolean jaExisteAmostragem(int idTB, String nomeBase, String dataModificacao) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int cont = 0;
		boolean isreprocessamento = false;

		sql = "select count(*) as QTDE from calculos_observacao where ID_TB = ? and NOME_BASE = ? AND DT_FLAG = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTB);
			ps.setString(2, nomeBase);
			ps.setString(3, dataModificacao.trim());
			rs = ps.executeQuery();

			if (rs.next()) {
				cont = rs.getInt("QTDE");
			}

			if (cont > 0) {
				isreprocessamento = true;
			}

			return isreprocessamento;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o id pelo nome: " + nomeBase + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
}
