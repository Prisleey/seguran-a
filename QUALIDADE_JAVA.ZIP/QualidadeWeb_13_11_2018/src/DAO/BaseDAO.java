package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Base;
import model.ColunaTabela;
import model.Resposta;
import model.ServidorSAS;
import model.Setor;

public class BaseDAO {

	private Connection conexao;

	public BaseDAO(Connection conexao) {
		this.conexao = conexao;
	}

public int inserirTabela(Base obj, String matricula) {
		
		int id;
		Base base;
		base = new Base();
		try {
			id = getProximoId();	
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o proximo ID da tabela: " + ex.getMessage());
		}
		String sql;
		if(obj.getTipoLayout() == 1) {
			sql = "Insert into tabela_qualidade"
					+ "(ID_TB, NOME_BASE, CONEXAO, MAT_RESPONSAVEL, TIPO_BASE, USR_INI, USR_ATU, LIMITE_SUPERIOR, LIMITE_INFERIOR, ID_SETOR, TIPO_LAYOUT, PERIODICIDADE, SAFRADA, TAMANHO_AMOSTRA, FULL_INCREMENTAL, NOME_BASE_MODELO, EMAIL_RESPONSAVEL) "
					+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		}else {
			sql = "Insert into tabela_qualidade"
					+ "(ID_TB, NOME_BASE, CONEXAO, MAT_RESPONSAVEL, TIPO_BASE, USR_INI, USR_ATU, LIMITE_SUPERIOR, LIMITE_INFERIOR, ID_SETOR, TIPO_LAYOUT, PERIODICIDADE, SAFRADA, TAMANHO_AMOSTRA, FULL_INCREMENTAL, NOME_BASE_MODELO, EMAIL_RESPONSAVEL) "
					+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		}
		
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql); 
			ps.setInt(1, id);
			ps.setString(2, obj.getNomeBase());
			ps.setString(3, obj.getConexao());
			ps.setString(4, obj.getMatriculaResponsavel());
			ps.setString(5, obj.getTipoBase());
			ps.setString(6, matricula);
			ps.setString(7, matricula);
			ps.setDouble(8, obj.getLimiteSuperior());
			ps.setDouble(9, obj.getLimiteInferior());
			ps.setInt(10, obj.getSetor().getIdSetor());
			ps.setInt(11, obj.getTipoLayout());
			ps.setString(12, obj.getPeriodicidade());
			ps.setInt(13, obj.getSafrada());
			ps.setInt(14, obj.getTamanhoAmostra());
			ps.setString(15, obj.getIncrem_full());
			if(obj.getTipoLayout() == 1){
				ps.setString(16, obj.getNomeBaseLayout());
				ps.setString(17, obj.getEmailResponsavel());
			}else {
				ps.setString(16, obj.getNomeBaseLayout());
				ps.setString(17, obj.getEmailResponsavel());
			}
			ps.executeUpdate();
			try{
	            conexao.commit();
	        }catch (SQLException ex){
	        	conexao.rollback();
	            throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To change body of generated methods, choose Tools | Templates.
	        	
	        	//return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To change body of generated methods, choose Tools | Templates.
	        }
			
			if(obj.getTipoBase().equals("SAS")) {
				inserirServidorSASNaBase(id, obj.getServidorSAS().getIdServidor());
			}
			
			return id;
			
		}catch(Exception ex) {
			throw new DAOException("Ocorreu um erro ao inserir o registro na tabela: " + ex.getMessage());
			
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
			
		
	}

	private void inserirServidorSASNaBase(int idTb, int idServidor) {
		String sql;
		sql = "Insert into TABELA_VS_SERVIDOR_SAS" + "(ID_TB, ID_SERVIDOR) " + "values (?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			ps.setInt(2, idServidor);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o " + ex.getMessage()); // To change body
																										// of generated
																										// methods,
																										// choose Tools
																										// | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException(
					"Ocorreu um erro ao inserir o registro na TABELA_VS_SERVIDOR_SAS: " + ex.getMessage());

		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public Resposta inserirColunas(List<ColunaTabela> colunas, int idTabela, String matricula) {

		deletarRegraPorIdBase(idTabela);
		deleteColunas(idTabela);

		Resposta resp = new Resposta();
		for (ColunaTabela obj : colunas) {
			String sql;
			sql = "Insert into coluna_tabela"
					+ "(ID_TB, NOME_COLUNA, TIPO_COLUNA, TAMANHO_COLUNA, ORDEM, USR_INI, USR_ATU, COLUNA_AUTOMATICA)"
					+ "values (?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = null;
			try {
				ps = conexao.prepareStatement(sql);
				ps.setInt(1, idTabela);
				ps.setString(2, obj.getNomeColuna());
				ps.setInt(3, obj.getTipoColuna());
				ps.setInt(4, obj.getTamanhoColuna());
				ps.setInt(5, obj.getNumOrdem());
				ps.setString(6, matricula);
				ps.setString(7, matricula);
				ps.setInt(8, obj.getColunaAutomatica());
				ps.executeUpdate();
				try {
					conexao.commit();
				} catch (SQLException ex) {
					conexao.rollback();
					// throw new DAOException("Ocorreu um erro ao confirmar a transa��o"); //To
					// change body of generated methods, choose Tools | Templates.
					resp.setMensagem("Ocorreu um erro ao confirmar a transa��o" + ex.getMessage());
					resp.setTipo(2); // erro
					return resp;
					// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
					// change body of generated methods, choose Tools | Templates.
				}

			} catch (Exception ex) {
				// throw new DAOException("Ocorreu um erro ao inserir o registro na tabela
				// Teste: " + ex.getMessage());
				resp.setMensagem("\"Ocorreu um erro ao inserir o registro na tabela: " + ex.getMessage());
				resp.setTipo(2); // erro
				return resp;
				// return ("Ocorreu um erro ao inserir o registro na tabela Teste: " +
				// ex.getMessage());
			} finally {
				ps = GerenciadorDeConexao.close(ps);
			}
		}

		resp.setMensagem("Registro inserido com sucesso");
		resp.setTipo(1);
		return resp;
		// return "Registro inserido com sucesso";

	}

	// lista todas as bases cadastradas, futuramente o metodo deve ser filtrado por
	// usu�rio
	public List<Base> listarTodos() {
		List<Base> listaBases = new ArrayList();
		String sql;
		Base base;

		sql = "Select " + "ID_TB, " + "NOME_BASE, " + "CONEXAO, " + "MAT_RESPONSAVEL, " + "TIPO_BASE, "
				+ "PERIODICIDADE, " + "SAFRADA," + "TAMANHO_AMOSTRA, " + "FULL_INCREMENTAL, " + "LIMITE_SUPERIOR, "
				+ "LIMITE_INFERIOR " + "FROM TABELA_QUALIDADE where TIPO_BASE = 'SAS' ORDER BY 1 DESC";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				base = new Base();
				base.setIdTabela(rs.getInt("ID_TB"));
				base.setNomeBase(rs.getString("NOME_BASE"));
				base.setConexao(rs.getString("CONEXAO"));
				base.setMatriculaResponsavel(rs.getString("MAT_RESPONSAVEL"));
				base.setTipoBase(rs.getString("TIPO_BASE"));
				base.setPeriodicidade(rs.getString("PERIODICIDADE"));
				base.setSafrada(rs.getInt("SAFRADA"));
				base.setTamanhoAmostra(rs.getInt("TAMANHO_AMOSTRA"));
				base.setIncrem_full(rs.getString("FULL_INCREMENTAL"));
				base.setLimiteInferior(rs.getDouble("LIMITE_INFERIOR"));
				base.setLimiteSuperior(rs.getDouble("LIMITE_SUPERIOR"));
				listaBases.add(base);
			}

			return listaBases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de bases: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
		
	}

	public ServidorSAS getServidorSASByIdTabela(int idTb) {
		String sql;
		ServidorSAS s = new ServidorSAS();
		sql = "SELECT t1.NOME_SERVIDOR, t1.HOST_NAME, t1.PORTA FROM SERVIDORES_SAS t1 "
				+ "INNER JOIN TABELA_VS_SERVIDOR_SAS t2 ON (t1.ID_SERVIDOR = t2.ID_SERVIDOR) "
				+ "WHERE t2.ID_TB = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			rs = ps.executeQuery();

			if (rs.next()) {
				s.setNomeServidor(rs.getString("NOME_SERVIDOR"));
				s.setHostName(rs.getString("HOST_NAME"));
				s.setPorta(rs.getInt("PORTA"));
			}

			return s;

		} catch (Exception ex) {
			throw new DAOException(
					"Ocorreu um erro ao retornar o servidor da base SAS de ID: " + idTb + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public ServidorSAS getServidorSasByIdWorkSpace(int idWorkSpace) {
		String sql;
		ServidorSAS s = new ServidorSAS();
		sql = "SELECT " + "t1.NOME_SERVIDOR, " + "t1.HOST_NAME, " + "t1.PORTA " + "FROM SERVIDORES_SAS t1 "
				+ "WHERE t1.ID_SERVIDOR = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idWorkSpace);
			rs = ps.executeQuery();

			if (rs.next()) {
				s.setNomeServidor(rs.getString("NOME_SERVIDOR"));
				s.setHostName(rs.getString("HOST_NAME"));
				s.setPorta(rs.getInt("PORTA"));
			}

			return s;

		} catch (Exception ex) {
			throw new DAOException(
					"Ocorreu um erro ao retornar o servidor de ID: " + idWorkSpace + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// metodo retorna uma base, dado um ID como parametro de busca
	public Base getBasePeloID(int id) {
		String sql;
		Base base;
		base = new Base();

		sql = "Select  t1.ID_TB, t1.NOME_BASE, t1.CONEXAO, t1.MAT_RESPONSAVEL, t1.EMAIL_RESPONSAVEL, t1.TIPO_BASE, t1.ID_SETOR,\r\n"
				+ "		t3.NOME_SETOR,t2.ID_SERVIDOR, t1.LIMITE_SUPERIOR, t1.LIMITE_INFERIOR, t1.TIPO_LAYOUT, t1.NOME_BASE_MODELO,\r\n"
				+ "		t1.PERIODICIDADE, t1.SAFRADA, t1.TAMANHO_AMOSTRA, t1.FULL_INCREMENTAL\r\n"
				+ "FROM TABELA_QUALIDADE t1\r\n" + "	left JOIN TABELA_VS_SERVIDOR_SAS t2\r\n"
				+ "	ON (t1.ID_TB = t2.ID_TB)\r\n" + "	left join Setores t3\r\n"
				+ "	ON(t1.ID_SETOR = t3.ID_SETOR)\r\n" + "WHERE t1.ID_TB = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();

			if (rs.next()) {

				base.setIdTabela(rs.getInt("ID_TB"));
				base.setNomeBase(rs.getString("NOME_BASE"));
				base.setConexao(rs.getString("CONEXAO"));
				base.setMatriculaResponsavel(rs.getString("MAT_RESPONSAVEL"));
				base.setEmailResponsavel(rs.getString("EMAIL_RESPONSAVEL"));
				base.setTipoBase(rs.getString("TIPO_BASE"));
				base.setSetor(new Setor(rs.getInt("ID_SETOR"), rs.getString("NOME_SETOR")));
				base.setServidorSAS(new ServidorSAS(rs.getInt("ID_SERVIDOR")));
				base.setLimiteSuperior(rs.getDouble("LIMITE_SUPERIOR"));
				base.setLimiteInferior(rs.getDouble("LIMITE_INFERIOR"));
				base.setTipoLayout(rs.getInt("TIPO_LAYOUT"));
				base.setNomeBaseLayout(rs.getString("NOME_BASE_MODELO"));
				base.setPeriodicidade(rs.getString("PERIODICIDADE"));
				base.setSafrada(rs.getInt("SAFRADA"));
				base.setTamanhoAmostra(rs.getInt("TAMANHO_AMOSTRA"));
				base.setIncrem_full(rs.getString("FULL_INCREMENTAL"));
				base.addListaColunas(getColunasPeloID(id));
			}

			return base;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a base: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// retorna todas as colunas de uma tabela x, apartir do ID dessa tabela
	public List<ColunaTabela> getColunasPeloID(int id) {
		List<ColunaTabela> listaColunas = new ArrayList();
		String sql;
		ColunaTabela coluna;

		sql = "Select " + "ID_COLUNA, NOME_COLUNA, " + "TIPO_COLUNA, " + "TAMANHO_COLUNA, " + "ORDEM "
				+ "FROM coluna_tabela WHERE coluna_automatica = 1 and ID_TB = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();

			while (rs.next()) {
				coluna = new ColunaTabela();
				coluna.setIdColuna(rs.getInt("ID_COLUNA"));
				coluna.setNomeColuna(rs.getString("NOME_COLUNA"));
				coluna.setTamanhoColuna(rs.getInt("TAMANHO_COLUNA"));
				coluna.setTipoColuna(rs.getInt("TIPO_COLUNA"));
				coluna.setNumOrdem(rs.getInt("ORDEM"));
				listaColunas.add(coluna);
			}

			return listaColunas;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// faz update na base a partir do ID dela, lembrando que aqui ainda n�o � feito
	// o update das colunas dessa base
	public Resposta updateBasePeloID(Base objBase, String matricula) {
		Resposta resp = new Resposta();
		String sql;
		sql = "UPDATE tabela_qualidade SET "
				+ "NOME_BASE = ?, CONEXAO = ?, MAT_RESPONSAVEL =?, TIPO_BASE  = ?, USR_ATU = ?, LIMITE_SUPERIOR = ?, LIMITE_INFERIOR = ?, ID_SETOR = ?, NOME_BASE_MODELO = ?, PERIODICIDADE = ?, SAFRADA = ?, EMAIL_RESPONSAVEL = ? "
				+ "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, objBase.getNomeBase());
			ps.setString(2, objBase.getConexao());
			ps.setString(3, objBase.getMatriculaResponsavel());
			ps.setString(4, objBase.getTipoBase());
			ps.setString(5, matricula);
			ps.setDouble(6, objBase.getLimiteSuperior());
			ps.setDouble(7, objBase.getLimiteInferior());
			ps.setInt(8, objBase.getSetor().getIdSetor());
			ps.setString(9, objBase.getNomeBaseLayout());
			ps.setString(10, objBase.getPeriodicidade());
			ps.setInt(11, objBase.getSafrada());
			ps.setString(12, objBase.getEmailResponsavel());
			ps.setInt(13, objBase.getIdTabela());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o");
				resp.setTipo(2);// erro
				return resp;
				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			resp.setMensagem("ocorreu um erro ao fazer update na base de ID:" + objBase.getIdTabela() + ". msg:"
					+ ex.getMessage());
			resp.setTipo(2); // erro
			return resp;
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}

		if (objBase.getTipoBase().equals("SAS")) {
			updateServidorPeloId(objBase.getServidorSAS().getIdServidor(), objBase.getIdTabela());
		}

		resp.setMensagem("Registro Atualizado com Sucesso!");
		resp.setTipo(1);// sucesso
		return resp;
	}

	// faz update no servidor das bases SAS pelo ID da tabela
	public void updateServidorPeloId(int idServidor, int idTb) {
		String sql;
		sql = "UPDATE TABELA_VS_SERVIDOR_SAS SET " + "ID_SERVIDOR = ?  " + "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idServidor);
			ps.setInt(2, idTb);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("ocorreu um erro ao fazer update no servidor SAS ID:" + idServidor + ". tabela: "
					+ idTb + ". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// 1 - est� rodando, 0 - n�o est� rodando
	public void updateQualidadeRunning(int status) {
		String sql;
		sql = "UPDATE QUALIDADE_RUNNING SET " + "ESTA_RODANDO = ? ";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, status);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");
				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException(
					"ocorreu um erro ao fazer update no status 'running' da qualidade:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// checa se a qualdiade est� rodando no momento: 1 - Running, 0 - Stoped, -1 -
	// Error
	public int checarQualidade() {

		int status = -1;
		String sql;
		sql = "select ESTA_RODANDO FROM QUALIDADE_RUNNING ";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			if (rs.next()) {
				status = rs.getInt("ESTA_RODANDO");
			}

			return status;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar o status da thread de qualidade: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
	}

	public void updateColunaPeloId(ColunaTabela coluna, String matriculaEdit) {
		String sql;
		sql = "UPDATE coluna_tabela SET " + "NOME_COLUNA = ?, TIPO_COLUNA = ?, TAMANHO_COLUNA =?, USR_ATU = ? "
				+ "WHERE ID_COLUNA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, coluna.getNomeColuna());
			ps.setInt(2, coluna.getTipoColuna());
			ps.setInt(3, coluna.getTamanhoColuna());
			ps.setString(4, matriculaEdit);
			ps.setInt(5, coluna.getIdColuna());
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("ocorreu um erro ao fazer update na coluna de ID:" + coluna.getIdColuna() + ". msg:"
					+ ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public Resposta deletarBasePeloId(int idTb) {
		deletarRegraPorIdBase(idTb);
		deleteColunas(idTb);
		deletaServidorPorId(idTb);
		deleteTabelaAmostragem(idTb);

		Resposta resp = new Resposta();
		String sql;
		sql = "delete from tabela_qualidade  " + "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o");
				resp.setTipo(2);

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			resp.setMensagem("ocorreu um erro ao deletar a base de ID:" + idTb + ". msg:" + ex.getMessage());
			resp.setTipo(2);
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
		resp.setMensagem("A base e suas regras foram exclu�das com sucesso!");
		resp.setTipo(1);

		return resp;
	}

	// deleta a anota��o de servidor vs base pelo id da base
	private void deletaServidorPorId(int idTb) {
		String sql = "delete from TABELA_VS_SERVIDOR_SAS  " + "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");
			}
		} catch (Exception ex) {
			throw new DAOException(
					"ocorreu um erro ao deletar a o servidorSAS da tabela de ID:" + idTb + ". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// deleta uma regra, apartir de seus IDs
	public void deletarRegraPorIdBase(int idTb) {
		String sql;
		sql = "delete from REGRAS_VS_BASE  " + "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException(
					"Ocorreu um erro ao deletar a regra da tabela de ID: " + idTb + ". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}

	}

	public void deleteColunas(int id) {
		String sql;
		sql = "delete from coluna_tabela  " + "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException(
					"ocorreu um erro ao deletar as colunas da tabela de ID:" + id + ". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void deleteColunaByID(int idTb, int idCol) {
		String sql;
		sql = "delete from coluna_tabela  " + "WHERE ID_TB = ? AND ID_COLUNA = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			ps.setInt(2, idCol);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("ocorreu um erro ao deletar a coluna de ID:" + idCol + " da tabela de ID:" + idTb
					+ ". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// este metodo checa se um registro existe na base, se o registro n�o existe �
	// um INSERT, se ele existe � um UPDATE
	public boolean checkRegistroExiste(int id) {
		String sql;
		sql = "Select ID_TB from tabela_qualidade where ID_TB = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao verificar o Id informado: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

	}

	public int getProximoId() {
		String sql;
		sql = "Select " + " case when max(id_tb) is not null then " + "max(id_tb)+1 " + "else " + " 1 " + " end as id "
				+ "from tabela_qualidade ";
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				int id;
				id = rs.getInt("id");
				return id;
			}
		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro no select do objeto");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
		return 0;
	}

	// maneira de saber se uma base ja rodou
	public void inserirBaseRodadas(String nomeBase, int statusBase) {
		String sql;
		sql = "insert into TABELAS_RUN (NOME_BASE, STATUS) values (?, ?) ";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.setInt(2, statusBase);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao inserir a tabela nas tabelas rodadas " + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// tipo 1 checa so se ja rodou somente se teve sucesso, tipo 2 checa se rodou,
	// independentemente de sucesso ou n�o
	public int checarSeJaExisteBaseRodada(String nomeBase, int tipo) {
		String sql;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int contador = 0;
		if (tipo == 1) {
			sql = "select count(NOME_BASE) as contador from TABELAS_RUN WHERE NOME_BASE = ? AND STATUS = 1";
		} else {
			sql = "select count(NOME_BASE) as contador from TABELAS_RUN WHERE NOME_BASE = ?";
		}

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			rs = ps.executeQuery();
			if (rs.next()) {
				contador = rs.getInt("contador");
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao checar se a tabela j� existe. " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return contador;
	}

	public int checarSeBaseExiste(String nomeBase) {
		String sql;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int contador = 0;
		sql = "select Count(NOME_BASE) as contador from tabela_qualidade WHERE NOME_BASE = ?";

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			rs = ps.executeQuery();
			if (rs.next()) {
				contador = rs.getInt("contador");
			}
		} catch (Exception ex) {
			throw new DAOException("Erro ao checar se a tabela j� existe. " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return contador;
	}

	// faz o update do status de uma base que j� foi rodada, na lista de bases
	// rodadas
	public void updateBaseRodada(String nomeBase, int status) {
		String sql;
		sql = "update TABELAS_RUN set STATUS = ? where NOME_BASE = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, status);
			ps.setString(2, nomeBase);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException(
					"ocorreu um erro ao fazer update na base de nome:" + nomeBase + ". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// lista de bases para rodar de acordo com o nome da base origem
	public List<String> gerarListaBasesRodar(String nomeBase, String tipoBase) {

		List<String> bases = new ArrayList();
		String sql;
		sql = "select NOME_BASE FROM BASES_RUN " + "where NOME_BASE like ? and TIPO_BASE = ? ";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, "%" + nomeBase + "%");
			ps.setString(2, tipoBase);
			rs = ps.executeQuery();

			while (rs.next()) {
				bases.add(rs.getString("NOME_BASE"));
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	// lista de bases para rodar de acordo com o nome da base origem
	public List<String> gerarListaBasesRodarAutomatico(String nomeBase, String tipoBase) {

		List<String> bases = new ArrayList();
		String sql;
		sql = "select NOME_BASE FROM BASES_RUN_AUTOMATICA " + "where NOME_BASE like ? and TIPO_BASE = ? ";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, "%" + nomeBase + "%");
			ps.setString(2, tipoBase);
			rs = ps.executeQuery();

			while (rs.next()) {
				bases.add(rs.getString("NOME_BASE"));
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de colunas: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public void deletarListaRun(String nomeBase) {
		String sql;
		sql = "delete from bases_run  " + "WHERE NOME_BASE = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeBase);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException("ocorreu um erro ao deletar da lista de bases a rodar, a base:" + nomeBase + ". msg:"
					+ ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public List<ServidorSAS> listarServidoresSAS() {
		List<ServidorSAS> servidores = new ArrayList();
		String sql;
		sql = "select ID_SERVIDOR, NOME_SERVIDOR, HOST_NAME, PORTA from SERVIDORES_SAS";
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				ServidorSAS serv = new ServidorSAS();
				serv.setIdServidor(rs.getInt("ID_SERVIDOR"));
				serv.setNomeServidor(rs.getString("NOME_SERVIDOR"));
				serv.setHostName(rs.getString("HOST_NAME"));
				serv.setPorta(rs.getInt("PORTA"));
				servidores.add(serv);
			}

		} catch (Exception ex) {
			throw new DAOException("ocorreu um erro ao listar os servidores do SAS. msg:" + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}

		return servidores;

	}

	public String getNomeBasePeloID(int idTb) {
		List<Base> listaBases = new ArrayList();
		String sql;
		String nomeBase = "";

		sql = "Select NOME_BASE from tabela_qualidade WHERE ID_TB = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			rs = ps.executeQuery();

			if (rs.next()) {
				nomeBase = rs.getString("NOME_BASE");
			}

			return nomeBase;

		} catch (Exception ex) {
			throw new DAOException(
					"Ocorreu um erro ao retornar o nome da base de id: " + idTb + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public List<Setor> listarSetores() {
		List<Setor> listaDeSetores = new ArrayList();
		String sql = "SELECT ID_SETOR, NOME_SETOR FROM SETORES";
		Setor setor;

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conexao.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				setor = new Setor();
				setor.setIdSetor(rs.getInt("ID_SETOR"));
				setor.setNomeSetor(rs.getString("NOME_SETOR"));
				listaDeSetores.add(setor);
			}
		} catch (Exception e) {

		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stmt = GerenciadorDeConexao.close(stmt);
		}
		return listaDeSetores;
	}

	public void deleteTabelaAmostragem(int idTabela) {
		String sql;
		sql = "delete from calculos_observacao  " + "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTabela);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			throw new DAOException(
					"ocorreu um erro ao deletar as colunas da tabela de ID:" + idTabela + ". msg:" + ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public int getidBaseToda(int idTb) {
		List<Base> listaBases = new ArrayList();
		String sql;
		int idBaseToda = 0;

		sql = "Select ID_COLUNA from coluna_tabela WHERE ID_TB = ? and NOME_COLUNA = 'BASE_TODA'" + "";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idTb);
			rs = ps.executeQuery();

			if (rs.next()) {
				idBaseToda = rs.getInt("ID_COLUNA");
			}

			return idBaseToda;

		} catch (Exception ex) {
			throw new DAOException(
					"Ocorreu um erro ao retornar o nome da base de id: " + idTb + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public boolean qualidadeEstaAtiva(String nome) {
		String sql;
		sql = "select STATUS from qualidade_ativo  " + "WHERE NOME = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nome);
			rs = ps.executeQuery();
			if (rs.next()) {
				int status = rs.getInt("STATUS");
				if (status == 1) {
					return true;
				} else {
					return false;
				}
			}
		} catch (Exception ex) {
			throw new DAOException("Houve um erro ao retornar o status de ativo da qualidade: " + nome);
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
		return false;
	}

	public String getUltimaDataBaseSAS() {

		String sql = "select " + "CONCAT(Substring(replace(convert(char(20), ULTIMA_DT, 13),' ',''),1,9), "
				+ "Replace(substring(convert(char(20), ULTIMA_DT, 13),12,9), ' ',':')) as ULTIMA_DT "
				+ "from QUALIDADE_LAST_RUN WHERE NOME_AMBIENTE = 'SAS'";
		String data = "";
		Statement stm = null;
		ResultSet rs = null;
		try {
			stm = conexao.createStatement();
			rs = stm.executeQuery(sql);

			if (rs.next()) {
				data = rs.getString("ULTIMA_DT");
			}
		} catch (Exception ex) {
			new DAOException("Ocorreu um erro ao retornar a ultima data das bases SAS: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stm = GerenciadorDeConexao.close(stm);
		}

		return data;
	}

	// pega o nome e o path das bases cadastradas para poder
	public List<List<String>> getAtributosBases(String tipoBase) {
		String sql;
		List<List<String>> listaBases = new ArrayList();

		sql = "Select NOME_BASE, CONEXAO FROM TABELA_QUALIDADE WHERE TIPO_BASE = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, tipoBase);
			rs = ps.executeQuery();
			while (rs.next()) {
				List<String> base = new ArrayList();
				base.add(rs.getString("NOME_BASE"));
				base.add(rs.getString("CONEXAO"));
				listaBases.add(base);
			}
		} catch (Exception ex) {
			new DAOException("Ocorreu um erro ao retornar a lista de bases do ambiente: " + tipoBase);
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return listaBases;
	}

	public String[] getLoginSAS() {
		String sql;
		String[] login = new String[2];

		sql = "select * from pwd";

		PreparedStatement ps;
		Statement stm = null;
		ResultSet rs = null;

		try {
			stm = conexao.createStatement();
			rs = stm.executeQuery(sql);
			while (rs.next()) {
				login[0] = rs.getString("USR");
				login[1] = rs.getString("PWD");
			}
		} catch (Exception ex) {
			new DAOException("Ocorreu um erro ao retornar o usu�rio SAS");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			stm = GerenciadorDeConexao.close(stm);
		}

		return login;
	}

	// insere as novas bases automaticas na lsita de rodar. Executa multiplos
	// preparestatements em batch.
	public void InsereNovasBasesAutomaticas(List<Base> bases, String tipoBase) {

		String sql = "insert into BASES_RUN_AUTOMATICA (NOME_BASE, TIPO_BASE, STATUS_BASE) values (?,?,?)";
		PreparedStatement statement = null;
		try {

			statement = conexao.prepareStatement(sql);

			int i = 0;

			for (Base b : bases) {
				statement.setString(1, b.getNomeBase());
				statement.setString(2, tipoBase);
				statement.setInt(3, 1);

				statement.addBatch();
				i++;

				if (i % 1000 == 0 || i == bases.size()) {
					statement.executeBatch(); // Executa a cada mil registros.
				}
			}
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				throw new DAOException("Ocorreu um erro ao confirmar a transa��o");

				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			new DAOException("Erro ao inserir novas bases SAS: " + e.getMessage());
		} finally {
			statement = GerenciadorDeConexao.close(statement);
		}
	}

	public void updateQualidadeLastRun(String novaData, String tipoBase) {
		String sql = "update QUALIDADE_LAST_RUN SET ULTIMA_DT = ? WHERE NOME_AMBIENTE = ?";

		PreparedStatement ps = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, novaData);
			ps.setString(2, tipoBase);
			ps.executeUpdate();

			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				new DAOException("Ocorreu um erro ao confirmar a transa��o");
			}
		} catch (Exception ex) {
			System.out.println("Erro ao fazer update na Qualidade Last Run do ambiente: " + tipoBase + " . msg: "
					+ ex.getMessage());
			new DAOException("Erro ao fazer update na Qualidade Last Run do ambiente: " + tipoBase + " . msg: "
					+ ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}

	}

	public void updateTamanhoAmostraBasePeloID(int idTB, int tamanho) {
		String sql;
		sql = "UPDATE tabela_qualidade SET " + "TAMANHO_AMOSTRA = ? " + "WHERE ID_TB = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, tamanho);
			ps.setInt(2, idTB);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				System.out.println(ex.getMessage());
				conexao.rollback();
				// return "Ocorreu um erro ao confirmar a transa��o" + ex.getMessage(); //To
				// change body of generated methods, choose Tools | Templates.
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
	}

	public String getEmailResponsavelByID(int id) {
		String sql;
		String Email = "";

		sql = "select EMAIL_RESPONSAVEL from tabela_qualidade where ID_TB = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				Email = rs.getString("EMAIL_RESPONSAVEL");
			}
		} catch (Exception ex) {
			new DAOException("Ocorreu um erro ao retornar o usu�rio SAS");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return Email;
	}
	
	public String getMatResponsavelByID(int id) {
		String sql;
		String Email = "";

		sql = "select MAT_RESPONSAVEL from tabela_qualidade where ID_TB = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			while (rs.next()) {
				Email = rs.getString("MAT_RESPONSAVEL");
			}
		} catch (Exception ex) {
			new DAOException("Ocorreu um erro ao retornar o usu�rio SAS");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return Email;
	}
	
	public int getIDSetor(String nomeSetor) {
		String sql;
		int idSetor = 0;

		sql = "select ID_SETOR from SETORES where NOME_SETOR = ?";

		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeSetor);
			rs = ps.executeQuery();
			while (rs.next()) {
				idSetor = rs.getInt("ID_SETOR");
			}
		} catch (Exception ex) {
			new DAOException("Ocorreu um erro ao retornar o usu�rio SAS");
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}

		return idSetor;
	}
	

	//edita servidor SAS na base SERVIDORES_SAS
	public Resposta inserirServidorSAS(String nomeServidor, String hostName, int porta) {
		String sql;
		Resposta resp = new Resposta();
		sql = "Insert into SERVIDORES_SAS (NOME_SERVIDOR, HOST_NAME, PORTA) values (?, ?, ?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeServidor);
			ps.setString(2, hostName);
			ps.setInt(3, porta);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o " + ex.getMessage());
				resp.setTipo(2);
				return resp;

				//throw new DAOException("Ocorreu um erro ao confirmar a transa��o " + ex.getMessage()); // To change body																					// choose Tools
																										// | Templates.
			}
		} catch (Exception ex) {
			//throw new DAOException("Ocorreu um erro ao inserir o registro na SERVIDORES_SAS: " + ex.getMessage());
			
			resp.setMensagem("Ocorreu um erro ao inserir o registro na SERVIDORES_SAS: " + ex.getMessage());
			resp.setTipo(2);
			return resp;

		}
		
		resp.setMensagem("Registro inserido com sucesso");
		resp.setTipo(1);
		return resp; 
	}
	
	
	//edita um servidor sas, baseado no ID fornecido
	public Resposta updateServidorSasById(int idServidor, String nomeServidor, String hostName, int porta) {
		String sql;
		Resposta resp = new Resposta();
		
		sql = "UPDATE SERVIDORES_SAS SET NOME_SERVIDOR = ?, HOST_NAME = ?, PORTA = ?  WHERE ID_SERVIDOR = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeServidor);
			ps.setString(2, hostName);
			ps.setInt(3, porta);
			ps.setInt(4, idServidor);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o " + ex.getMessage());
				resp.setTipo(2);
				return resp;
			}
		} catch (Exception ex) {
			resp.setMensagem("ocorreu um erro ao fazer update no na Base SERVIDRES_SAS, ID:" + idServidor + ". nome: "
					+ nomeServidor + ". msg:" + ex.getMessage());
			resp.setTipo(2);
			return resp;
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
		
		resp.setMensagem("Registro editado com sucesso");
		resp.setTipo(1);
		return resp; 
	}
	
	//edita um setor, baseado no ID fornecido
	public Resposta updateSetorPorId(int idSetor, String nomeSetor) {
		String sql;
		Resposta resp = new Resposta();
		
		sql = "UPDATE SETORES SET NOME_SETOR = ? WHERE ID_SETOR = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeSetor);
			ps.setInt(2, idSetor);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o " + ex.getMessage());
				resp.setTipo(2);
				return resp;
			}
		} catch (Exception ex) {
			resp.setMensagem("ocorreu um erro ao fazer update no na Base SERVIDRES_SAS, ID:" + idSetor + ". nome: "
					+ nomeSetor + ". msg:" + ex.getMessage());
			resp.setTipo(2);
			return resp;
		} finally {
			ps = GerenciadorDeConexao.close(ps);
		}
		
		resp.setMensagem("Registro editado com sucesso");
		resp.setTipo(1);
		return resp; 
	}
	
	//Get setor por id_setor, para retrieve antes do update
	public Setor getSetorPorId(int idSetor) {
		String sql;
		Setor setor = new Setor();
		sql = "SELECT ID_SETOR, NOME_SETOR FROM SETORES WHERE ID_SETOR = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idSetor);
			rs = ps.executeQuery();

			if (rs.next()) {
				setor.setIdSetor(rs.getInt("ID_SETOR"));
				setor.setNomeSetor(rs.getString("NOME_SETOR"));
			}

			return setor;

		} catch (Exception ex) {
			throw new DAOException(
					"Ocorreu um erro ao retornar o servidor da base SAS de ID: " + idSetor + ". " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	
	//insere 1 setor na base SETORES
	public Resposta inserirSetor(String nomeSetor) {
		String sql;
		Resposta resp = new Resposta();
		sql = "Insert into SETORES (NOME_SETOR) values (?)";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nomeSetor);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o " + ex.getMessage());
				resp.setTipo(2);
				return resp;

				//throw new DAOException("Ocorreu um erro ao confirmar a transa��o " + ex.getMessage()); // To change body																					// choose Tools
																										// | Templates.
			}
		} catch (Exception ex) {
			//throw new DAOException("Ocorreu um erro ao inserir o registro na SERVIDORES_SAS: " + ex.getMessage());
			
			resp.setMensagem("Ocorreu um erro ao inserir o registro na SETORES: " + ex.getMessage());
			resp.setTipo(2);
			return resp;

		}
		resp.setMensagem("Registro inserido com sucesso!");
		resp.setTipo(1);
		return resp;
	}
	
	// retorna uma string concatenada com as bases de um certo setor
	public String getBasesPorSetor(int idSetor) {
		String bases = "";
		String sql;
		ColunaTabela coluna;

		sql = "Select nome_base from tabela_qualidade where id_setor =  ?";

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idSetor);
			rs = ps.executeQuery();

			while (rs.next()) {
				bases = bases + rs.getString("nome_base") + " <br>";
			}

			return bases;

		} catch (Exception ex) {
			throw new DAOException("Ocorreu um erro ao retornar a lista de bases por setor: " + ex.getMessage());
		} finally {
			rs = GerenciadorDeConexao.close(rs);
			ps = GerenciadorDeConexao.close(ps);
		}
	}
	
	// deleta um servidor SAS e por sua vez uma rela��o "servidor x base"
	public Resposta deletarServidorSasPorId(int idServidor) {
		Resposta resp = new Resposta();
		
		//deletando a rela��o primeiro, para evitar erro de constraint
		try{
			deletaServidorPorId(idServidor);
		}catch(Exception ex) {
			resp.setMensagem("ocorreu um erro ao deletar a rela��o 'servidorSAS x Base' do ID:" + idServidor + ". msg:" + ex.getMessage());
			resp.setTipo(2);
			return resp;
		}
		String sql = "delete from SERVIDORES_SAS  " + "WHERE ID_SERVIDOR = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idServidor);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				
				//throw new DAOException("Ocorreu um erro ao confirmar a transa��o");
				
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o. msg:" + ex.getMessage());
				resp.setTipo(2);
				return resp;
			}
		} catch (Exception ex) {
			
			
			resp.setMensagem("ocorreu um erro ao deletar a o servidorSAS da tabela de ID:" + idServidor + ". msg:" + ex.getMessage());
			resp.setTipo(2);
			return resp;
			
			//throw new DAOException("ocorreu um erro ao deletar a o servidorSAS da tabela de ID:" + idTb + ". msg:" + ex.getMessage());
			
		}
		
		resp.setMensagem("Registro deletado com sucesso");
		resp.setTipo(1);
		return resp; 
	}
	
	// deleta um Setor, desde que n�o haja nenhuma base conectada com ele por Foreign Key
	public Resposta deletarSetorPorId(int idSetor) {
		Resposta resp = new Resposta();
		String basesSetor = "";
		//checa se n�o existem bases relacionadas a esse setor (Constraint)
		try {
			basesSetor = getBasesPorSetor(idSetor);
		}catch(Exception ex) {
			resp.setMensagem("ocorreu um erro ao checar se existem bases cadastradas com esse setor: "+ idSetor + ". msg:" + ex.getMessage());
			resp.setTipo(2);
			return resp;
		}
		
		if(basesSetor != "") {
			resp.setMensagem("Esse setor n�o pode ser exluido, pois as seguintes bases est�o atreladas � ele, por favor delete as bases primeiro e depois o setor: <br>"+ basesSetor);
			resp.setTipo(2);
			return resp;
		}	
		
		String sql = "delete from SETORES WHERE ID_SETOR = ?";
		PreparedStatement ps = null;
		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, idSetor);
			ps.executeUpdate();
			try {
				conexao.commit();
			} catch (SQLException ex) {
				conexao.rollback();
				
				//throw new DAOException("Ocorreu um erro ao confirmar a transa��o");
				
				resp.setMensagem("Ocorreu um erro ao confirmar a transa��o. msg:" + ex.getMessage());
				resp.setTipo(2);
				return resp;
			}
		} catch (Exception ex) {
			
			
			resp.setMensagem("ocorreu um erro ao deletar o Setor: " + idSetor + ". msg:" + ex.getMessage());
			resp.setTipo(2);
			return resp;
			
			//throw new DAOException("ocorreu um erro ao deletar a o servidorSAS da tabela de ID:" + idTb + ". msg:" + ex.getMessage());
			
		}
		
		resp.setMensagem("Registro deletado com sucesso");
		resp.setTipo(1);
		return resp; 
	}
}
