package model;

import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;

public class Email {


	
	public Email() {
		
	}

	public void enviarEmail(final String usuario, final String senha, String remetente, String destinatario, String assunto,
			String texto) throws UnsupportedEncodingException, MessagingException, AddressException {

		Properties props = new Properties();

		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.smtp.host", "smtp.corpr.bradesco.com.br");
		props.setProperty("mail.smtp.port", "25");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(usuario, senha);
			}
		});

		Message msg = new MimeMessage(session);

		msg.setFrom(new InternetAddress(remetente, "Enviado de Admin"));
		msg.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario, "Usu�rio"));
		msg.setSubject(assunto);
		msg.setContent(texto, "text/html; charset=utf-8");

		System.out.println("Enviando email.");
		Transport.send(msg);
		System.out.println("Email enviado.");
	}

	public void enviarEmailComAnexo(final String usuario, final String senha, String remetente, String destinatario, String assunto,
			String texto, String caminhoArquivo, String nomeArquivo)
			throws UnsupportedEncodingException, MessagingException, AddressException {

		Properties props = new Properties();

		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.smtp.host", "smtp.corpr.bradesco.com.br");
		props.setProperty("mail.smtp.port", "25");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(usuario, senha);
			}
		});

		Message msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress(remetente, "Example.com Admin"));
		msg.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario, "Mr. User"));
		msg.setSubject(assunto);
		msg.setText(texto);

		Multipart multipart = new MimeMultipart();

		MimeBodyPart textBodyPart = new MimeBodyPart();
		textBodyPart.setText(texto);

		MimeBodyPart attachmentBodyPart = new MimeBodyPart();
		DataSource source = new FileDataSource(caminhoArquivo);
		attachmentBodyPart.setDataHandler(new DataHandler(source));
		attachmentBodyPart.setFileName(nomeArquivo);

		multipart.addBodyPart(textBodyPart);
		multipart.addBodyPart(attachmentBodyPart);

		msg.setContent(multipart);

		// [END multipart_example]

		System.out.println("Enviando email.");
		Transport.send(msg);
		System.out.println("Email enviado.");
	}

	
	
}
