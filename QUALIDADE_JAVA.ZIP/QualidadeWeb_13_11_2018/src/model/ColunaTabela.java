package model;

import java.util.ArrayList;
import java.util.List;

public class ColunaTabela {
	
	private int idColuna;
	private String nomeColuna;
	private int tipoColuna; //1 Num�rico, 2 - String
	private int tamanhoColuna;
	private int numOrdem;
	private Base tabela;
	private List<Regra> regras;
	private double rangeMin; //campo s� ser� usado quando for utilizada a regra de range
	private double rangeMax; //campo s� ser� usado quando for utilizada a regra de range
	private int colunaAutomatica; //1 - Colunas em Geral. 2 - Colunas gen�ricas.
	
	public ColunaTabela() {
		regras = new ArrayList();
	}
	
	public ColunaTabela(Base tabela) {
		this.tabela = tabela;
	}

	
	public String getNomeColuna() {
		return nomeColuna;
	}

	public void setNomeColuna(String nomeColuna) {
		this.nomeColuna = nomeColuna;
	}

	public int getTipoColuna() {
		return tipoColuna;
	}

	public void setTipoColuna(int tipoColuna) {
		this.tipoColuna = tipoColuna;
	}

	public int getTamanhoColuna() {
		return tamanhoColuna;
	}

	public void setTamanhoColuna(int tamanhoColuna) {
		this.tamanhoColuna = tamanhoColuna;
	}
	
	public int getNumOrdem() {
		return numOrdem;
	}

	public void setNumOrdem(int numOrdem) {
		this.numOrdem = numOrdem;
	}

	public Base getTabela() {
		return tabela;
	}

	public void setTabela(Base tabela) {
		this.tabela = tabela;
	}

	public int getIdColuna() {
		return idColuna;
	}

	public void setIdColuna(int idColuna) {
		this.idColuna = idColuna;
	}
	
	public void addRegra(Regra regra) {
		regras.add(regra);
	}
	
	public List<Regra> getRegras(){
		return regras;
	}

	public double getRangeMin() {
		return rangeMin;
	}

	public void setRangeMin(double rangeMin) {
		this.rangeMin = rangeMin;
	}

	public double getRangeMax() {
		return rangeMax;
	}

	public void setRangeMax(double rangeMax) {
		this.rangeMax = rangeMax;
	}

	public int getColunaAutomatica() {
		return colunaAutomatica;
	}

	public void setColunaAutomatica(int colunaAutomatica) {
		this.colunaAutomatica = colunaAutomatica;
	}

	public void setRegras(List<Regra> regras) {
		this.regras = regras;
	}
	
	
}
