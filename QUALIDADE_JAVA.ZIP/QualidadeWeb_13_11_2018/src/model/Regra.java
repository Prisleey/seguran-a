package model;

import java.util.Arrays;

//Essa � uma classe "multi-uso" para ambas tabelas 'REGRAS_QUALIDADE' quanto 'REGRAS_VS_BASE' do banco de dados
public class Regra {

	public int idRegra;
	public int idColuna;
	public int idTabela;
	public String nomeRegra;
	public String detalheRegra; //detalhamento da regra, ex: o campo deve conter pf e pj. O campo deve ter range x at� y, etc.
	public String detalheRegra2; //caso de range
	public ColunaTabela coluna;
	public String [] multiIds; //array de IDs para a regra de duplicidade que ser�o v�rios inserts.
	
	
	public Regra () {
		
	}

	public Regra(String detalheRegra) {
		this.detalheRegra = detalheRegra;
	}
	
	public int getIdRegra() {
		return idRegra;
	}


	public void setIdRegra(int idRegra) {
		this.idRegra = idRegra;
	}


	public int getIdColuna() {
		return idColuna;
	}


	public void setIdColuna(int idColuna) {
		this.idColuna = idColuna;
	}

	
	public int getIdTabela() {
		return idTabela;
	}


	public void setIdTabela(int idTabela) {
		this.idTabela = idTabela;
	}


	public String getNomeRegra() {
		return nomeRegra;
	}


	public void setNomeRegra(String nomeRegra) {
		this.nomeRegra = nomeRegra;
	}


	public String getDetalheRegra() {
		return detalheRegra;
	}


	public void setDetalheRegra(String detalheRegra) {
		this.detalheRegra = detalheRegra;
	}


	public String getDetalheRegra2() {
		return detalheRegra2;
	}


	public void setDetalheRegra2(String detalheRegra2) {
		this.detalheRegra2 = detalheRegra2;
	}


	public ColunaTabela getColuna() {
		return coluna;
	}


	public void setColuna(ColunaTabela coluna) {
		this.coluna = coluna;
	}

	public String[] getMultiIds() {
		return multiIds;
	}

	public void setMultiIds(String[] multiIds) {
		this.multiIds = multiIds;
	}
	
	public String getMultiIdsToString() {
		String ids = Arrays.toString(this.multiIds);
		ids = ids.substring(1, ids.length()-1);
		return ids;
	}
	
}
