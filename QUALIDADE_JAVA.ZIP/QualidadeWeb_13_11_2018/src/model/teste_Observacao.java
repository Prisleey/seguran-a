package model;

import java.sql.Date;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import DAO.BaseDAO;
import DAO.GerenciadorDeConexao;
import DAO.ObservacaoDAO;

public class teste_Observacao {
	
	public static void main(String[] args) {
		
		
		ArrayList<Double> nobsAmostra = new ArrayList<Double>();
		double[] nobs_teste = {97342.00,97228.00,97390.00,93705.00,94670.00,94077.00,96679.00,
				92359.00,95871.00,93806.00,94820.00,94486.00,95775.00,95001.00,92398.00,
				97000.00,94569.00,87000.00,93417.00,91255.00,92516.00,94025.00,95733.00,
				93297.00,92399.00,96008.00,92832.00,94741.00,93689.00,94074.00};
		for (int i = 0; i < nobs_teste.length; i++) {
			nobsAmostra.add(nobs_teste[i]);
		}
		
		calcObservacao(1,nobsAmostra);
		
		
	}
		
	@SuppressWarnings("unchecked")
	private static void calcObservacao(int idTabela, ArrayList<Double> nobsAmostra) {
		GerenciadorDeConexao sqlServer = null;
		
		try {
			Observacao nobs = new Observacao();
			sqlServer = new GerenciadorDeConexao();
			sqlServer.iniciar();
			ObservacaoDAO obsDAO = sqlServer.getObjetoObs();
			
			double lmiteSuperior = obsDAO.getLimiteSuperior(idTabela);
			double lmiteInferior = obsDAO.getLimiteInferior(idTabela);
			
			nobs.setNobs(nobsAmostra);
			nobs.setIdTabela(idTabela);
			nobs.setDesvioBaixo(lmiteInferior);
			nobs.setDesvioCima(lmiteSuperior);
			ArrayList<Double> nm_nobs = nobs.getNobs();
			double[] sd = nobs.getDesvioPad();
			double[] avg = nobs.getMedias();
			double[] range = nobs.getRange();
			double[] r_media = nobs.getMedia_Range();
			double[] lcl_x = nobs.getLimiteInf_Vermelho();
			double[] ucl_menos = nobs.getLimiteInf_Amarelo();
			double[] ucl_mais = nobs.getLimiteSup_Amarelo();
			double[] ucl_x = nobs.getLimiteSup_Vermelho();
			double[] calc_ldp_udp = nobs.getQtdDesvioNeces();
			double[] lcl_dp = nobs.getNmDesvioAbaixo(lmiteInferior);
			double[] ucl_dp = nobs.getNmDesvioAcima(lmiteSuperior);
			int[] flags = nobs.getFlags(lmiteSuperior,lmiteInferior);
			ArrayList<List> tabelaFinal;
			List linhaTabela;
			tabelaFinal = new ArrayList();
			
			for (int i = 0; i < nm_nobs.size(); i++) {
				linhaTabela = new ArrayList();
				DecimalFormat df = new DecimalFormat("0");
				DecimalFormat df_desvio = new DecimalFormat("0.###");
				String nm_obser = df.format(nm_nobs.get(i));
				String desvio = df.format(sd[i]);
				String media = df.format(avg[i]);
				String amplit = df.format(range[i]);
				String media_amp = df.format(r_media[i]);
				String lmtInf_Ver = df.format(lcl_x[i]);
				String lmtInf_Ama = df.format(ucl_menos[i]);
				String lmtSup_Ama = df.format(ucl_mais[i]);
				String lmtSup_Ver = df.format(ucl_x[i]);
				String desvio_nec = df_desvio.format(calc_ldp_udp[i]);
				String desvio_acima = df.format(lcl_dp[i]);
				String desvio_abaixo = df.format(ucl_dp[i]);
				
				linhaTabela.add(nm_nobs.get(i)); //nm_obser
				linhaTabela.add(sd[i]); //desvio
				linhaTabela.add(avg[i]); //media
				linhaTabela.add(range[i]); //amplit
				linhaTabela.add(r_media[i]); //media_amp
				linhaTabela.add(lcl_x[i]); //lmtInf_Ver
				linhaTabela.add(ucl_menos[i]); //lmtInf_Ama
				linhaTabela.add(ucl_mais[i]); //lmtSup_Ama
				linhaTabela.add(ucl_x[i]); //lmtSup_Ver
				linhaTabela.add(calc_ldp_udp[i]); //desvio_nec
				linhaTabela.add(lcl_dp[i]); //desvio_acima
				linhaTabela.add(ucl_dp[i]); //desvio_abaixo
				linhaTabela.add(flags[i]); //flag
				
				String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmmss").format(Calendar.getInstance().getTime());
				linhaTabela.add(timeStamp); //data flag
				
				tabelaFinal.add(linhaTabela);
				
				System.out.println(i + "	" + nm_obser + "	" + desvio + "	" + media + "	" 
				+ amplit + "	" + media_amp + "	" + lmtInf_Ver + "	" + lmtInf_Ama + "	" 
				+ lmtSup_Ama + "	" + lmtSup_Ver + "	" + desvio_nec + "	" + desvio_acima+ "	" 
				+ desvio_abaixo + "	" + flags[i] + " " + timeStamp);
			}
			
			obsDAO.inserirTabelaAmostragem(idTabela, tabelaFinal);
		} finally {
			if (sqlServer != null) {
				sqlServer.encerrar(); // fechando a conex�o com o banco
			}
		}
	}
	
}