package model;

public class StatusBases {
	
	private int idTb;
	private int idItemSP;
	private String nomeBase;
	private int statusBase;
	private int statusObservacao;
	private int statusIntegridade;
	private int statusDuplicidade;
	private int statusDominio;
	private int statusMissing;
	private int statusRange;
	private int statusPSI;
	private String dataModificacao;
	private int statusReprocessamento;
	private String dataQualidade;
	private String periodicidade;
	private int statusEmail;
	
	public int getIdTb() {
		return idTb;
	}
	public void setIdTb(int idTb) {
		this.idTb = idTb;
	}
	public String getNomeBase() {
		return nomeBase;
	}
	public void setNomeBase(String nomeBase) {
		this.nomeBase = nomeBase;
	}
	public int getStatusObservacao() {
		return statusObservacao;
	}
	public void setStatusObservacao(int statusObservacao) {
		this.statusObservacao = statusObservacao;
	}
	public int getStatusIntegridade() {
		return statusIntegridade;
	}
	public void setStatusIntegridade(int statusIntegridade) {
		this.statusIntegridade = statusIntegridade;
	}
	public int getStatusDuplicidade() {
		return statusDuplicidade;
	}
	public void setStatusDuplicidade(int statusDuplicidade) {
		this.statusDuplicidade = statusDuplicidade;
	}
	public int getStatusDominio() {
		return statusDominio;
	}
	public void setStatusDominio(int statusDominio) {
		this.statusDominio = statusDominio;
	}
	public int getStatusMissing() {
		return statusMissing;
	}
	public void setStatusMissing(int statusMissing) {
		this.statusMissing = statusMissing;
	}
	public int getStatusRange() {
		return statusRange;
	}
	public void setStatusRange(int statusRange) {
		this.statusRange = statusRange;
	}
	public int getStatusPSI() {
		return statusPSI;
	}
	public void setStatusPSI(int statusPSI) {
		this.statusPSI = statusPSI;
	}
	public String getDataModificacao() {
		return dataModificacao;
	}
	public void setDataModificacao(String dataModificacao) {
		this.dataModificacao = dataModificacao;
	}
	public int getStatusReprocessamento() {
		return statusReprocessamento;
	}
	public void setStatusReprocessamento(int statusReprocessamento) {
		this.statusReprocessamento = statusReprocessamento;
	}
	public String getDataQualidade() {
		return dataQualidade;
	}
	public void setDataQualidade(String dataQualidade) {
		this.dataQualidade = dataQualidade;
	}
	public String getPeriodicidade() {
		return periodicidade;
	}
	public void setPeriodicidade(String periodicidade) {
		this.periodicidade = periodicidade;
	}
	public int getStatusBase() {
		return statusBase;
	}
	public void setStatusBase(int statusBase) {
		this.statusBase = statusBase;
	}
	public int getStatusEmail() {
		return statusEmail;
	}
	public void setStatusEmail(int statusEmail) {
		this.statusEmail = statusEmail;
	}
	public int getIdItemSP() {
		return idItemSP;
	}
	public void setIdItemSP(int idItemSP) {
		this.idItemSP = idItemSP;
	}
	
		
}