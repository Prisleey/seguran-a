package model;

import java.util.Date;

public class Notificacao {
	
	private int idColuna;
	private int idRegra;
	private String descricaoRegra;
	private String nomeBase;
	private String nomeMetrica;
	private String mensagem;
	private String nomeColuna;
	private String dataNotificacao;
	private String area;
	private String cor;
	
	public int getIdColuna() {
		return idColuna;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public void setIdColuna(int idColuna) {
		this.idColuna = idColuna;
	}
	public int getIdRegra() {
		return idRegra;
	}
	public void setIdRegra(int idRegra) {
		this.idRegra = idRegra;
	}
	public String getNomeBase() {
		return nomeBase;
	}
	public void setNomeBase(String nomeBase) {
		this.nomeBase = nomeBase;
	}
	public String getMensagem() {
		return mensagem;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	public String getDataNotificacao() {
		return dataNotificacao;
	}
	public void setDataNotificacao(String dataNotificacao) {
		this.dataNotificacao = dataNotificacao;
	}
	public String getNomeColuna() {
		return nomeColuna;
	}
	public void setNomeColuna(String nomeColuna) {
		this.nomeColuna = nomeColuna;
	}
	public String getDescricaoRegra() {
		return descricaoRegra;
	}
	public void setDescricaoRegra(String descricaoRegra) {
		this.descricaoRegra = descricaoRegra;
	}
	public String getNomeMetrica() {
		return nomeMetrica;
	}
	public void setNomeMetrica(String nomeMetrica) {
		this.nomeMetrica = nomeMetrica;
	}
	
	
	
}