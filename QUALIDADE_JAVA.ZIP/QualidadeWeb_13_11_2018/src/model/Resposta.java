package model;

//classe(objeto) padr�o para envio de respostas/mensagens entre as camadas do sistema

public class Resposta {
	String mensagem;
	int tipo; //tipo 1 = sucesso, tipo 2 = erro
	
	public Resposta(){
		
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	
}
