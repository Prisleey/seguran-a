package model;

import java.util.ArrayList;
import java.util.List;

import DAO.GerenciadorDeConexao;
import DAO.ObservacaoDAO;


public class ObservacaoMediaHist {
	
	//campos usados para quando for retornar a informa��o
	int idTabela;
	double numObs;
	double desvio;
	double media;
	double rangeIndividual;
	double mediaRange;
	double lmtInfVer;
	double lmtInfAma;
	double lmtSupAma;
	double lmtSupVer; 
	double desvioNecess; 
	double desvioCima;
	double desvioBaixo;
	int flag;
	String dataFlag;
	
	// Vetor para o n�mero de registros
	private ArrayList<Double> nobs;
	private double[] range;

	// Pega as informa��es da amostra
	public ArrayList<Double> getNobs() {
		return nobs;
	}
	
	// Salva as novas informa��es como sendo a amostra
	public void setNobs(ArrayList<Double> nobs) {
		this.nobs = nobs;
	}
	
	// Calcular Desvio Padr�o
	public double[] getDesvioPad() {

		double[] nobs_1;
		double[] desvio = new double[nobs.size()];
		

		desvio[0] = nobs.get(0);

		for (int i = 1; i < desvio.length; i++) {
			
				nobs_1 = new double[i + 1];
				
				for (int j = 0; j < nobs_1.length; j++) {
					nobs_1[j] = nobs.get(j);
				}
				desvio[i] = desvio_padrao(nobs_1);
		}
		return desvio;
	}

	// Calcular M�dia Aritm�tica
	public double[] getMedias() {

		double[] nobs_1;
		double[] media_1 = new double[nobs.size()];
		
				
		media_1[0] = nobs.get(0);

		for (int i = 1; i < media_1.length; i++) {
			
				nobs_1 = new double[i + 1];
				
				for (int j = 0; j < nobs_1.length; j++) {
					nobs_1[j] = nobs.get(j);
				}
				media_1[i] = media(nobs_1);
		}
		
		return media_1;
	}

	// Pega a amplitude dos n�meros de observa��o
	public double[] getRange() {

		
		range = new double[nobs.size()];
		
		
		range[0] = 1;

		for (int i = 1; i < range.length; i++) {
			range[i] = Math.abs(nobs.get(i - 1) - nobs.get(i));
		}

		return range;
	}

	// Calcular M�dia Aritm�tica do Range
	public double[] getMedia_Range() {

		double[] range_1;
		double[] media_1 = new double[range.length];

		media_1[0] = range[0];
		media_1[1] = range[1];
		
		for (int i = 2; i < media_1.length; i++) {
			
				range_1 = new double[i];
				for (int j = 0; j < range_1.length; j++) {
					
					range_1[j] = range[j + 1];
				}
				media_1[i] = media(range_1);
		}
		return media_1;
	}

	// Calcular Limite Superior Vermelho
	public double[] getLimiteSup_Vermelho() {

		double[] media = getMedias();
		double[] r_media = getMedia_Range();
		double[] lmtSuperior = new double[media.length];
		
		
		lmtSuperior[0] = nobs.get(0);

		for (int i = 1; i < lmtSuperior.length; i++) {
			lmtSuperior[i] = media[i] + 0.8865 * getDesvioCima() * r_media[i];
		}

		return lmtSuperior;
	}

	// Calcular Limite Superior Amarelo
	public double[] getLimiteSup_Amarelo() {

		double[] desvio = getDesvioPad();
		double[] lmtSuperior = getLimiteSup_Vermelho();
		double[] lmtSuperior_Amar = new double[desvio.length];
		
		
		lmtSuperior_Amar[0] = nobs.get(0);

		for (int i = 1; i < lmtSuperior_Amar.length; i++) {
			lmtSuperior_Amar[i] = lmtSuperior[i] - (desvio[i] * 0.7);
		}

		return lmtSuperior_Amar;
	}

	// Calcular Limite Inferior Vermelho
	public double[] getLimiteInf_Vermelho() {

		double[] media = getMedias();
		double[] r_media = getMedia_Range();
		double[] lmtInferior = new double[media.length];
		
		
		lmtInferior[0] = nobs.get(0);

		for (int i = 1; i < lmtInferior.length; i++) {
			lmtInferior[i] = media[i] + 0.8865 * getDesvioBaixo() * r_media[i];
		}

		return lmtInferior;
	}

	// Calcular Limite Inferior Amarelo
	public double[] getLimiteInf_Amarelo() {

		double[] desvio = getDesvioPad();
		double[] lmtInferior = getLimiteInf_Vermelho();
		double[] lmtInferior_Amar = new double[desvio.length];
		
		
		lmtInferior_Amar[0] = nobs.get(0);

		for (int i = 1; i < lmtInferior_Amar.length; i++) {
			lmtInferior_Amar[i] = lmtInferior[i] + (desvio[i] * 0.7);
		}

		return lmtInferior_Amar;
	}

	// Pega a quantidade de desvio que cada registro gera
	public double[] getQtdDesvioNeces() {
		
		
		double[] media = getMedias();
		double[] r_media = getMedia_Range();
		double[] qtdDesvioNeces = new double[media.length];
		
		qtdDesvioNeces[0] = 0.0;

		for (int i = 1; i < qtdDesvioNeces.length; i++) {
			if (r_media[i] == 0) {
				System.out.println("� zero");
				qtdDesvioNeces[i] = 0;
			}
			else {
				qtdDesvioNeces[i] = (-media[i] + nobs.get(i)) / (0.8865 * r_media[i]);
			}
		}

		return qtdDesvioNeces;
	}
	
	// Retorna a quantidade de desvios acima da m�dia
	public double[] getNmDesvioAcima(double limSup) {

		double[] numero_de_desvios = new double[this.nobs.size()];
		
		for (int i = 0; i < numero_de_desvios.length; i++) {
			numero_de_desvios[i] = limSup;
		}

		return numero_de_desvios;
	}

	// Retorna a quantidade de desvios abaixo da m�dia
	public double[] getNmDesvioAbaixo(double limInf) {

		double[] numero_de_desvios = new double[this.nobs.size()];
		
		for (int i = 0; i < numero_de_desvios.length; i++) {
			numero_de_desvios[i] = limInf;
		}

		return numero_de_desvios;
	}
	
	
	// Pega warnings e erros
	public int[] getFlags(double limInf, double limSup) {
		
		
		int[] flags = new int[nobs.size()];
		double[] qtd_desv = getQtdDesvioNeces();
		double[] lmtInferiorVermelho = getNmDesvioAbaixo(limInf);
		double[] lmtSuperiorVermelho = getNmDesvioAcima(limSup);
		
		for (int i = 0; i < flags.length; i++) {
			
			// Acima do limite superior mais positivo
			if (qtd_desv[i] >= lmtSuperiorVermelho[i]) {
				flags[i] = 2;
			} // Entre o limite superior positivo e o limite superior mais positivo
			else if ((qtd_desv[i] >= lmtSuperiorVermelho[i] * 0.7) && qtd_desv[i] < lmtSuperiorVermelho[i]) {
				flags[i] = 1;
			} // Dentro do esperado
			else if ((qtd_desv[i] < lmtSuperiorVermelho[i] * 0.7) && qtd_desv[i] > lmtInferiorVermelho[i] * 0.7) { // Entre o limite inferior menos negativo e o limite inferior mais negativo
				flags[i] = 0;
			}
			else if ((qtd_desv[i] <= lmtInferiorVermelho[i] * 0.7) && qtd_desv[i] > lmtInferiorVermelho[i]) {
				flags[i] = -1;
			} // Abaixo do limite inferior mais negativo
			else if (qtd_desv[i] <= lmtInferiorVermelho[i]) {
				flags[i] = -2;
			}
				
		} 
		
		return flags;
	}
	
	// Calcula a m�dia de uma determinada amostra
	public double media(double[] nobs) {
		
		double soma = 0.0;
		
		for (int i = 0; i < nobs.length; i++) {
			soma += nobs[i];
		}
		return soma/nobs.length;
	}
	
	// Calcula o desvio padr�o de uma determinada amostra
	public double desvio_padrao(double[] nobs) {
		
		double avg = media(nobs);
		double soma = 0.0;
		double accum2 = 0.0;
		double dev = 0.0;
		int tam = nobs.length;
		
		for (int i = 0; i < nobs.length; i++) {
			dev = nobs[i] - avg;
            accum2 += dev;
			soma += (dev)*(dev);
		}
		
		return Math.sqrt((soma - (accum2 * accum2 / tam)) / (tam - 1.0));
	}

	public double getNumObs() {
		return numObs;
	}

	public void setNumObs(double numObs) {
		this.numObs = numObs;
	}

	public double getDesvio() {
		return desvio;
	}

	public void setDesvio(double desvio) {
		this.desvio = desvio;
	}

	public double getRangeIndividual() {
		return rangeIndividual;
	}

	public void setRangeIndividual(double rangeIndividual) {
		this.rangeIndividual = rangeIndividual;
	}

	public double getMediaRange() {
		return mediaRange;
	}

	public void setMediaRange(double mediaRange) {
		this.mediaRange = mediaRange;
	}

	public double getLmtInfVer() {
		return lmtInfVer;
	}

	public void setLmtInfVer(double lmtInfVer) {
		this.lmtInfVer = lmtInfVer;
	}

	public double getLmtInfAma() {
		return lmtInfAma;
	}

	public void setLmtInfAma(double lmtInfAma) {
		this.lmtInfAma = lmtInfAma;
	}

	public double getLmtSupAma() {
		return lmtSupAma;
	}

	public void setLmtSupAma(double lmtSupAma) {
		this.lmtSupAma = lmtSupAma;
	}

	public double getLmtSupVer() {
		return lmtSupVer;
	}

	public void setLmtSupVer(double lmtSupVer) {
		this.lmtSupVer = lmtSupVer;
	}

	public double getDesvioNecess() {
		return desvioNecess;
	}

	public void setDesvioNecess(double desvioNecess) {
		this.desvioNecess = desvioNecess;
	}

	public double getDesvioCima() {
		return desvioCima;
	}

	public void setDesvioCima(double desvioCima) {
		this.desvioCima = desvioCima;
	}

	public double getDesvioBaixo() {
		return desvioBaixo;
	}

	public void setDesvioBaixo(double desvioBaixo) {
		this.desvioBaixo = desvioBaixo;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}
	
	public double getMedia() {
		return media;
	}
	public void setMedia(double media) {
		this.media = media;
	}

	public int getIdTabela() {
		return idTabela;
	}

	public void setIdTabela(int idTabela) {
		this.idTabela = idTabela;
	}

	public String getDataFlag() {
		return dataFlag;
	}

	public void setDataFlag(String dataFlag) {
		this.dataFlag = dataFlag;
	}
	
	

}
