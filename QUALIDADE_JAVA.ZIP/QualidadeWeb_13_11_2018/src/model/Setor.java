package model;

public class Setor {
	
	int idSetor;
	String nomeSetor;
	
	public Setor() {
		
	}
	
	public Setor(int idSetor) {
		this.idSetor = idSetor;
	}
	
	public Setor(int idSetor, String nomeSetor) {
		this.idSetor = idSetor;
		this.nomeSetor = nomeSetor;
	}

	public int getIdSetor() {
		return idSetor;
	}

	public void setIdSetor(int idSetor) {
		this.idSetor = idSetor;
	}

	public String getNomeSetor() {
		return nomeSetor;
	}

	public void setNomeSetor(String nomeSetor) {
		this.nomeSetor = nomeSetor;
	}
	
	
}

