package model;

import java.util.ArrayList;
import java.util.List;

public class Base {

	private int idTabela;
	private String nomeBase;
	private String conexao;
	private String tipoBase;
	private String matriculaResponsavel;
	private String emailResponsavel;
	private List<ColunaTabela> colunas;
	private Setor setor;
	private Double limiteSuperior; //somente usado para a m�trica de observa��o
	private Double limiteInferior; //somente usado para a m�trica de observa��o
	private boolean estaVazia; //checar se a tabela esta vazia
	private ServidorSAS servidorSAS; //somente usado caso a base seja SAS
	private int tipoLayout; //tipo 1 = automatico, tipo 2 = manual
	private String nomeBaseLayout; //nome do arquivo que servir� de modelo no caso de bases autom�ticas.
	private String periodicidade;
	private int safrada;
	private int tamanhoAmostra;
	private String increm_full;
	
	//Construtor 1 - inicia uma tabela sem colunas
	public Base() {
		colunas = new ArrayList();
	}
	
	//Construtor 2 - inicia uma tabela com ao menos 1 coluna  (n�o sei se ir� ser utilizado de fato)
	public Base(List<ColunaTabela> colunas) {
		this.colunas = colunas;
	}
	
	
	public Base(String nomeBase, String conexao) {
		this.nomeBase = nomeBase;
		this.conexao = conexao;
	}
	
	public int getIdTabela() {
		return idTabela;
	}

	public void setIdTabela(int idTabela) {
		this.idTabela = idTabela;
	}

	public String getNomeBase() {
		return nomeBase;
	}
	
	public void setNomeBase(String nomeBase) {
		this.nomeBase = nomeBase;
	}
	
	public String getConexao() {
		return conexao;
	}
	
	public void setConexao(String conexao) {
		this.conexao = conexao;
	}
	
	
	
	public String getTipoBase() {
		return tipoBase;
	}
	
	public void setTipoBase(String tipoBase) {
		this.tipoBase = tipoBase;
	}
	
	
	public String getMatriculaResponsavel() {
		return matriculaResponsavel;
	}

	public void setMatriculaResponsavel(String matriculaResponsavel) {
		this.matriculaResponsavel = matriculaResponsavel;
	}

	public void addColuna(ColunaTabela coluna) {
		colunas.add(coluna);
	}
	
	
	
	public List<ColunaTabela> getColunas() {
		return colunas;
	}

	public void addListaColunas(List<ColunaTabela> colunas) {
		this.colunas = colunas;
	}

	public Double getLimiteSuperior() {
		return limiteSuperior;
	}

	public void setLimiteSuperior(Double limiteSuperior) {
		this.limiteSuperior = limiteSuperior;
	}

	public Double getLimiteInferior() {
		return limiteInferior;
	}

	public void setLimiteInferior(Double limiteInferior) {
		this.limiteInferior = limiteInferior;
	}

	public boolean isEstaVazia() {
		return estaVazia;
	}

	public void setEstaVazia(boolean estaVazia) {
		this.estaVazia = estaVazia;
	}

	public ServidorSAS getServidorSAS() {
		return servidorSAS;
	}

	public void setServidorSAS(ServidorSAS servidorSAS) {
		this.servidorSAS = servidorSAS;
	}

	public void setColunas(List<ColunaTabela> colunas) {
		this.colunas = colunas;
	}

	public Setor getSetor() {
		return setor;
	}

	public void setSetor(Setor setor) {
		this.setor = setor;
	}

	public int getTipoLayout() {
		return tipoLayout;
	}

	public void setTipoLayout(int tipoLayout) {
		this.tipoLayout = tipoLayout;
	}

	public String getNomeBaseLayout() {
		return nomeBaseLayout;
	}

	public void setNomeBaseLayout(String nomeBaseLayout) {
		this.nomeBaseLayout = nomeBaseLayout;
	}

	public String getPeriodicidade() {
		return periodicidade;
	}

	public void setPeriodicidade(String periodicidade) {
		this.periodicidade = periodicidade;
	}

	public int getSafrada() {
		return safrada;
	}

	public void setSafrada(int safrada) {
		this.safrada = safrada;
	}

	public int getTamanhoAmostra() {
		return tamanhoAmostra;
	}

	public void setTamanhoAmostra(int tamanhoAmostra) {
		this.tamanhoAmostra = tamanhoAmostra;
	}

	public String getIncrem_full() {
		return increm_full;
	}

	public void setIncrem_full(String increm_full) {
		this.increm_full = increm_full;
	}

	public String getEmailResponsavel() {
		return emailResponsavel;
	}

	public void setEmailResponsavel(String emailResponsavel) {
		this.emailResponsavel = emailResponsavel;
	}
	
	
}
