package model;

public class Integridade {

}
