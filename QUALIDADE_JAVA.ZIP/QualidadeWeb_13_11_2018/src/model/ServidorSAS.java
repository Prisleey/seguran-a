package model;

public class ServidorSAS {
	
	private int idServidor;
	private String nomeServidor;
	private String hostName;
	private int porta;
	
	public ServidorSAS() {
		
	}
	
	//construtor para quando se apenas necessita do ID do servidor
	public ServidorSAS(int idServidor) {
		this.idServidor = idServidor;
	}
	
	public int getIdServidor() {
		return idServidor;
	}


	public void setIdServidor(int idServidor) {
		this.idServidor = idServidor;
	}


	public String getNomeServidor() {
		return nomeServidor;
	}

	public void setNomeServidor(String nomeServidor) {
		this.nomeServidor = nomeServidor;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public int getPorta() {
		return porta;
	}

	public void setPorta(int porta) {
		this.porta = porta;
	}
	
	
}
